# KeyShortcut v2.4 — GitHub phone build package

1. Upload `KeyShortcutV2-v2.4-source.zip` to the root of your GitHub repository.
2. Create `.github/workflows/build-apk.yml` and paste the workflow supplied in chat.
3. GitHub → Actions → Build KeyShortcut APK → Run workflow.
4. Download artifact `KeyShortcut-v2.4-test-apk`.

Keep the working v2.2 APK installed while testing. v2.4 uses package ID `com.example.keyshortcut.test24` in the build workflow.

After installing v2.4, open Voice Recorder once, grant microphone permission if requested, and link `SD card/KeyShortcut/Recordings`. This arms the recorder foreground service so the later hardware gesture can start/stop recording without trying to create a microphone foreground service from the background.
