package com.example.keyshortcut

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

/** Polished standalone voice recorder experience inside KeyShortcut. */
class VoiceRecorderActivity : Activity() {
    companion object {
        const val ACTION_REFRESH = "com.example.keyshortcut.voice.REFRESH"
        const val PICK_FOLDER = 8801
        fun notifyRefresh(ctx: Context) { ctx.sendBroadcast(Intent(ACTION_REFRESH).setPackage(ctx.packageName)) }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var playing: RecordingStore.Item? = null
    private var timer: TextView? = null
    private var waveform: LinearLayout? = null
    private var titleView: TextView? = null
    private var pendingStartAfterPermission = false

    private val refreshReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { showHome() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registerReceiver(refreshReceiver, IntentFilter(ACTION_REFRESH), Context.RECEIVER_NOT_EXPORTED)
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            VoiceRecorderService.arm(this)
        }
        showHome()
    }

    override fun onDestroy() {
        try { unregisterReceiver(refreshReceiver) } catch (_: Exception) {}
        player?.release(); player = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(text: String, size: Float, bold: Boolean = false, color: Int = Color.BLACK) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); includeFontPadding = true
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun button(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text; setAllCaps(false); setOnClickListener { click() }
    }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun spacer(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }

    private fun backToMain() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }

    private fun header(title: String, back: () -> Unit): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(tv("‹", 38f, false, Color.BLACK).apply { setOnClickListener { back() }; setPadding(0, 0, dp(8), 0) })
        addView(tv(title, 25f, true))
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(32)) }
        root.addView(header("Voice Recorder") { backToMain() })
        root.addView(tv("Record, edit, and keep your voice notes on your SD card.", 13f, false, Color.DKGRAY))
        root.addView(spacer(16))

        root.addView(recordingStudio())
        root.addView(spacer(20))
        root.addView(storageCard())
        root.addView(spacer(20))
        root.addView(recentSection())
        root.addView(spacer(12))
        root.addView(button("View all recordings") { showLibrary() })

        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        if (VoiceRecorderService.recording) startLoops()
    }

    private fun recordingStudio(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(0xFF111217.toInt(), 30)
        }

        val recording = VoiceRecorderService.recording
        val paused = VoiceRecorderService.paused
        val stateColor = when {
            recording && !paused -> 0xFFFF5B6B.toInt()
            recording -> 0xFFFFC857.toInt()
            else -> 0xFFB7BBC7.toInt()
        }

        val state = tv(if (recording) if (paused) "PAUSED" else "RECORDING" else "READY", 12f, true, stateColor).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            letterSpacing = .12f
        }
        card.addView(state)

        timer = tv(if (recording) elapsed() else "00:00", 58f, true, Color.WHITE).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            letterSpacing = .02f
            setPadding(0, dp(4), 0, 0)
        }
        card.addView(timer)

        titleView = tv(if (recording) "Current recording" else "Voice Memo", 14f, false, 0xFFB9BBC4.toInt()).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        }
        card.addView(titleView)
        card.addView(spacer(16))

        waveform = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        repeat(36) { i -> waveform!!.addView(waveBar(if (recording) 10 + ((i * 7) % 28) else 7 + ((i % 4) * 4))) }
        card.addView(waveform)
        card.addView(spacer(14))

        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }

        if (recording) {
            controls.addView(circleAction(if (paused) "▶" else "Ⅱ", if (paused) "Resume" else "Pause") {
                VoiceRecorderService.send(this@VoiceRecorderActivity, if (paused) VoiceRecorderService.ACTION_RESUME else VoiceRecorderService.ACTION_PAUSE)
                handler.postDelayed({ showHome() }, 220)
            })
            controls.addView(spacerH(18))
            controls.addView(circleAction("■", "Stop", 0xFFE94B5B.toInt()) {
                VoiceRecorderService.send(this@VoiceRecorderActivity, VoiceRecorderService.ACTION_STOP)
                handler.postDelayed({ showHome() }, 450)
            })
        } else {
            controls.addView(circleAction("●", "Record", 0xFFFF4F61.toInt()) { startRecordingFromPage() })
        }
        card.addView(controls)
        card.addView(spacer(10))
        card.addView(tv(
            if (recording) "Recording stays active while you use other apps." else "Tap Record to start a new voice recording.",
            12f, false, 0xFF8F929D.toInt()
        ).apply { gravity = Gravity.CENTER_HORIZONTAL })
        return card
    }

    private fun waveBar(h: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(3), dp(h)).apply { leftMargin = dp(2); rightMargin = dp(2) }
        setBackgroundColor(0xFF6875FF.toInt())
    }

    private fun circleAction(symbol: String, label: String, color: Int = 0xFF4657D8.toInt(), click: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT)
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
        val circle = TextView(this).apply {
            text = symbol
            textSize = if (symbol == "●") 28f else 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(color)
            }
            layoutParams = LinearLayout.LayoutParams(dp(62), dp(62))
        }
        box.addView(circle)
        box.addView(tv(label, 12f, true, 0xFFB9BBC4.toInt()).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
        return box
    }

    private fun spacerH(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }

    private fun startRecordingFromPage() {
        val validation = StorageManager.validate(this)
        if (!validation.ok) {
            toast(validation.message)
            linkFolder()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterPermission = true
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 740)
            return
        }
        VoiceRecorderService.startFromVisibleActivity(this)
        handler.postDelayed({ showHome() }, 300)
    }

    private fun storageCard(): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(17), dp(17), dp(17))
            background = rounded(0xFFF1F3F8.toInt(), 22)
        }
        c.addView(tv("Recording Storage", 18f, true))
        c.addView(spacer(4))
        val validation = StorageManager.validate(this)
        val linked = validation.ok
        c.addView(tv(if (linked) "● SD card connected" else "● Storage needs attention", 13f, true, if (linked) 0xFF258A57.toInt() else 0xFFB84D59.toInt()))
        c.addView(tv(if (linked) "SD card / KeyShortcut / Recordings" else validation.message, 13f, false, 0xFF5D626D.toInt()).apply { setPadding(0, dp(3), 0, dp(8)) })
        c.addView(button(if (linked) "Change storage folder" else "Link storage folder") { linkFolder() })
        return c
    }

    private fun linkFolder() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        }, PICK_FOLDER)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_FOLDER || resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            val takeFlags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            contentResolver.takePersistableUriPermission(uri, takeFlags)
            StorageManager.setTreeUri(this, uri)
            val validation = StorageManager.validate(this)
            if (!validation.ok) {
                toast(validation.message)
            } else {
                if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) VoiceRecorderService.arm(this)
                toast("Recording storage connected")
            }
        } catch (_: Exception) { toast("Couldn't connect to that folder. Choose the KeyShortcut/Recordings folder again.") }
        showHome()
    }

    private fun recentSection(): View {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("Recent Recordings", 21f, true).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        head.addView(tv("All  ›", 14f, true, 0xFF4F6BED.toInt()).apply { setOnClickListener { showLibrary() } })
        wrap.addView(head)
        wrap.addView(spacer(8))
        val list = RecordingStore.all(this)
        if (list.isEmpty()) {
            val empty = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(26), dp(20), dp(26)); background = rounded(0xFFF3F4F7.toInt(), 18) }
            empty.addView(tv("No recordings yet", 17f, true)); empty.addView(tv("Your saved voice notes will appear here.", 13f, false, Color.GRAY))
            wrap.addView(empty)
        } else {
            list.take(5).forEach { wrap.addView(recordingRow(it)) }
        }
        return wrap
    }

    private fun recordingRow(item: RecordingStore.Item): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(13), dp(12), dp(10), dp(12)); background = rounded(0xFFF0F1F5.toInt(), 17) }
        val icon = tv("◉", 23f, true, 0xFF4F6BED.toInt()).apply { gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)) }
        r.addView(icon)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(10); rightMargin = dp(8) } }
        col.addView(tv(item.name, 15f, true))
        col.addView(tv(formatDate(item.created) + "  •  " + duration(item), 11f, false, Color.GRAY))
        r.addView(col)
        r.addView(tv("▶", 18f, true, 0xFF4F6BED.toInt()).apply { setOnClickListener { play(item) } })
        r.addView(tv("⋮", 25f, false, Color.DKGRAY).apply { setPadding(dp(12), 0, 0, 0); setOnClickListener { menu(item) } })
        r.setOnClickListener { showRecording(item) }
        r.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
        return r
    }

    private fun menu(item: RecordingStore.Item) {
        AlertDialog.Builder(this).setItems(arrayOf("Play", "Rename", "Trim", "Share", "Delete")) { _, which ->
            when (which) { 0 -> play(item); 1 -> rename(item); 2 -> trim(item); 3 -> share(item); 4 -> delete(item) }
        }.show()
    }

    private fun showLibrary() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(32)) }
        root.addView(header("Recordings") { backToMain() })
        root.addView(tv("Your saved voice notes", 13f, false, Color.DKGRAY))
        root.addView(spacer(14))
        RecordingStore.all(this).forEach { root.addView(recordingRow(it)) }
        if (RecordingStore.all(this).isEmpty()) root.addView(tv("No recordings yet.", 15f, false, Color.GRAY))
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }

    private fun showRecording(item: RecordingStore.Item) {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(32)) }
        root.addView(header("Recording") { backToMain() })
        root.addView(spacer(8))
        root.addView(tv(item.name, 27f, true))
        root.addView(tv(formatDate(item.created) + "  •  " + duration(item), 13f, false, Color.GRAY))
        root.addView(spacer(18))
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(18), dp(24), dp(18), dp(24)); background = rounded(0xFF101116.toInt(), 26) }
        panel.addView(tv("▶", 58f, true, 0xFF7D89FF.toInt()).apply { setOnClickListener { play(item) } })
        panel.addView(tv("Tap to play", 13f, false, 0xFFB9BBC4.toInt()))
        root.addView(panel)
        root.addView(spacer(16))
        root.addView(button("Rename") { rename(item) })
        root.addView(button("Trim recording") { trim(item) })
        root.addView(button("Share") { share(item) })
        root.addView(button("Delete") { delete(item) })
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }

    private fun play(item: RecordingStore.Item) {
        try {
            if (playing?.location == item.location && player?.isPlaying == true) { player?.pause(); return }
            player?.release()
            player = MediaPlayer().apply {
                if (item.isUri) setDataSource(this@VoiceRecorderActivity, Uri.parse(item.location)) else setDataSource(item.location)
                setOnCompletionListener { playing = null }
                prepare(); start()
            }
            playing = item
        } catch (_: Exception) { toast("Couldn't play this recording") }
    }

    private fun rename(item: RecordingStore.Item) {
        val input = EditText(this).apply { setText(item.name); setSingleLine() }
        AlertDialog.Builder(this).setTitle("Rename recording").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            RecordingStore.rename(this, item, input.text.toString()); showHome()
        }.show()
    }

    private fun delete(item: RecordingStore.Item) {
        AlertDialog.Builder(this).setTitle("Delete recording?").setMessage("This permanently removes the audio file from your recording folder.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> RecordingStore.delete(this, item); showHome() }.show()
    }

    private fun share(item: RecordingStore.Item) {
        try {
            val uri = if (item.isUri) Uri.parse(item.location) else Uri.parse("content://" + packageName + ".recordings/" + Uri.encode(File(item.path).name))
            val i = Intent(Intent.ACTION_SEND).apply { type = "audio/mp4"; putExtra(Intent.EXTRA_STREAM, uri); clipData = ClipData.newRawUri("Recording", uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(Intent.createChooser(i, "Share recording"))
        } catch (_: Exception) { toast("Couldn't share this recording") }
    }

    private fun duration(item: RecordingStore.Item): String = try {
        val mp = MediaPlayer()
        if (item.isUri) mp.setDataSource(this, Uri.parse(item.location)) else mp.setDataSource(item.location)
        mp.prepare(); val sec = mp.duration / 1000; mp.release(); String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
    } catch (_: Exception) { "--:--" }

    private fun trim(item: RecordingStore.Item) {
        val durationSec = duration(item).let { it.split(":").let { p -> (p[0].toLongOrNull() ?: 0) * 60 + (p[1].toLongOrNull() ?: 0) } }
        if (durationSec <= 0) { toast("Couldn't read the recording length"); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), 0) }
        val start = EditText(this).apply { hint = "Start seconds"; inputType = 2; setText("0") }
        val end = EditText(this).apply { hint = "End seconds"; inputType = 2; setText(durationSec.toString()) }
        box.addView(start); box.addView(end)
        AlertDialog.Builder(this).setTitle("Trim recording").setMessage("Keep audio between these times.").setView(box).setNegativeButton("Cancel", null).setPositiveButton("Trim") { _, _ ->
            val s = start.text.toString().toLongOrNull() ?: 0L; val e = end.text.toString().toLongOrNull() ?: durationSec
            if (s < 0 || e <= s) { toast("End time must be after start time"); return@setPositiveButton }
            Thread { doTrim(item, s * 1_000_000L, e * 1_000_000L) }.start()
        }.show()
    }

    private fun doTrim(item: RecordingStore.Item, startUs: Long, endUs: Long) {
        val temp = File(cacheDir, "trim_${System.currentTimeMillis()}.m4a")
        try {
            val ex = MediaExtractor()
            if (item.isUri) ex.setDataSource(this, Uri.parse(item.location), null) else ex.setDataSource(item.location)
            var track = -1
            for (i in 0 until ex.trackCount) if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; break }
            if (track < 0) throw Exception("No audio track")
            ex.selectTrack(track)
            val mux = MediaMuxer(temp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outTrack = mux.addTrack(ex.getTrackFormat(track)); mux.start(); ex.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val buffer = java.nio.ByteBuffer.allocate(1024 * 1024); val info = android.media.MediaCodec.BufferInfo()
            while (true) { info.offset = 0; info.size = ex.readSampleData(buffer, 0); if (info.size < 0) break; val t = ex.sampleTime; if (t > endUs) break; if (t >= startUs) { info.presentationTimeUs = t - startUs; info.flags = ex.sampleFlags; mux.writeSampleData(outTrack, buffer, info) }; ex.advance() }
            mux.stop(); mux.release(); ex.release()
            val name = item.name + " (trimmed)"
            val outUri = StorageManager.createRecording(this, name)
            if (outUri == null) throw Exception("Recording storage is not linked")
            contentResolver.openOutputStream(outUri, "w")!!.use { out -> temp.inputStream().use { it.copyTo(out) } }
            RecordingStore.add(this, outUri.toString(), name)
            temp.delete()
            runOnUiThread { toast("Trimmed recording saved"); showHome() }
        } catch (_: Exception) { temp.delete(); runOnUiThread { toast("Trim failed") } }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 740 && grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            VoiceRecorderService.arm(this)
            if (pendingStartAfterPermission) {
                pendingStartAfterPermission = false
                handler.postDelayed({ VoiceRecorderService.startFromVisibleActivity(this); showHome() }, 300)
            } else {
                toast("Microphone ready. Your gesture can now start recording.")
                showHome()
            }
        } else if (requestCode == 740) {
            pendingStartAfterPermission = false
            toast("Microphone permission is required to record audio.")
        }
    }

    private fun startLoops() {
        handler.post(object : Runnable {
            override fun run() {
                if (isFinishing || !VoiceRecorderService.recording) return
                timer?.text = elapsed()
                val amp = VoiceRecorderService.maxAmplitude
                waveform?.let { for (i in 0 until it.childCount) { val v = it.getChildAt(i); val base = 8 + ((amp / 5000).coerceIn(0, 15) + (i % 5) * 4); v.layoutParams = (v.layoutParams as LinearLayout.LayoutParams).apply { height = dp(base) }; v.requestLayout() } }
                handler.postDelayed(this, 250)
            }
        })
    }

    private fun elapsed(): String { val sec = ((System.currentTimeMillis() - VoiceRecorderService.startedAt) / 1000).coerceAtLeast(0); return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60) }
    private fun formatDate(t: Long): String = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US).format(Date(t))
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
