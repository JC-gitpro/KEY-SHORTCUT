package com.example.keyshortcut

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Native microphone recorder used by KeyShortcut gestures. */
class VoiceRecorderService : Service() {
    companion object {
        const val ACTION_TOGGLE = "com.example.keyshortcut.voice.TOGGLE"
        const val ACTION_START = "com.example.keyshortcut.voice.START"
        const val ACTION_STOP = "com.example.keyshortcut.voice.STOP"
        const val ACTION_OPEN = "com.example.keyshortcut.voice.OPEN"
        const val ACTION_STATE = "com.example.keyshortcut.voice.STATE"
        const val ACTION_PAUSE = "com.example.keyshortcut.voice.PAUSE"
        const val ACTION_RESUME = "com.example.keyshortcut.voice.RESUME"
        const val ACTION_ARM = "com.example.keyshortcut.voice.ARM"
        const val EXTRA_STATE = "state"
        const val STATE_IDLE = "idle"
        const val STATE_RECORDING = "recording"
        const val STATE_PAUSED = "paused"

        @Volatile var paused = false
        @Volatile var maxAmplitude = 0

        @Volatile var instance: VoiceRecorderService? = null
        @Volatile var armed = false

        @Volatile var recording = false
        @Volatile var currentPath: String? = null
        @Volatile var startedAt: Long = 0L

        private const val CHANNEL = "keyshortcut_voice"
        private const val NOTIFICATION_ID = 4101
        private const val FINISHED_NOTIFICATION_ID = 4102

        fun arm(ctx: Context) {
            val i = Intent(ctx, VoiceRecorderService::class.java).setAction(ACTION_ARM)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) { e.printStackTrace() }
        }

        /** Starts recording directly from a visible VoiceRecorderActivity. */
        fun startFromVisibleActivity(ctx: Context) {
            val live = instance
            if (live != null) {
                live.armRecorder()
                live.startRecording()
                return
            }
            val i = Intent(ctx, VoiceRecorderService::class.java).setAction(ACTION_START)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) { e.printStackTrace() }
        }

        fun send(ctx: Context, action: String) {
            val live = instance
            if (live != null) {
                when (action) {
                    ACTION_TOGGLE -> if (recording) live.stopRecording() else live.startRecording()
                    ACTION_START -> if (!recording) live.startRecording()
                    ACTION_STOP -> if (recording) live.stopRecording()
                    ACTION_PAUSE -> live.pauseRecording()
                    ACTION_RESUME -> live.resumeRecording()
                    ACTION_OPEN -> live.openRecorder()
                }
                return
            }
            val i = Intent(ctx, VoiceRecorderService::class.java).setAction(action)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private var recorder: MediaRecorder? = null
    private var outputPfd: android.os.ParcelFileDescriptor? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (recording) {
                if (!paused) maxAmplitude = runCatching { recorder?.maxAmplitude ?: 0 }.getOrDefault(0)
                KeyComboService.instance?.updateRecorderPill(elapsedMs())
                handler.postDelayed(this, 500L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_START || action == ACTION_TOGGLE) {
            if (!recording) armRecorder()
        }
        when (action) {
            ACTION_TOGGLE -> if (recording) stopRecording() else startRecording()
            ACTION_START -> if (!recording) startRecording()
            ACTION_STOP -> if (recording) stopRecording()
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_ARM -> armRecorder()
            ACTION_OPEN -> openRecorder()
            null -> if (!recording) armRecorder()
        }
        return if (armed || recording) START_STICKY else START_NOT_STICKY
    }

    private fun armRecorder() {
        if (recording) return
        armed = true
        startForeground(NOTIFICATION_ID, armedNotification())
    }

    private fun startRecording() {
        if (recording) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            postStatusNotification("Microphone access is not ready. Open Voice Recorder and allow microphone access.")
            return
        }
        val base = "Recording - " + SimpleDateFormat("MMM d yyyy - h.mm a", Locale.US).format(Date())
        val uri = StorageManager.createRecording(this, base)
        if (uri == null) {
            val detail = StorageManager.lastError(this).ifBlank { "The selected recording folder is not writable." }
            postStatusNotification("Recording storage: $detail")
            return
        }
        try {
            val pfd = contentResolver.openFileDescriptor(uri, "w") ?: throw IllegalStateException("Could not open recording file")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(pfd.fileDescriptor)
            r.prepare()
            r.start()
            outputPfd = pfd
            recorder = r
            currentPath = uri.toString()
            startedAt = System.currentTimeMillis()
            paused = false
            maxAmplitude = 0
            recording = true
            armed = true
            startForeground(NOTIFICATION_ID, buildNotification())
            KeyComboService.instance?.showRecorderPill()
            handler.removeCallbacks(tick)
            handler.post(tick)
        } catch (e: Exception) {
            e.printStackTrace()
            try { outputPfd?.close() } catch (_: Exception) {}
            outputPfd = null
            if (uri != null) runCatching { StorageManager.delete(this, uri) }
            recording = false
            recorder = null
            currentPath = null
            if (armed) {
                startForeground(NOTIFICATION_ID, armedNotification())
            } else {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            postStatusNotification("Couldn't start recording. ${e.message ?: "Check microphone and storage access."}")
        }
    }

    private fun pauseRecording() {
        if (!recording || paused) return
        if (Build.VERSION.SDK_INT >= 24) {
            runCatching { recorder?.pause(); paused = true }
        }
    }

    private fun resumeRecording() {
        if (!recording || !paused) return
        if (Build.VERSION.SDK_INT >= 24) {
            runCatching { recorder?.resume(); paused = false }
        }
    }

    private fun stopRecording() {
        if (!recording) { stopSelf(); return }
        val location = currentPath
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { outputPfd?.close() } catch (_: Exception) {}
        outputPfd = null
        recording = false
        paused = false
        currentPath = null
        handler.removeCallbacks(tick)
        KeyComboService.instance?.hideRecorderPill()
        if (!location.isNullOrEmpty()) {
            RecordingStore.add(this, location, location.substringAfterLast('/').substringBeforeLast('.').ifBlank { "Recording" })
        }
        if (armed) {
            startForeground(NOTIFICATION_ID, armedNotification())
        } else {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        VoiceRecorderActivity.notifyRefresh(this)
        try {
            val n = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            n.notify(FINISHED_NOTIFICATION_ID, finishedNotification(location))
        } catch (_: Exception) {}
    }

    private fun elapsedMs(): Long = if (startedAt == 0L) 0L else System.currentTimeMillis() - startedAt

    private fun openRecorder() {
        try {
            val i = Intent(this, VoiceRecorderActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            startActivity(i)
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun postStatusNotification(message: String) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(FINISHED_NOTIFICATION_ID, baseBuilder()
                .setContentTitle("Voice Recorder")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(this, 23, Intent(this, VoiceRecorderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                .build())
        } catch (_: Exception) {}
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Voice Recorder", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun pending(action: String, id: Int): PendingIntent {
        val i = Intent(this, VoiceRecorderService::class.java).setAction(action)
        return PendingIntent.getService(this, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun baseBuilder(): android.app.Notification.Builder {
        return if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, CHANNEL)
        else android.app.Notification.Builder(this)
    }

    private fun armedNotification(): Notification = baseBuilder()
        .setContentTitle("Voice Recorder ready")
        .setContentText("Your KeyShortcut gesture can start recording")
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setOngoing(true)
        .setContentIntent(PendingIntent.getActivity(this, 24, Intent(this, VoiceRecorderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        .addAction(Notification.Action.Builder(null, "Open Recorder", PendingIntent.getActivity(this, 25, Intent(this, VoiceRecorderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)).build())
        .build()

    private fun buildNotification(): Notification = baseBuilder()
        .setContentTitle(if (paused) "Voice Recorder — Paused" else "Voice Recorder — Recording")
        .setContentText("Recording ${formatElapsed(elapsedMs())}")
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setOngoing(true)
        .setContentIntent(PendingIntent.getActivity(this, 20, Intent(this, VoiceRecorderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        .addAction(Notification.Action.Builder(null, if (paused) "Resume" else "Pause", pending(if (paused) ACTION_RESUME else ACTION_PAUSE, 21)).build())
        .addAction(Notification.Action.Builder(null, "Stop", pending(ACTION_STOP, 22)).build())
        .build()

    private fun finishedNotification(path: String?): Notification = baseBuilder()
        .setContentTitle("Recording saved")
        .setContentText(if (path.isNullOrEmpty()) "Open Voice Recorder" else "Recording saved to your selected folder")
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setAutoCancel(true)
        .setContentIntent(PendingIntent.getActivity(this, 22, Intent(this, VoiceRecorderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        .build()

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        if (recording) {
            try { recorder?.stop() } catch (_: Exception) {}
            try { recorder?.release() } catch (_: Exception) {}
            try { outputPfd?.close() } catch (_: Exception) {}
            outputPfd = null
            recorder = null
            recording = false
        }
        KeyComboService.instance?.hideRecorderPill()
        armed = false
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun formatElapsed(ms: Long): String {
        val total = ms / 1000
        return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
    }

}
