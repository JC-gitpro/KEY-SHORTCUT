package com.example.keyshortcut

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import java.util.UUID

/** Persistent user-selected recording folder using Android's Storage Access Framework. */
object StorageManager {
    private const val PREFS = "recording_storage"
    private const val KEY_TREE = "tree_uri"
    private const val KEY_LAST_ERROR = "last_error"

    fun treeUri(ctx: Context): Uri? = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_TREE, null)?.let { runCatching { Uri.parse(it) }.getOrNull() }

    /** Returns true only when the stored URI still has usable persisted write access. */
    fun isLinked(ctx: Context): Boolean = validate(ctx).ok

    fun setTreeUri(ctx: Context, uri: Uri) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TREE, uri.toString())
            .remove(KEY_LAST_ERROR)
            .apply()
    }

    fun clear(ctx: Context) {
        treeUri(ctx)?.let { old ->
            runCatching { ctx.contentResolver.releasePersistableUriPermission(old, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    data class Validation(val ok: Boolean, val message: String)

    /** Checks both the saved URI and actual write/delete access to the selected folder. */
    fun validate(ctx: Context): Validation {
        val tree = treeUri(ctx) ?: return Validation(false, "No recording folder is linked.")
        val persisted = ctx.contentResolver.persistedUriPermissions.firstOrNull { it.uri == tree }
        if (persisted == null || !persisted.isWritePermission) {
            val msg = "The recording-folder permission is no longer available. Link the folder again."
            saveError(ctx, msg)
            return Validation(false, msg)
        }
        return runCatching {
            val probeName = ".keyshortcut_${UUID.randomUUID()}"
            val probe = DocumentsContract.createDocument(ctx.contentResolver, tree, "application/octet-stream", probeName)
                ?: throw IllegalStateException("Android could not create a file in the selected folder.")
            DocumentsContract.deleteDocument(ctx.contentResolver, probe)
            saveError(ctx, "")
            Validation(true, "Recording folder is ready.")
        }.getOrElse {
            val msg = "The linked folder cannot be written to. Link the SD-card folder again."
            saveError(ctx, msg)
            Validation(false, msg)
        }
    }

    fun lastError(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_LAST_ERROR, "") ?: ""

    fun createRecording(ctx: Context, baseName: String): Uri? {
        val validation = validate(ctx)
        if (!validation.ok) return null
        val tree = treeUri(ctx) ?: return null
        return runCatching {
            DocumentsContract.createDocument(
                ctx.contentResolver,
                tree,
                "audio/mp4",
                safeName(baseName) + ".m4a"
            )
        }.onFailure { saveError(ctx, "Android could not create the recording file in the linked folder.") }
            .getOrNull()
    }

    fun delete(ctx: Context, uri: Uri): Boolean = runCatching {
        DocumentsContract.deleteDocument(ctx.contentResolver, uri)
    }.getOrDefault(false)

    fun rename(ctx: Context, uri: Uri, name: String): Uri? = runCatching {
        DocumentsContract.renameDocument(ctx.contentResolver, uri, safeName(name) + ".m4a")
    }.getOrNull()

    fun safeName(name: String): String {
        val cleaned = name.trim().replace(Regex("[\\/:*?\"<>|]"), "_")
        return cleaned.ifBlank { "Recording" }.take(100)
    }

    fun displayLocation(ctx: Context): String {
        val uri = treeUri(ctx) ?: return "Not linked"
        return runCatching {
            val doc = DocumentsContract.getTreeDocumentId(uri)
            val value = doc.substringAfterLast(':').replace('%2F', '/').replace('%2f', '/')
            if (value.isBlank()) "SD card" else value
        }.getOrDefault("SD card")
    }

    private fun saveError(ctx: Context, message: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LAST_ERROR, message).apply()
    }
}
