package com.example.keyshortcut

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.UUID

/**
 * SAF-backed recording storage.
 *
 * The user selects a writable folder (normally the microSD card root). KeyShortcut
 * then creates/uses:
 *
 *   <selected folder>/KeyShortcut/Recordings
 *
 * The original selected tree permission is kept separately from the actual
 * Recordings document URI. This is important on Samsung/Android because a child
 * folder URI is not itself a persisted tree permission.
 */
object StorageManager {
    private const val PREFS = "recording_storage"
    private const val KEY_ROOT_TREE = "root_tree_uri"
    private const val KEY_RECORDINGS = "recordings_uri"
    private const val KEY_LAST_ERROR = "last_error"

    private const val KEYSHORTCUT_DIR = "KeyShortcut"
    private const val RECORDINGS_DIR = "Recordings"

    private const val DOC_ID = "document_id"
    private const val DISPLAY_NAME = "display_name"
    private const val MIME_TYPE = "mime_type"

    data class Validation(val ok: Boolean, val message: String)

    fun treeUri(ctx: Context): Uri? = prefs(ctx)
        .getString(KEY_RECORDINGS, null)
        ?.let { runCatching { Uri.parse(it) }.getOrNull() }

    /** The URI on which the user granted the persistable tree permission. */
    private fun rootTreeUri(ctx: Context): Uri? = prefs(ctx)
        .getString(KEY_ROOT_TREE, null)
        ?.let { runCatching { Uri.parse(it) }.getOrNull() }

    /**
     * Called after ACTION_OPEN_DOCUMENT_TREE returns. It persists the grant and
     * immediately creates/locates KeyShortcut/Recordings inside the selected tree.
     */
    fun linkSelectedFolder(ctx: Context, selectedTree: Uri): Validation {
        return try {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            val persistedFlags = ctx.contentResolver.persistedUriPermissions
                .firstOrNull { it.uri == selectedTree }
                ?.let { (if (it.isReadPermission) Intent.FLAG_GRANT_READ_URI_PERMISSION else 0) or
                        (if (it.isWritePermission) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0) }
                ?: 0

            if (persistedFlags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION == 0) {
                ctx.contentResolver.takePersistableUriPermission(selectedTree, flags)
            }

            val permission = ctx.contentResolver.persistedUriPermissions
                .firstOrNull { it.uri == selectedTree }
            if (permission == null || !permission.isWritePermission) {
                return Validation(false, "Android did not give KeyShortcut write access to that folder. Select the SD-card folder again and allow access.")
            }

            val recordings = ensureRecordingsFolder(ctx, selectedTree)
            prefs(ctx).edit()
                .putString(KEY_ROOT_TREE, selectedTree.toString())
                .putString(KEY_RECORDINGS, recordings.toString())
                .remove(KEY_LAST_ERROR)
                .apply()

            validate(ctx)
        } catch (e: Exception) {
            val message = "Couldn't create KeyShortcut/Recordings there. ${e.message ?: "Choose a writable SD-card folder."}"
            saveError(ctx, message)
            Validation(false, message)
        }
    }

    /** Backward-compatible setter for older code. */
    fun setTreeUri(ctx: Context, uri: Uri) {
        val result = linkSelectedFolder(ctx, uri)
        if (!result.ok) saveError(ctx, result.message)
    }

    fun clear(ctx: Context) {
        rootTreeUri(ctx)?.let { old ->
            runCatching {
                ctx.contentResolver.releasePersistableUriPermission(
                    old,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
        }
        prefs(ctx).edit().clear().apply()
    }

    /** Checks the persisted grant and performs a real create/delete test. */
    fun validate(ctx: Context): Validation {
        val recordings = treeUri(ctx)
            ?: return Validation(false, "No recording folder is linked. Tap Link storage folder.")

        val root = rootTreeUri(ctx)
            ?: return Validation(false, "The SD-card permission is missing. Link the storage folder again.")

        val permission = ctx.contentResolver.persistedUriPermissions
            .firstOrNull { it.uri == root }
        if (permission == null || !permission.isWritePermission) {
            val msg = "The SD-card write permission is no longer available. Link the storage folder again."
            saveError(ctx, msg)
            return Validation(false, msg)
        }

        return try {
            val probeName = ".keyshortcut_${UUID.randomUUID()}"
            val probe = DocumentsContract.createDocument(
                ctx.contentResolver,
                recordings,
                "application/octet-stream",
                probeName
            ) ?: throw IllegalStateException("Android could not create a test file in KeyShortcut/Recordings.")

            val deleted = DocumentsContract.deleteDocument(ctx.contentResolver, probe)
            if (!deleted) throw IllegalStateException("Android created the test file but would not delete it.")

            saveError(ctx, "")
            Validation(true, "Recording folder is ready.")
        } catch (e: Exception) {
            val msg = "KeyShortcut/Recordings cannot be written on this SD card. ${e.message ?: "Select the SD-card folder again."}"
            saveError(ctx, msg)
            Validation(false, msg)
        }
    }

    fun lastError(ctx: Context): String = prefs(ctx)
        .getString(KEY_LAST_ERROR, "") ?: ""

    fun createRecording(ctx: Context, baseName: String): Uri? {
        val validation = validate(ctx)
        if (!validation.ok) return null

        val recordings = treeUri(ctx) ?: return null
        return runCatching {
            DocumentsContract.createDocument(
                ctx.contentResolver,
                recordings,
                "audio/mp4",
                safeName(baseName) + ".m4a"
            ) ?: throw IllegalStateException("Android could not create the recording file.")
        }.onFailure {
            saveError(ctx, "Android could not create the recording file in KeyShortcut/Recordings. ${it.message ?: "Check SD-card access."}")
        }.getOrNull()
    }

    fun delete(ctx: Context, uri: Uri): Boolean = runCatching {
        DocumentsContract.deleteDocument(ctx.contentResolver, uri)
    }.getOrDefault(false)

    fun rename(ctx: Context, uri: Uri, name: String): Uri? = runCatching {
        DocumentsContract.renameDocument(ctx.contentResolver, uri, safeName(name) + ".m4a")
    }.getOrNull()

    fun safeName(name: String): String {
        val cleaned = name.trim().replace(Regex("[\\/:*?\"<>|]"), "_")
        return cleaned.ifBlank { "Recording" }.take(100)
    }

    fun displayLocation(ctx: Context): String {
        val uri = treeUri(ctx) ?: return "Not linked"
        return runCatching {
            val id = DocumentsContract.getDocumentId(uri)
            val decoded = URLDecoder.decode(id.substringAfterLast(':'), StandardCharsets.UTF_8.name())
            if (decoded.isBlank()) "SD card / KeyShortcut / Recordings" else "SD card / $KEYSHORTCUT_DIR / $RECORDINGS_DIR"
        }.getOrDefault("SD card / $KEYSHORTCUT_DIR / $RECORDINGS_DIR")
    }

    /** Create or locate the requested child directory under a writable parent. */
    private fun ensureRecordingsFolder(ctx: Context, selectedTree: Uri): Uri {
        val selectedName = documentName(ctx, selectedTree)

        // If the user already selected a folder named Recordings, use it directly.
        if (selectedName.equals(RECORDINGS_DIR, ignoreCase = true)) {
            return selectedTree
        }

        // If the user selected KeyShortcut, create/locate Recordings directly inside it.
        if (selectedName.equals(KEYSHORTCUT_DIR, ignoreCase = true)) {
            val keyShortcutDoc = documentUriForTree(selectedTree)
            return findOrCreateDirectory(ctx, keyShortcutDoc, RECORDINGS_DIR)
        }

        // Otherwise treat the selected folder as the parent and create the requested structure.
        val keyShortcutDoc = findOrCreateDirectory(ctx, documentUriForTree(selectedTree), KEYSHORTCUT_DIR)
        return findOrCreateDirectory(ctx, keyShortcutDoc, RECORDINGS_DIR)
    }

    private fun findOrCreateDirectory(ctx: Context, parent: Uri, name: String): Uri {
        findChild(ctx, parent, name, DocumentsContract.Document.MIME_TYPE_DIR)?.let { return it }
        return DocumentsContract.createDocument(
            ctx.contentResolver,
            parent,
            DocumentsContract.Document.MIME_TYPE_DIR,
            name
        ) ?: throw IllegalStateException("Android could not create the $name folder.")
    }

    private fun findChild(ctx: Context, parent: Uri, name: String, mime: String): Uri? {
        val docId = runCatching { DocumentsContract.getDocumentId(parent) }.getOrNull() ?: return null
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(parent, docId)
        val projection = arrayOf(DOC_ID, DISPLAY_NAME, MIME_TYPE)
        ctx.contentResolver.query(children, projection, null, null, null)?.use { c ->
            val idCol = c.getColumnIndex(DOC_ID)
            val nameCol = c.getColumnIndex(DISPLAY_NAME)
            val mimeCol = c.getColumnIndex(MIME_TYPE)
            while (c.moveToNext()) {
                val childName = if (nameCol >= 0) c.getString(nameCol) else ""
                val childMime = if (mimeCol >= 0) c.getString(mimeCol) else ""
                if (childName.equals(name, ignoreCase = true) && childMime == mime) {
                    val childId = c.getString(idCol)
                    return DocumentsContract.buildDocumentUriUsingTree(parent, childId)
                }
            }
        }
        return null
    }

    private fun documentUriForTree(tree: Uri): Uri {
        val id = DocumentsContract.getTreeDocumentId(tree)
        return DocumentsContract.buildDocumentUriUsingTree(tree, id)
    }

    private fun documentName(ctx: Context, uri: Uri): String {
        val projection = arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        return ctx.contentResolver.query(uri, projection, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) ?: "" else ""
        } ?: ""
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun saveError(ctx: Context, message: String) {
        prefs(ctx).edit().putString(KEY_LAST_ERROR, message).apply()
    }
}
