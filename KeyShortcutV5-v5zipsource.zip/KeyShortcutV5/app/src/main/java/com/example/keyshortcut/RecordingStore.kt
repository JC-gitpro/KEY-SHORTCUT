package com.example.keyshortcut

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object RecordingStore {
    private const val PREFS = "voice_recordings"
    private const val KEY = "items"

    data class Item(val location: String, var name: String, val created: Long, val waveform: List<Int> = emptyList(), val transcript: String = "") {
        val isUri: Boolean get() = location.startsWith("content:")
        val uri: Uri? get() = if (isUri) Uri.parse(location) else null
        val path: String get() = location
    }

    fun all(ctx: Context): MutableList<Item> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val out = mutableListOf<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val location = o.optString("location", o.optString("path"))
            if (location.isBlank()) continue
            val exists = if (location.startsWith("content:")) {
                runCatching { ctx.contentResolver.openFileDescriptor(Uri.parse(location), "r")?.use { true } ?: false }.getOrDefault(false)
            } else File(location).exists()
            if (exists) {
                val ampsJson = o.optJSONArray("waveform") ?: JSONArray()
                val amps = (0 until ampsJson.length()).map { ampsJson.optInt(it, 0) }
                out.add(Item(location, o.optString("name", "Recording"), o.optLong("created", System.currentTimeMillis()), amps, o.optString("transcript", "")))
            }
        }
        out.sortByDescending { it.created }
        return out
    }

    fun add(ctx: Context, location: String, name: String, waveform: List<Int> = emptyList()) {
        val list = all(ctx)
        list.removeAll { it.location == location }
        list.add(0, Item(location, name.ifBlank { "Recording" }, System.currentTimeMillis(), waveform))
        save(ctx, list)
    }

    fun rename(ctx: Context, item: Item, name: String): Item? {
        val newName = name.ifBlank { "Recording" }
        var newLocation = item.location
        if (item.isUri) {
            newLocation = StorageManager.rename(ctx, Uri.parse(item.location), newName)?.toString() ?: item.location
        } else {
            val src = File(item.location)
            val dst = File(src.parentFile, StorageManager.safeName(newName) + ".m4a")
            if (src.exists() && src.absolutePath != dst.absolutePath) runCatching { src.renameTo(dst) }
            newLocation = dst.absolutePath
        }
        val list = all(ctx)
        list.find { it.location == item.location }?.let {
            it.name = newName
            list.remove(it)
            list.add(0, Item(newLocation, newName, item.created, item.waveform, item.transcript))
        }
        save(ctx, list)
        return Item(newLocation, newName, item.created, item.waveform, item.transcript)
    }

    fun updateTranscript(ctx: Context, location: String, transcript: String) {
        val list = all(ctx)
        val arr = JSONArray()
        list.forEach { item ->
            arr.put(JSONObject().put("location", item.location).put("name", item.name).put("created", item.created)
                .put("waveform", JSONArray(item.waveform)).put("transcript", if (item.location == location) transcript else item.transcript))
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun delete(ctx: Context, item: Item) {
        if (item.isUri) runCatching { StorageManager.delete(ctx, Uri.parse(item.location)) }
        else runCatching { File(item.location).delete() }
        val list = all(ctx)
        list.removeAll { it.location == item.location }
        save(ctx, list)
    }

    private fun save(ctx: Context, list: List<Item>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("location", it.location).put("name", it.name).put("created", it.created).put("waveform", JSONArray(it.waveform)).put("transcript", it.transcript)) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
