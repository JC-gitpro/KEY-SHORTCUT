# KeyShortcut v2

Native Android app (Kotlin, no libraries). Press both volume keys and run up to 3 programmable actions.

## Build + install from Windows

Run `BUILD-AND-INSTALL.cmd`. The script uses a valid lowercase Flutter project name explicitly, so the temporary build folder name cannot cause Flutter's Dart package-name error. It also performs real ADB device, install, package-resolution, and launch checks.

## Install (no build needed)

- On the phone: tap `KeyShortcut-v2.apk`, allow "install unknown apps", then Install
  (Play Protect: More details > Install anyway).
- From the PC: `adb install -r KeyShortcut-v2.apk`
- If Android says the update conflicts with an existing KeyShortcut, uninstall the old one first.

## First run

1. Open KeyShortcut and tap **Open Accessibility settings**.
   Turn on KeyShortcut (Installed apps > KeyShortcut). If it is greyed out:
   Settings > Apps > KeyShortcut > menu > Allow restricted settings.
2. On Action 1: **Choose app**, then optionally **Record controls**.
3. Unlock the phone and press both volume keys: hold, double tap, or triple tap.

## Recording controls

Choose an app on the action, tap **Record controls**. The app opens with a dim layer on top.
Tap the control you want: it is highlighted and captured, not pressed. Repeat for more controls.
Need to move to another screen first? Tap **Interact**, navigate, then tap **Record** and continue.
Tap **Done** to save. Controls run top to bottom when the action runs.

## Source

`app/src/main/java/com/example/keyshortcut/`: Cfg.kt (settings), KeyComboService.kt (gestures,
runner, banner, recorder), MainActivity.kt (UI). Standard Gradle layout, so it also opens in
Android Studio.
