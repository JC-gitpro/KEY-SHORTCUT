package com.example.keyshortcut

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.ActivityManager
import android.app.KeyguardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

private typealias Step = (ok: () -> Unit, fail: (String) -> Unit) -> Unit

/**
 * The one native service. It:
 *  - watches the hardware keys for  Hold / Double tap / Triple tap  of the button combination
 *  - runs the configured action (open app, tap recorded controls, close app)
 *  - shows an iPhone-style banner at the top of the screen while it runs
 *  - lets the user record controls by tapping them inside the real app
 */
class KeyComboService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: KeyComboService? = null
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var cfg = JSONObject()

    // Keeps a strong reference: SharedPreferences only holds listeners weakly.
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        cfg = Cfg.load(this)
    }

    // ───────────────────────── lifecycle ─────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cfg = Cfg.load(this)
        getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE)
            .registerOnSharedPreferenceChangeListener(prefListener)
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        instance = null
        try {
            getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE)
                .unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (e: Exception) {
        }
        runToken++
        stopRecordingViews()
        val p = pill
        pill = null
        if (p != null) {
            try {
                wm.removeView(p)
            } catch (e: Exception) {
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ───────────────────────── gesture detection ─────────────────────────

    private inner class Combo(val profile: String, val a: Int, val b: Int) {
        var aDown = false
        var bDown = false
        var aT = 0L
        var bT = 0L
        var active = false
        var swallow = false
        var holdFired = false
        var taps = 0
        var holdTask: Runnable? = null
        var tapTask: Runnable? = null

        fun involves(code: Int) = code == a || code == b

        fun reset() {
            aDown = false
            bDown = false
            active = false
            swallow = false
            holdFired = false
            taps = 0
            holdTask?.let { ui.removeCallbacks(it) }
            tapTask?.let { ui.removeCallbacks(it) }
        }
    }

    private val combos = listOf(
        Combo("vol", KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN),
        Combo("power", KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_POWER)
    )

    private fun profileEnabled(key: String): Boolean = try {
        Cfg.profile(cfg, key).optBoolean("enabled", false)
    } catch (e: Exception) {
        false
    }

    private fun holdMs(): Long = cfg.optInt("holdMs", 1200).toLong().coerceIn(400L, 4000L)

    override fun onKeyEvent(event: KeyEvent): Boolean {
        var consume = false
        for (c in combos) {
            if (c.involves(event.keyCode) && handle(c, event)) consume = true
        }
        return consume
    }

    private fun handle(c: Combo, e: KeyEvent): Boolean {
        if (!profileEnabled(c.profile)) {
            c.reset()
            return false
        }
        val down = e.action == KeyEvent.ACTION_DOWN
        if (e.keyCode == c.a) {
            if (down && !c.aDown) c.aT = e.eventTime
            c.aDown = down
        } else {
            if (down && !c.bDown) c.bT = e.eventTime
            c.bDown = down
        }

        val both = c.aDown && c.bDown && abs(c.aT - c.bT) < 500

        if (!c.active && both) {
            // Both buttons are now down together: a new press of the combination begins.
            c.active = true
            c.swallow = true
            c.holdFired = false
            c.tapTask?.let { ui.removeCallbacks(it) }
            val hold = Runnable {
                if (c.active) {
                    c.holdFired = true
                    c.taps = 0
                    fire(c.profile, 0)
                }
            }
            c.holdTask = hold
            ui.postDelayed(hold, holdMs())
        } else if (c.active && !(c.aDown && c.bDown)) {
            // The press ended.
            c.active = false
            c.holdTask?.let { ui.removeCallbacks(it) }
            if (c.holdFired) {
                c.taps = 0
            } else {
                c.taps++
                val task = Runnable {
                    val n = c.taps
                    c.taps = 0
                    // A single tap does nothing on purpose.
                    if (n == 2) fire(c.profile, 1) else if (n == 3) fire(c.profile, 2)
                }
                c.tapTask = task
                ui.postDelayed(task, 420L)
            }
        }

        val result = c.swallow
        if (!c.aDown && !c.bDown) c.swallow = false
        return result
    }

    private fun keyguardLocked(): Boolean {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isKeyguardLocked
    }

    private fun fire(profileKey: String, gesture: Int) {
        try {
            val prof = Cfg.profile(cfg, profileKey)
            if (!prof.optBoolean("enabled", false)) return
            if (cfg.optBoolean("unlockedOnly", true) && keyguardLocked()) return
            val idx = prof.getJSONArray("assign").optInt(gesture, -1)
            val acts = prof.getJSONArray("actions")
            if (idx < 0 || idx >= acts.length()) return
            val a = acts.getJSONObject(idx)
            if (!a.optBoolean("enabled", true)) return
            runAction(a, idx, Cfg.GESTURES[gesture])
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // ───────────────────────── running an action ─────────────────────────

    private var runToken = 0

    fun runAction(a: JSONObject, index: Int, via: String) {
        val token = ++runToken
        val pkg = a.optString("pkg")
        val label = a.optString("label")
        val controls = a.optJSONArray("controls") ?: JSONArray()
        val ts = a.optString("tailscale", "none")
        val close = a.optBoolean("closeApp", false)
        val title = if (label.isNotEmpty()) label else "Action ${index + 1}"

        if (pkg.isEmpty() && controls.length() == 0 && ts == "none" && !close) {
            showBanner("Action ${index + 1}", null, via)
            finishBanner("Nothing programmed yet", false)
            return
        }
        if (pkg.isNotEmpty() && !isInstalled(pkg)) {
            showBanner("Action ${index + 1}", null, via)
            finishBanner("The selected app is no longer installed", false)
            return
        }

        showBanner(title, if (pkg.isEmpty()) null else pkg, via)
        val target = if (pkg.isNotEmpty()) pkg else (rootInActiveWindow?.packageName?.toString() ?: "")

        val steps = ArrayList<Step>()

        if (ts == "on" || ts == "off") {
            steps.add { ok, _ ->
                setSub(if (ts == "on") "Turning Tailscale on" else "Turning Tailscale off")
                tailscale(ts == "on")
                ui.postDelayed({ ok() }, 900L)
            }
        }

        if (pkg.isNotEmpty()) {
            steps.add { ok, fail ->
                setSub("Opening $title")
                val li = packageManager.getLaunchIntentForPackage(pkg)
                if (li == null) {
                    fail("Can't open $title")
                } else {
                    li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    startActivity(li)
                    waitForeground(token, pkg, 6000L, { ui.postDelayed({ ok() }, 600L) }, { fail("Couldn't open $title") })
                }
            }
        }

        for (i in 0 until controls.length()) {
            val c = controls.getJSONObject(i)
            steps.add { ok, fail ->
                setSub("Tapping \"${c.optString("label")}\"")
                tapControl(token, c, target, 8000L, { ui.postDelayed({ ok() }, 450L) }, { fail("Couldn't find \"${c.optString("label")}\"") })
            }
        }

        if (close && target.isNotEmpty()) {
            steps.add { ok, _ ->
                setSub("Closing the app")
                performGlobalAction(GLOBAL_ACTION_HOME)
                ui.postDelayed({
                    closePackage(target)
                    ok()
                }, 700L)
            }
        }

        runSteps(token, steps, 0)
    }

    private fun runSteps(token: Int, steps: List<Step>, i: Int) {
        if (token != runToken) return
        if (i >= steps.size) {
            finishBanner("Done", true)
            return
        }
        steps[i]({ runSteps(token, steps, i + 1) }, { msg -> if (token == runToken) finishBanner(msg, false) })
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getApplicationInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun tailscale(on: Boolean) {
        try {
            val i = Intent(if (on) "com.tailscale.ipn.CONNECT_VPN" else "com.tailscale.ipn.DISCONNECT_VPN")
            i.component = ComponentName("com.tailscale.ipn", "com.tailscale.ipn.IPNReceiver")
            sendBroadcast(i)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun closePackage(pkg: String) {
        try {
            (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun waitForeground(token: Int, pkg: String, timeout: Long, ok: () -> Unit, fail: () -> Unit) {
        val end = SystemClock.uptimeMillis() + timeout
        val poll = object : Runnable {
            override fun run() {
                if (token != runToken) return
                if (rootInActiveWindow?.packageName?.toString() == pkg) {
                    ok()
                    return
                }
                if (SystemClock.uptimeMillis() > end) {
                    fail()
                    return
                }
                ui.postDelayed(this, 250L)
            }
        }
        ui.postDelayed(poll, 300L)
    }

    private fun tapControl(token: Int, c: JSONObject, pkg: String, timeout: Long, ok: () -> Unit, fail: () -> Unit) {
        val end = SystemClock.uptimeMillis() + timeout
        val poll = object : Runnable {
            override fun run() {
                if (token != runToken) return
                val root = rootInActiveWindow
                if (root != null && (pkg.isEmpty() || root.packageName?.toString() == pkg) && clickMatching(root, c)) {
                    ok()
                    return
                }
                if (SystemClock.uptimeMillis() > end) {
                    // Last resort: the screen position that was recorded.
                    if (c.has("x") && c.has("y") && tapAt(c.getDouble("x"), c.getDouble("y"))) ok() else fail()
                    return
                }
                ui.postDelayed(this, 250L)
            }
        }
        poll.run()
    }

    private fun collect(root: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        val stack = ArrayList<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty() && out.size < 4000) {
            val n = stack.removeAt(stack.size - 1)
            out.add(n)
            for (i in 0 until n.childCount) {
                val ch = n.getChild(i)
                if (ch != null) stack.add(ch)
            }
        }
    }

    private fun labelsOf(n: AccessibilityNodeInfo): List<String> {
        val out = ArrayList<String>()
        val t = n.text?.toString()
        if (!t.isNullOrBlank()) out.add(t.trim())
        val d = n.contentDescription?.toString()
        if (!d.isNullOrBlank()) out.add(d.trim())
        return out
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 7) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            depth++
        }
        return false
    }

    private fun clickMatching(root: AccessibilityNodeInfo, c: JSONObject): Boolean {
        val text = c.optString("text").trim()
        val desc = c.optString("desc").trim()
        val id = c.optString("id")
        val nodes = ArrayList<AccessibilityNodeInfo>()
        collect(root, nodes)
        val visible = nodes.filter { it.isVisibleToUser }
        val wanted = listOf(text, desc).filter { it.isNotEmpty() }

        for (w in wanted) for (n in visible) {
            if (labelsOf(n).any { it.equals(w, true) } && click(n)) return true
        }
        if (id.isNotEmpty()) for (n in visible) {
            if (n.viewIdResourceName == id && click(n)) return true
        }
        for (w in wanted) if (w.length >= 2) for (n in visible) {
            if (labelsOf(n).any { it.contains(w, true) } && click(n)) return true
        }
        return false
    }

    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return dm
    }

    private fun tapAt(fx: Double, fy: Double): Boolean {
        return try {
            val dm = realMetrics()
            val path = Path()
            path.moveTo((fx * dm.widthPixels).toFloat(), (fy * dm.heightPixels).toFloat())
            val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
            val g = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }

    // ───────────────────────── top banner ─────────────────────────

    private var pill: LinearLayout? = null
    private var pillIcon: FrameLayout? = null
    private var pillTitle: TextView? = null
    private var pillSub: TextView? = null
    private val hideTask = Runnable { hideBanner() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun bannerOn() = cfg.optBoolean("banner", true)

    fun showBanner(title: String, pkg: String?, sub: String) {
        if (!bannerOn()) return
        try {
            ui.removeCallbacks(hideTask)
            if (pill == null) createPill()
            pillTitle?.text = title
            pillSub?.text = sub
            pillSub?.setTextColor(0xFFB8B8C0.toInt())
            setPillIcon(pkg)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setSub(sub: String) {
        pillSub?.text = sub
    }

    fun finishBanner(msg: String, ok: Boolean) {
        if (!bannerOn()) {
            if (!ok) Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            return
        }
        try {
            if (pill == null) createPill()
            pillSub?.text = (if (ok) "\u2713 " else "\u26A0 ") + msg
            pillSub?.setTextColor(if (ok) 0xFF7CE38B.toInt() else 0xFFFFB454.toInt())
            ui.removeCallbacks(hideTask)
            ui.postDelayed(hideTask, if (ok) 1500L else 3500L)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideBanner() {
        val p = pill ?: return
        pill = null
        pillIcon = null
        pillTitle = null
        pillSub = null
        p.animate().alpha(0f).translationY(-dp(60).toFloat()).setDuration(220L).withEndAction {
            try {
                wm.removeView(p)
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun createPill() {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.HORIZONTAL
        p.gravity = Gravity.CENTER_VERTICAL
        p.setPadding(dp(12), dp(10), dp(22), dp(10))
        p.minimumWidth = dp(240)
        val bg = GradientDrawable()
        bg.setColor(0xF2121214.toInt())
        bg.setCornerRadius(dp(32).toFloat())
        p.background = bg

        val holder = FrameLayout(this)
        holder.layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, 0, 0)

        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.maxWidth = dp(230)

        val s = TextView(this)
        s.textSize = 13f
        s.maxLines = 1
        s.ellipsize = TextUtils.TruncateAt.END
        s.maxWidth = dp(230)

        col.addView(t)
        col.addView(s)
        p.addView(holder)
        p.addView(col)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = statusBarHeight() + dp(4)
        wm.addView(p, lp)

        pill = p
        pillIcon = holder
        pillTitle = t
        pillSub = s
        p.alpha = 0f
        p.translationY = -dp(60).toFloat()
        p.animate().alpha(1f).translationY(0f).setDuration(260L).start()
    }

    private fun setPillIcon(pkg: String?) {
        val h = pillIcon ?: return
        h.removeAllViews()
        val d = try {
            if (pkg.isNullOrEmpty()) null else packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }
        if (d != null) {
            val iv = ImageView(this)
            iv.setImageDrawable(d)
            h.addView(iv, FrameLayout.LayoutParams(dp(42), dp(42)))
        } else {
            val tv = TextView(this)
            tv.text = "\u26A1"
            tv.gravity = Gravity.CENTER
            tv.textSize = 20f
            tv.setTextColor(Color.WHITE)
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(0xFF4F6BED.toInt())
            tv.background = bg
            h.addView(tv, FrameLayout.LayoutParams(dp(42), dp(42)))
        }
    }

    // ───────────────────────── recording controls ─────────────────────────

    private var recDim: View? = null
    private var recDimLp: WindowManager.LayoutParams? = null
    private var recPill: LinearLayout? = null
    private var recTitle: TextView? = null
    private var recHint: TextView? = null
    private var recInteractBtn: TextView? = null
    private var recProfile = "vol"
    private var recIndex = 0
    private var recPkg = ""
    private var recorded = JSONArray()
    private var recInteracting = false

    fun startRecording(profile: String, index: Int, pkg: String) {
        stopRecordingViews()
        hideBanner()
        recProfile = profile
        recIndex = index
        recPkg = pkg
        recorded = JSONArray()
        recInteracting = false

        // Full-screen layer that catches your taps so nothing in the app is actually pressed.
        val dim = View(this)
        dim.setBackgroundColor(0x33000000)
        dim.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_UP) onRecordTouch(ev.rawX.toInt(), ev.rawY.toInt())
            true
        }
        val dlp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(dim, dlp)
        recDim = dim
        recDimLp = dlp

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(12), dp(18), dp(12))
        val bg = GradientDrawable()
        bg.setColor(0xF2121214.toInt())
        bg.setCornerRadius(dp(26).toFloat())
        box.background = bg

        val title = TextView(this)
        title.setTextColor(Color.WHITE)
        title.textSize = 15f
        title.setTypeface(title.typeface, Typeface.BOLD)
        val hint = TextView(this)
        hint.setTextColor(0xFFB8B8C0.toInt())
        hint.textSize = 12f
        box.addView(title)
        box.addView(hint)

        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.setPadding(0, dp(8), 0, 0)
        val interact = chip("Interact") { toggleInteract() }
        chips.addView(interact)
        chips.addView(chip("Undo") { undoRecord() })
        chips.addView(chip("Done") { finishRecording(true) })
        chips.addView(chip("Cancel") { finishRecording(false) })
        box.addView(chips)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = statusBarHeight() + dp(4)
        wm.addView(box, lp)

        recPill = box
        recTitle = title
        recHint = hint
        recInteractBtn = interact
        refreshRecordText()
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(Color.WHITE)
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        val bg = GradientDrawable()
        bg.setColor(0xFF2C2C30.toInt())
        bg.setCornerRadius(dp(16).toFloat())
        t.background = bg
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.rightMargin = dp(6)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun refreshRecordText() {
        val n = recorded.length()
        if (recInteracting) {
            recTitle?.text = "Interact mode"
            recHint?.text = "Go to the screen you need, then tap Record."
            recInteractBtn?.text = "Record"
        } else {
            recTitle?.text = if (n == 0) "Tap a control to record it" else "$n control" + (if (n == 1) "" else "s") + " recorded"
            recHint?.text = "Your taps are captured, not pressed. Tap Done when finished."
            recInteractBtn?.text = "Interact"
        }
    }

    private fun toggleInteract() {
        val dim = recDim ?: return
        val lp = recDimLp ?: return
        recInteracting = !recInteracting
        lp.flags = if (recInteracting) {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        }
        try {
            wm.updateViewLayout(dim, lp)
        } catch (e: Exception) {
        }
        refreshRecordText()
    }

    private fun undoRecord() {
        val n = recorded.length()
        if (n > 0) recorded.remove(n - 1)
        refreshRecordText()
    }

    private fun onRecordTouch(x: Int, y: Int) {
        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() == packageName) {
            recHint?.text = "Open the app first, then tap a control."
            return
        }
        val node = nodeAt(root, x, y)
        if (node == null) {
            recHint?.text = "Nothing selectable at that spot. Try again."
            return
        }
        val ctl = describe(node)
        recorded.put(ctl)
        val r = Rect()
        node.getBoundsInScreen(r)
        flashRect(r)
        refreshRecordText()
        recHint?.text = "Recorded: " + ctl.optString("label")
    }

    /** The smallest visible node under the finger that is clickable or has a name. */
    private fun nodeAt(root: AccessibilityNodeInfo, x: Int, y: Int): AccessibilityNodeInfo? {
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all)
        var best: AccessibilityNodeInfo? = null
        var bestArea = Long.MAX_VALUE
        val r = Rect()
        for (n in all) {
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(r)
            if (!r.contains(x, y)) continue
            val useful = n.isClickable || !n.text.isNullOrEmpty() ||
                !n.contentDescription.isNullOrEmpty() || !n.viewIdResourceName.isNullOrEmpty()
            if (!useful) continue
            val area = r.width().toLong() * r.height().toLong()
            if (area <= bestArea) {
                best = n
                bestArea = area
            }
        }
        return best
    }

    private fun firstLabel(n: AccessibilityNodeInfo?, depth: Int): Pair<String, String> {
        if (n == null || depth > 3) return Pair("", "")
        val t = n.text?.toString()?.trim().orEmpty()
        val d = n.contentDescription?.toString()?.trim().orEmpty()
        if (t.isNotEmpty() || d.isNotEmpty()) return Pair(t, d)
        for (i in 0 until n.childCount) {
            val res = firstLabel(n.getChild(i), depth + 1)
            if (res.first.isNotEmpty() || res.second.isNotEmpty()) return res
        }
        return Pair("", "")
    }

    private fun describe(node: AccessibilityNodeInfo): JSONObject {
        var text = node.text?.toString()?.trim().orEmpty()
        var desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isEmpty() && desc.isEmpty()) {
            val p = firstLabel(node, 0)
            text = p.first
            desc = p.second
        }
        val id = node.viewIdResourceName.orEmpty()
        val cls = node.className?.toString().orEmpty()
        val label = when {
            text.isNotEmpty() -> text
            desc.isNotEmpty() -> desc
            id.isNotEmpty() -> id.substringAfterLast('/')
            else -> cls.substringAfterLast('.').ifEmpty { "control" }
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        val dm = realMetrics()
        val o = JSONObject()
        o.put("label", label.take(60))
        o.put("text", text)
        o.put("desc", desc)
        o.put("id", id)
        o.put("cls", cls)
        o.put("x", r.centerX().toDouble() / dm.widthPixels)
        o.put("y", r.centerY().toDouble() / dm.heightPixels)
        return o
    }

    private fun flashRect(r: Rect) {
        try {
            val v = View(this)
            val g = GradientDrawable()
            g.setColor(0x334F6BED)
            g.setStroke(dp(3), 0xFF4F6BED.toInt())
            g.setCornerRadius(dp(6).toFloat())
            v.background = g
            val lp = WindowManager.LayoutParams(
                r.width().coerceAtLeast(dp(12)),
                r.height().coerceAtLeast(dp(12)),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = r.left
            lp.y = r.top
            wm.addView(v, lp)
            ui.postDelayed({
                try {
                    wm.removeView(v)
                } catch (e: Exception) {
                }
            }, 700L)
        } catch (e: Exception) {
        }
    }

    private fun stopRecordingViews() {
        val d = recDim
        val p = recPill
        recDim = null
        recDimLp = null
        recPill = null
        recTitle = null
        recHint = null
        recInteractBtn = null
        if (d != null) {
            try {
                wm.removeView(d)
            } catch (e: Exception) {
            }
        }
        if (p != null) {
            try {
                wm.removeView(p)
            } catch (e: Exception) {
            }
        }
    }

    private fun finishRecording(save: Boolean) {
        val added = recorded
        stopRecordingViews()
        if (save && added.length() > 0) {
            try {
                val c = Cfg.load(this)
                val acts = Cfg.profile(c, recProfile).getJSONArray("actions")
                val a = acts.getJSONObject(recIndex)
                val list = a.getJSONArray("controls")
                for (i in 0 until added.length()) list.put(added.getJSONObject(i))
                Cfg.save(this, c)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // Bring KeyShortcut back to the front so you can see what was saved.
        try {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(i)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
