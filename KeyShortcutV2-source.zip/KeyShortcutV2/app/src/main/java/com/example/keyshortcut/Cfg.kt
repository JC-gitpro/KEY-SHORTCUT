package com.example.keyshortcut

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * All settings live in one JSON document in SharedPreferences, so they survive
 * closing the app, rebooting, and reinstalling over the top.
 *
 * {
 *   unlockedOnly, banner, holdMs,
 *   profiles: {
 *     vol:   { enabled, assign:[gesture -> action index], actions:[3 x action] },
 *     power: { ... same ... }            // Volume Up + Power (best effort)
 *   }
 * }
 * action = { enabled, pkg, label, tailscale: none|on|off, closeApp, controls:[ control ] }
 * control = { label, text, desc, id, cls, x, y }
 */
object Cfg {
    const val PREFS = "keyshortcut2"
    val GESTURES = arrayOf("Hold", "Double tap", "Triple tap")

    fun newAction(): JSONObject = JSONObject()
        .put("enabled", true)
        .put("pkg", "")
        .put("label", "")
        .put("tailscale", "none")
        .put("closeApp", false)
        .put("controls", JSONArray())

    private fun newProfile(enabled: Boolean): JSONObject {
        val acts = JSONArray()
        for (i in 0 until 3) acts.put(newAction())
        val assign = JSONArray()
        for (i in 0 until 3) assign.put(i)
        return JSONObject().put("enabled", enabled).put("assign", assign).put("actions", acts)
    }

    fun load(ctx: Context): JSONObject {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("config", null)
        val cfg = try {
            if (raw == null) JSONObject() else JSONObject(raw)
        } catch (e: Exception) {
            JSONObject()
        }
        if (!cfg.has("unlockedOnly")) cfg.put("unlockedOnly", true)
        if (!cfg.has("banner")) cfg.put("banner", true)
        if (!cfg.has("holdMs")) cfg.put("holdMs", 1200)

        var profs = cfg.optJSONObject("profiles")
        if (profs == null) {
            profs = JSONObject()
            cfg.put("profiles", profs)
        }
        if (!profs.has("vol")) profs.put("vol", newProfile(true))
        if (!profs.has("power")) profs.put("power", newProfile(false))
        repair(profs.getJSONObject("vol"))
        repair(profs.getJSONObject("power"))
        return cfg
    }

    /** Makes sure a profile always has exactly 3 well-formed actions and 3 assignments. */
    private fun repair(p: JSONObject) {
        var acts = p.optJSONArray("actions")
        if (acts == null) {
            acts = JSONArray()
            p.put("actions", acts)
        }
        while (acts.length() < 3) acts.put(newAction())
        for (i in 0 until 3) {
            val a = acts.getJSONObject(i)
            if (!a.has("enabled")) a.put("enabled", true)
            if (!a.has("pkg")) a.put("pkg", "")
            if (!a.has("label")) a.put("label", "")
            if (!a.has("tailscale")) a.put("tailscale", "none")
            if (!a.has("closeApp")) a.put("closeApp", false)
            if (a.optJSONArray("controls") == null) a.put("controls", JSONArray())
        }
        var asg = p.optJSONArray("assign")
        if (asg == null) {
            asg = JSONArray()
            p.put("assign", asg)
        }
        while (asg.length() < 3) asg.put(asg.length())
        if (!p.has("enabled")) p.put("enabled", false)
    }

    fun save(ctx: Context, cfg: JSONObject) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("config", cfg.toString()).apply()
    }

    fun profile(cfg: JSONObject, key: String): JSONObject =
        cfg.getJSONObject("profiles").getJSONObject(key)
}
