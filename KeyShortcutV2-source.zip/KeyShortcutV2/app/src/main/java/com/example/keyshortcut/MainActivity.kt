package com.example.keyshortcut

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/** Native KeyShortcut configuration UI. */
class MainActivity : Activity() {
    private var cfg = JSONObject()
    private var profile = "vol"
    private var scroll: ScrollView? = null
    private var editingIndex = -1

    override fun onResume() {
        super.onResume()
        cfg = Cfg.load(this)
        if (editingIndex >= 0) showEditor(editingIndex) else showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun save() { Cfg.save(this, cfg) }
    private fun prof(): JSONObject = Cfg.profile(cfg, profile)

    private fun newPage(title: String): LinearLayout {
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(40))
        val t = label(title, 28f, true)
        t.setPadding(0, 0, 0, dp(12))
        content.addView(t)
        val sv = ScrollView(this)
        sv.addView(content)
        setContentView(sv)
        scroll = sv
        return content
    }

    private fun label(s: String, size: Float = 16f, bold: Boolean = false, color: Int = Color.BLACK): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun btn(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setAllCaps(false)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#EEF0F6"))
        bg.setCornerRadius(dp(16).toFloat())
        c.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        c.layoutParams = lp
        return c
    }

    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun weighted(v: View): View { v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); return v }
    private fun spacer(h: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h)) }

    private fun loadIcon(pkg: String?): Drawable? = try {
        if (pkg.isNullOrEmpty()) null else packageManager.getApplicationIcon(pkg)
    } catch (_: Exception) { null }

    private fun iconView(pkg: String?, sizeDp: Int): View {
        val d = loadIcon(pkg)
        val lp = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply { rightMargin = dp(10) }
        if (d != null) return ImageView(this).apply { setImageDrawable(d); layoutParams = lp }
        return TextView(this).apply {
            text = "⚡"; textSize = sizeDp * .42f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#9AA0B4")) }
            layoutParams = lp
        }
    }

    private fun isInstalled(pkg: String): Boolean = try { packageManager.getApplicationInfo(pkg, 0); true } catch (_: Exception) { false }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = android.content.ComponentName(this, KeyComboService::class.java)
        return enabled.contains(cn.flattenToString()) || enabled.contains(cn.flattenToShortString())
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun showHome() {
        editingIndex = -1
        val c = newPage("KeyShortcut")
        c.addView(accessCard())

        val tabs = row()
        tabs.addView(weighted(btn((if (profile == "vol") "● " else "") + "Volume Up + Down") { profile = "vol"; showHome() }))
        tabs.addView(weighted(btn((if (profile == "power") "● " else "") + "Volume Up + Power") { profile = "power"; showHome() }))
        c.addView(tabs)
        c.addView(profileCard())
        c.addView(assignCard())

        val head = label("Actions", 20f, true)
        head.setPadding(0, dp(8), 0, dp(8))
        c.addView(head)

        val acts = prof().getJSONArray("actions")
        for (i in 0 until acts.length()) c.addView(actionCard(i))
        c.addView(btn("＋ Add action") { addAction() })
        c.addView(settingsCard())
    }

    private fun accessCard(): LinearLayout {
        val on = isServiceEnabled()
        val k = card()
        k.background = GradientDrawable().apply { setColor(Color.parseColor(if (on) "#DDF3E1" else "#FBDADA")); setCornerRadius(dp(16).toFloat()) }
        k.addView(label(if (on) "Accessibility service is on" else "Accessibility service is OFF", 17f, true))
        k.addView(label(if (on) "Your shortcuts work from any app." else "Turn on KeyShortcut in Accessibility settings before testing gestures.", 13f))
        if (!on) k.addView(btn("Open Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        return k
    }

    private fun profileCard(): LinearLayout {
        val p = prof(); val k = card(); val head = row(); head.gravity = Gravity.CENTER_VERTICAL
        val title = label(if (profile == "vol") "Volume Up + Volume Down" else "Volume Up + Power", 17f, true)
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); head.addView(title)
        val sw = Switch(this); sw.isChecked = p.optBoolean("enabled", false); sw.setOnCheckedChangeListener { _, v -> p.put("enabled", v); save() }; head.addView(sw)
        k.addView(head)
        k.addView(label(if (profile == "vol") "Tap, hold, double tap, or triple tap both buttons together." else "Best effort only. Android/Samsung may reserve the power button.", 13f))
        return k
    }

    private fun actionNames(): Array<String> {
        val acts = prof().getJSONArray("actions")
        val out = ArrayList<String>(); out.add("Not assigned"); out.add("Selection menu")
        for (i in 0 until acts.length()) out.add("Action ${i + 1}: " + actionTitle(acts.getJSONObject(i), i))
        return out.toTypedArray()
    }

    private fun assignCard(): LinearLayout {
        val p = prof(); val asg = p.getJSONArray("assign"); val k = card()
        k.addView(label("Gesture assignment", 17f, true))
        k.addView(label("Each gesture can run any action, or open a selection menu. Assignments are independent; actions can be reused.", 13f))
        k.addView(spacer(6))
        val options = actionNames()
        for (g in Cfg.GESTURES.indices) {
            val r = row(); r.gravity = Gravity.CENTER_VERTICAL
            val name = label(Cfg.GESTURES[g], 15f, true); name.layoutParams = LinearLayout.LayoutParams(dp(105), ViewGroup.LayoutParams.WRAP_CONTENT); r.addView(name)
            val sp = Spinner(this); sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
            val current = asg.optInt(g, Cfg.UNASSIGNED)
            sp.setSelection(when { current == Cfg.SELECTION_MENU -> 1; current >= 0 -> current + 2; else -> 0 })
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    val chosen = when { pos == 1 -> Cfg.SELECTION_MENU; pos >= 2 -> pos - 2; else -> Cfg.UNASSIGNED }
                    if (chosen != asg.optInt(g, Cfg.UNASSIGNED)) { asg.put(g, chosen); save() }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
            sp.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); r.addView(sp); k.addView(r)
        }
        return k
    }

    private fun actionTitle(a: JSONObject, i: Int): String = a.optString("label").ifBlank { "Action ${i + 1}" }

    private fun assignedGestures(index: Int): String {
        val asg = prof().getJSONArray("assign"); val names = ArrayList<String>()
        for (g in Cfg.GESTURES.indices) if (asg.optInt(g, Cfg.UNASSIGNED) == index) names.add(Cfg.GESTURES[g])
        return if (names.isEmpty()) "Not assigned" else names.joinToString(", ")
    }

    private fun eventLabel(s: JSONObject): String = when (s.optString("type")) {
        "open_app" -> "Open " + s.optString("label").ifBlank { s.optString("pkg") }
        "tap" -> "Tap: " + s.optString("label").ifBlank { "control" }
        "tailscale_on" -> "Turn Tailscale on"
        "tailscale_off" -> "Turn Tailscale off"
        "close_app" -> "Close app"
        else -> s.optString("type", "Event")
    }

    private fun actionCard(i: Int): LinearLayout {
        val a = prof().getJSONArray("actions").getJSONObject(i); val k = card(); val head = row(); head.gravity = Gravity.CENTER_VERTICAL
        val title = label(actionTitle(a, i), 18f, true); title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); head.addView(title)
        val sw = Switch(this); sw.isChecked = a.optBoolean("enabled", true); sw.setOnCheckedChangeListener { _, v -> a.put("enabled", v); save() }; head.addView(sw); k.addView(head)
        k.addView(label("Gestures: ${assignedGestures(i)}", 13f, false, Color.DKGRAY))
        val steps = a.optJSONArray("steps") ?: JSONArray(); val summary = ArrayList<String>()
        for (q in 0 until steps.length()) summary.add("${q + 1}. ${eventLabel(steps.getJSONObject(q))}")
        k.addView(label(if (summary.isEmpty()) "No events configured" else summary.joinToString("\n"), 13f, false, Color.DKGRAY))
        val r = row(); r.addView(weighted(btn("Edit") { showEditor(i) })); r.addView(weighted(btn("Test") { testAction(a, i) })); r.addView(weighted(btn("Delete") { deleteAction(i) })); k.addView(r)
        return k
    }

    private fun addAction() {
        val acts = prof().getJSONArray("actions"); val a = Cfg.newAction(); a.put("label", "Action ${acts.length() + 1}"); acts.put(a); save(); showEditor(acts.length() - 1)
    }

    private fun deleteAction(index: Int) {
        AlertDialog.Builder(this).setTitle("Delete action?").setMessage("This removes the action and unassigns any gestures using it.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                val p = prof(); val acts = p.getJSONArray("actions"); if (index >= 0 && index < acts.length()) acts.remove(index)
                val asg = p.getJSONArray("assign")
                for (g in 0 until asg.length()) { val v = asg.optInt(g, Cfg.UNASSIGNED); asg.put(g, when { v == index -> Cfg.UNASSIGNED; v > index -> v - 1; else -> v }) }
                save(); showHome()
            }.show()
    }

    private fun showEditor(index: Int) {
        val acts = prof().getJSONArray("actions")
        if (index < 0 || index >= acts.length()) { showHome(); return }
        editingIndex = index
        val a = acts.getJSONObject(index)
        val c = newPage("Edit Action ${index + 1}")
        c.addView(btn("← Back to actions") { editingIndex = -1; showHome() })

        val name = EditText(this); name.setText(a.optString("label")); name.hint = "Action name"; name.setSingleLine(); c.addView(name)
        name.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { a.put("label", s?.toString().orEmpty()); save() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        val en = Switch(this); en.text = "Enabled"; en.isChecked = a.optBoolean("enabled", true); en.setOnCheckedChangeListener { _, v -> a.put("enabled", v); save() }; c.addView(en)

        val appCard = card(); appCard.addView(label("App", 17f, true))
        val pkg = a.optString("pkg"); val ar = row(); ar.gravity = Gravity.CENTER_VERTICAL; ar.addView(iconView(pkg.ifEmpty { null }, 44))
        val appText = label(if (pkg.isEmpty()) "No app selected" else a.optString("label").ifBlank { pkg }, 15f, true); appText.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); ar.addView(appText)
        ar.addView(btn(if (pkg.isEmpty()) "Choose" else "Change") { chooseApp(a) })
        if (pkg.isNotEmpty()) ar.addView(btn("Remove") { a.put("pkg", ""); a.put("label", ""); a.put("steps", JSONArray()); save(); showEditor(index) })
        appCard.addView(ar); c.addView(appCard)

        val eventsCard = card(); eventsCard.addView(label("Events — top to bottom", 17f, true)); eventsCard.addView(label("The app executes these in this exact order. Move events up/down to change the sequence.", 13f))
        val steps = a.optJSONArray("steps") ?: JSONArray(); a.put("steps", steps)
        for (q in 0 until steps.length()) eventsCard.addView(eventRow(a, q))
        val addRow = row(); addRow.addView(weighted(btn("＋ Add event") { showAddEventDialog(index) })); addRow.addView(weighted(btn("Record navigation") { startRecord(index) })); eventsCard.addView(addRow)
        c.addView(eventsCard)

        c.addView(btn("Test this action") { testAction(a, index) })
        c.addView(btn("Delete this action") { deleteAction(index) })

        val settings = card(); settings.addView(label("Global settings", 17f, true))
        settings.addView(label("These settings apply to the whole app and are available from the main page.", 13f)); c.addView(settings)
    }

    private fun eventRow(a: JSONObject, index: Int): LinearLayout {
        val steps = a.getJSONArray("steps"); val s = steps.getJSONObject(index); val r = row(); r.gravity = Gravity.CENTER_VERTICAL
        val num = label("${index + 1}", 15f, true); num.layoutParams = LinearLayout.LayoutParams(dp(30), ViewGroup.LayoutParams.WRAP_CONTENT); r.addView(num)
        val text = label(eventLabel(s), 14f); text.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); r.addView(text)
        r.addView(btn("↑") { if (index > 0) { steps.put(index, steps.getJSONObject(index - 1)); steps.put(index - 1, s); save(); showEditor(editingIndex) } })
        r.addView(btn("↓") { if (index < steps.length() - 1) { steps.put(index, steps.getJSONObject(index + 1)); steps.put(index + 1, s); save(); showEditor(editingIndex) } })
        r.addView(btn("✕") { steps.remove(index); save(); showEditor(editingIndex) })
        return r
    }

    private fun showAddEventDialog(index: Int) {
        val choices = arrayOf("Tap/recorded control", "Turn Tailscale on", "Turn Tailscale off", "Close app")
        AlertDialog.Builder(this).setTitle("Add event").setItems(choices) { _, which ->
            val a = prof().getJSONArray("actions").getJSONObject(index); val steps = a.getJSONArray("steps")
            when (which) {
                0 -> startRecord(index)
                1 -> steps.put(Cfg.newStep("tailscale_on"))
                2 -> steps.put(Cfg.newStep("tailscale_off"))
                3 -> steps.put(Cfg.newStep("close_app"))
            }
            save(); if (which != 0) showEditor(index)
        }.show()
    }

    private fun settingsCard(): LinearLayout {
        val k = card(); k.addView(label("Settings", 17f, true))
        val unl = Switch(this); unl.text = "Only when the phone is unlocked"; unl.isChecked = cfg.optBoolean("unlockedOnly", true); unl.setOnCheckedChangeListener { _, v -> cfg.put("unlockedOnly", v); save() }; k.addView(unl)
        val ban = Switch(this); ban.text = "Show the banner at the top"; ban.isChecked = cfg.optBoolean("banner", true); ban.setOnCheckedChangeListener { _, v -> cfg.put("banner", v); save() }; k.addView(ban)
        val holdMs = cfg.optInt("holdMs", 1200); val holdLabel = label("Hold time: ${holdMs / 1000.0} s", 14f); k.addView(holdLabel)
        val bar = SeekBar(this); bar.max = 25; bar.progress = ((holdMs - 500) / 100).coerceIn(0, 25)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) { holdLabel.text = "Hold time: ${(500 + progress * 100) / 1000.0} s" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { cfg.put("holdMs", 500 + (s?.progress ?: 7) * 100); save() }
        }); k.addView(bar); return k
    }

    private fun testAction(a: JSONObject, i: Int) {
        val svc = KeyComboService.instance ?: run { toast("Turn on the KeyShortcut accessibility service first."); return }
        svc.runAction(a, i, "Test")
    }

    private fun startRecord(index: Int) {
        val svc = KeyComboService.instance ?: run { toast("Turn on the KeyShortcut accessibility service first."); return }
        val a = prof().getJSONArray("actions").getJSONObject(index); val pkg = a.optString("pkg")
        if (pkg.isEmpty()) { toast("Choose an app first, then record its navigation."); return }
        val li = packageManager.getLaunchIntentForPackage(pkg) ?: run { toast("That app can't be opened."); return }
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        startActivity(li)
        svc.startRecording(profile, index, pkg)
    }

    private fun chooseApp(a: JSONObject) {
        pickApp { appLabel, pkg ->
            val old = a.optString("pkg")
            if (old != pkg) {
                a.put("steps", JSONArray())
                a.put("pkg", pkg)
                a.put("label", appLabel)
                a.getJSONArray("steps").put(Cfg.newStep("open_app").put("pkg", pkg).put("label", appLabel))
            } else {
                a.put("pkg", pkg); a.put("label", appLabel)
                val steps = a.getJSONArray("steps")
                var found = false
                for (i in 0 until steps.length()) if (steps.getJSONObject(i).optString("type") == "open_app") { steps.getJSONObject(i).put("pkg", pkg).put("label", appLabel); found = true; break }
                if (!found) steps.put(0, Cfg.newStep("open_app").put("pkg", pkg).put("label", appLabel))
            }
            save()
        }
    }

    private fun listApps(): List<Pair<String, String>> {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        return packageManager.queryIntentActivities(launcher, 0).map { Pair(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.second }.filter { it.second != packageName }.sortedBy { it.first.lowercase() }
    }

    private fun pickApp(onPicked: (String, String) -> Unit) {
        val apps = listApps(); var shown = apps
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL
        val search = EditText(this); search.hint = "Search apps"; search.setSingleLine(); box.addView(search)
        val list = ListView(this); list.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(420)); box.addView(list)
        val dialog = AlertDialog.Builder(this).setTitle("Choose an app").setView(box).setNegativeButton("Cancel", null).create()
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int) = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val item = shown[position]; val r = row(); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(dp(12), dp(8), dp(12), dp(8)); r.addView(iconView(item.second, 40))
                val col = LinearLayout(this@MainActivity); col.orientation = LinearLayout.VERTICAL; col.addView(label(item.first, 16f, true)); col.addView(label(item.second, 11f, false, Color.GRAY)); r.addView(col); return r
            }
        }
        list.adapter = adapter
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { val q = s?.toString().orEmpty().lowercase(); shown = apps.filter { it.first.lowercase().contains(q) || it.second.lowercase().contains(q) }; adapter.notifyDataSetChanged() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        list.setOnItemClickListener { _, _, pos, _ -> val item = shown[pos]; dialog.dismiss(); onPicked(item.first, item.second); if (editingIndex >= 0) showEditor(editingIndex) }
        dialog.show()
    }
}
