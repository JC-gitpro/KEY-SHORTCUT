package com.example.keyshortcut

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * Configuration screen. Everything is written to Cfg (SharedPreferences) the moment you change it,
 * and the accessibility service picks the change up immediately.
 */
class MainActivity : Activity() {

    private var cfg = JSONObject()
    private var profile = "vol"
    private var scroll: ScrollView? = null

    override fun onResume() {
        super.onResume()
        // Also runs when you come back from Accessibility settings or from recording controls.
        showHome()
    }

    // ───────────────────────── small helpers ─────────────────────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun save() {
        Cfg.save(this, cfg)
    }

    private fun prof(): JSONObject = Cfg.profile(cfg, profile)

    private fun newPage(title: String): LinearLayout {
        val keepY = scroll?.scrollY ?: 0
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(40))
        val t = label(title, 28f, true)
        t.setPadding(0, 0, 0, dp(12))
        content.addView(t)
        val sv = ScrollView(this)
        sv.addView(content)
        setContentView(sv)
        scroll = sv
        sv.post { sv.scrollTo(0, keepY) }
        return content
    }

    private fun label(s: String, size: Float = 16f, bold: Boolean = false, color: Int = Color.BLACK): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun btn(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setAllCaps(false)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#EEF0F6"))
        bg.setCornerRadius(dp(16).toFloat())
        c.background = bg
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(12)
        c.layoutParams = lp
        return c
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        return r
    }

    private fun weighted(v: View): View {
        v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        return v
    }

    private fun spacer(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
        return v
    }

    private fun loadIcon(pkg: String?): Drawable? {
        if (pkg.isNullOrEmpty()) return null
        return try {
            packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getApplicationInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    /** The app's real launcher icon, or a round placeholder. */
    private fun iconView(pkg: String?, sizeDp: Int): View {
        val d = loadIcon(pkg)
        val lp = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        lp.rightMargin = dp(10)
        if (d != null) {
            val iv = ImageView(this)
            iv.setImageDrawable(d)
            iv.layoutParams = lp
            return iv
        }
        val t = TextView(this)
        t.text = "\u26A1"
        t.textSize = sizeDp * 0.42f
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#9AA0B4"))
        t.background = bg
        t.layoutParams = lp
        return t
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(this, KeyComboService::class.java)
        return enabled.contains(cn.flattenToString()) || enabled.contains(cn.flattenToShortString())
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    // ───────────────────────── home screen ─────────────────────────

    private fun showHome() {
        cfg = Cfg.load(this)
        val c = newPage("KeyShortcut")

        c.addView(accessCard())

        // Which button combination we are configuring
        val tabs = row()
        val tVol = btn((if (profile == "vol") "\u25CF " else "") + "Volume Up + Down") { profile = "vol"; showHome() }
        val tPow = btn((if (profile == "power") "\u25CF " else "") + "Volume Up + Power") { profile = "power"; showHome() }
        tabs.addView(weighted(tVol))
        tabs.addView(weighted(tPow))
        c.addView(tabs)

        c.addView(profileCard())
        c.addView(assignCard())

        val head = label("Actions", 20f, true)
        head.setPadding(0, dp(8), 0, dp(8))
        c.addView(head)
        for (i in 0 until 3) c.addView(actionCard(i))

        c.addView(settingsCard())
    }

    private fun accessCard(): LinearLayout {
        val on = isServiceEnabled()
        val k = card()
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor(if (on) "#DDF3E1" else "#FBDADA"))
        bg.setCornerRadius(dp(16).toFloat())
        k.background = bg
        k.addView(label(if (on) "Accessibility service is on" else "Accessibility service is OFF", 17f, true))
        k.addView(
            label(
                if (on) "Your shortcuts work from any app."
                else "Nothing will work until you turn on KeyShortcut in Accessibility settings (Installed apps > KeyShortcut).",
                13f
            )
        )
        if (!on) {
            k.addView(btn("Open Accessibility settings") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        }
        return k
    }

    private fun profileCard(): LinearLayout {
        val p = prof()
        val k = card()
        val head = row()
        head.gravity = Gravity.CENTER_VERTICAL
        val title = label(if (profile == "vol") "Volume Up + Volume Down" else "Volume Up + Power", 17f, true)
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        head.addView(title)
        val sw = Switch(this)
        sw.isChecked = p.optBoolean("enabled", false)
        sw.setOnCheckedChangeListener { _, v ->
            p.put("enabled", v)
            save()
        }
        head.addView(sw)
        k.addView(head)
        k.addView(
            label(
                if (profile == "vol") "Press both buttons together: hold, double tap, or triple tap."
                else "Best effort only. Android reserves the power button, so many phones (including Samsung) never send it to apps. If nothing happens, that is the phone, not the app.",
                13f
            )
        )
        return k
    }

    private fun assignCard(): LinearLayout {
        val p = prof()
        val asg = p.getJSONArray("assign")
        val k = card()
        k.addView(label("Gesture assignment", 17f, true))
        k.addView(label("Choose which action each gesture runs. A single tap never does anything.", 13f))
        k.addView(spacer(6))
        val options = arrayOf("Not assigned", "Action 1", "Action 2", "Action 3")
        for (g in 0 until 3) {
            val r = row()
            r.gravity = Gravity.CENTER_VERTICAL
            val name = label(Cfg.GESTURES[g], 15f, true)
            name.layoutParams = LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT)
            r.addView(name)
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
            sp.setSelection(asg.getInt(g) + 1)
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, rowId: Long) {
                    val chosen = pos - 1
                    if (chosen == asg.getInt(g)) return
                    // Swap with whichever gesture already used that action
                    val old = asg.getInt(g)
                    if (chosen >= 0) {
                        for (o in 0 until 3) if (o != g && asg.getInt(o) == chosen) asg.put(o, old)
                    }
                    asg.put(g, chosen)
                    save()
                    showHome()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
            sp.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            r.addView(sp)
            k.addView(r)
        }
        return k
    }

    private fun actionCard(i: Int): LinearLayout {
        val p = prof()
        val a = p.getJSONArray("actions").getJSONObject(i)
        val asg = p.getJSONArray("assign")
        var gesture = -1
        for (q in 0 until 3) if (asg.getInt(q) == i) gesture = q

        val k = card()

        // Header: name + ON/OFF
        val head = row()
        head.gravity = Gravity.CENTER_VERTICAL
        val title = label("Action ${i + 1}", 18f, true)
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        head.addView(title)
        val sw = Switch(this)
        sw.isChecked = a.optBoolean("enabled", true)
        sw.setOnCheckedChangeListener { _, v ->
            a.put("enabled", v)
            save()
        }
        head.addView(sw)
        k.addView(head)
        k.addView(
            label(
                if (gesture >= 0) "Runs on: " + Cfg.GESTURES[gesture] else "Not assigned to a gesture",
                13f, false, Color.parseColor("#555555")
            )
        )
        k.addView(spacer(8))

        // App
        val pkg = a.optString("pkg")
        val lab = a.optString("label")
        val appRow = row()
        appRow.gravity = Gravity.CENTER_VERTICAL
        appRow.addView(iconView(if (pkg.isEmpty()) null else pkg, 44))
        val missing = pkg.isNotEmpty() && !isInstalled(pkg)
        val appName = label(
            when {
                pkg.isEmpty() -> "No app (optional)"
                missing -> "$lab (not installed)"
                else -> lab
            },
            15f, true, if (missing) Color.parseColor("#B3261E") else Color.BLACK
        )
        appName.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        appRow.addView(appName)
        appRow.addView(btn(if (pkg.isEmpty()) "Choose app" else "Change") { chooseApp(a) })
        if (pkg.isNotEmpty()) {
            appRow.addView(btn("Remove") {
                a.put("pkg", "")
                a.put("label", "")
                a.put("controls", JSONArray())
                save()
                showHome()
            })
        }
        k.addView(appRow)

        // Controls
        val controls = a.getJSONArray("controls")
        val names = ArrayList<String>()
        for (q in 0 until controls.length()) names.add((q + 1).toString() + ". " + controls.getJSONObject(q).optString("label"))
        val ctlText = label(
            if (names.isEmpty()) "No controls recorded" else names.joinToString("  \u2192  "),
            13f, false, Color.parseColor("#333333")
        )
        ctlText.setPadding(0, dp(6), 0, dp(2))
        k.addView(ctlText)
        val cr = row()
        cr.addView(weighted(btn("Record controls") { startRecord(i) }))
        cr.addView(weighted(btn("Clear") {
            a.put("controls", JSONArray())
            save()
            showHome()
        }))
        k.addView(cr)

        // Options
        val close = Switch(this)
        close.text = "Close the app after the action"
        close.isChecked = a.optBoolean("closeApp", false)
        close.setOnCheckedChangeListener { _, v ->
            a.put("closeApp", v)
            save()
        }
        k.addView(close)

        val tsRow = row()
        tsRow.gravity = Gravity.CENTER_VERTICAL
        tsRow.addView(label("Tailscale: ", 14f))
        val tsValues = arrayOf("none", "on", "off")
        val tsSpin = Spinner(this)
        tsSpin.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Leave as is", "Turn on first", "Turn off first")
        )
        tsSpin.setSelection(tsValues.indexOf(a.optString("tailscale", "none")).coerceAtLeast(0))
        tsSpin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, rowId: Long) {
                if (a.optString("tailscale", "none") != tsValues[pos]) {
                    a.put("tailscale", tsValues[pos])
                    save()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        tsSpin.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tsRow.addView(tsSpin)
        k.addView(tsRow)

        k.addView(btn("Test this action") { testAction(a, i) })
        return k
    }

    private fun settingsCard(): LinearLayout {
        val k = card()
        k.addView(label("Settings", 17f, true))

        val unl = Switch(this)
        unl.text = "Only when the phone is unlocked"
        unl.isChecked = cfg.optBoolean("unlockedOnly", true)
        unl.setOnCheckedChangeListener { _, v ->
            cfg.put("unlockedOnly", v)
            save()
        }
        k.addView(unl)

        val ban = Switch(this)
        ban.text = "Show the banner at the top of the screen"
        ban.isChecked = cfg.optBoolean("banner", true)
        ban.setOnCheckedChangeListener { _, v ->
            cfg.put("banner", v)
            save()
        }
        k.addView(ban)

        val holdMs = cfg.optInt("holdMs", 1200)
        val holdLabel = label("Hold time: " + (holdMs / 1000.0) + " s", 14f)
        holdLabel.setPadding(0, dp(10), 0, 0)
        k.addView(holdLabel)
        val bar = SeekBar(this)
        bar.max = 25 // 0.5 s .. 3.0 s in 0.1 s steps
        bar.progress = ((holdMs - 500) / 100).coerceIn(0, 25)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                holdLabel.text = "Hold time: " + ((500 + progress * 100) / 1000.0) + " s"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                cfg.put("holdMs", 500 + (s?.progress ?: 7) * 100)
                save()
            }
        })
        k.addView(bar)
        return k
    }

    // ───────────────────────── actions on the cards ─────────────────────────

    private fun testAction(a: JSONObject, i: Int) {
        val svc = KeyComboService.instance
        if (svc == null) {
            toast("Turn on the KeyShortcut accessibility service first.")
            return
        }
        svc.runAction(a, i, "Test")
    }

    private fun startRecord(i: Int) {
        val svc = KeyComboService.instance
        if (svc == null) {
            toast("Turn on the KeyShortcut accessibility service first.")
            return
        }
        val a = prof().getJSONArray("actions").getJSONObject(i)
        val pkg = a.optString("pkg")
        if (pkg.isEmpty()) {
            toast("Choose an app for this action first, then record its controls.")
            return
        }
        val li = packageManager.getLaunchIntentForPackage(pkg)
        if (li == null) {
            toast("That app can't be opened. Is it still installed?")
            return
        }
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(li)
        svc.startRecording(profile, i, pkg)
    }

    private fun chooseApp(a: JSONObject) {
        pickApp { appLabel, pkg ->
            if (a.optString("pkg") != pkg) {
                a.put("controls", JSONArray())
            }
            a.put("pkg", pkg)
            a.put("label", appLabel)
            save()
            showHome()
        }
    }

    // ───────────────────────── installed-app picker (real icons) ─────────────────────────

    private fun listApps(): List<Pair<String, String>> {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        return packageManager.queryIntentActivities(launcher, 0)
            .map { Pair(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.second }
            .filter { it.second != packageName }
            .sortedBy { it.first.lowercase() }
    }

    private fun pickApp(onPicked: (String, String) -> Unit) {
        val apps = listApps()
        var shown = apps

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val search = EditText(this)
        search.hint = "Search apps"
        search.setSingleLine()
        val list = ListView(this)
        list.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(420))
        box.addView(search)
        box.addView(list)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Choose an app")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .create()

        val ctx = this
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int) = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val item = shown[position]
                val r = LinearLayout(ctx)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(12), dp(8), dp(12), dp(8))
                r.addView(iconView(item.second, 40))
                val col = LinearLayout(ctx)
                col.orientation = LinearLayout.VERTICAL
                col.addView(label(item.first, 16f, true))
                col.addView(label(item.second, 11f, false, Color.GRAY))
                r.addView(col)
                return r
            }
        }
        list.adapter = adapter

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty().lowercase()
                shown = apps.filter { it.first.lowercase().contains(q) || it.second.lowercase().contains(q) }
                adapter.notifyDataSetChanged()
            }

            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        list.setOnItemClickListener { _, _, pos, _ ->
            val item = shown[pos]
            dialog.dismiss()
            onPicked(item.first, item.second)
        }
        dialog.show()
    }
}
