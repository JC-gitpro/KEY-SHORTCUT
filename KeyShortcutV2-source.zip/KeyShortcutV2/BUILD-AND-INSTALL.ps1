$ErrorActionPreference = 'Stop'

$SourceRoot = Split-Path -Parent $PSCommandPath
$Flutter = 'C:\flutter\bin\flutter.bat'
$Dart = 'C:\flutter\bin\dart.bat'
$Adb = 'C:\Users\JNC\AppData\Local\Android\Sdk\platform-tools\adb.exe'
$BuildRoot = Join-Path $env:TEMP ('keyshortcut_v2_build_' + $PID)

function Fail([string]$Message) {
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Red
    Write-Host "BUILD/INSTALL FAILED: $Message" -ForegroundColor Red
    Write-Host '============================================================' -ForegroundColor Red
    exit 1
}

function Invoke-Native([string]$FilePath, [string[]]$Arguments) {
    & $FilePath @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed ($LASTEXITCODE): $FilePath $($Arguments -join ' ')"
    }
}

function Get-ConnectedDevice {
    Write-Host ''
    Write-Host '==================== ADB DEBUG ====================' -ForegroundColor Cyan
    Write-Host "ADB executable: $Adb"

    Write-Host 'ADB DEBUG: starting server...'
    & $Adb 'start-server'
    if ($LASTEXITCODE -ne 0) { throw "ADB server could not start (exit code $LASTEXITCODE)." }

    Write-Host 'ADB DEBUG: adb version:' -ForegroundColor Cyan
    & $Adb 'version'
    if ($LASTEXITCODE -ne 0) { throw 'adb version failed.' }

    $deadline = [DateTime]::UtcNow.AddSeconds(30)
    while ([DateTime]::UtcNow -lt $deadline) {
        $deviceLines = @(& $Adb 'devices' '-l')
        Write-Host ''
        Write-Host 'ADB DEBUG: adb devices -l:' -ForegroundColor Cyan
        Write-Host ($deviceLines -join [Environment]::NewLine)

        $authorized = $null
        $unauthorized = $false
        $offline = $false
        foreach ($line in ($deviceLines | Select-Object -Skip 1)) {
            if ($line -match '^\s*(\S+)\s+device\b') { $authorized = $Matches[1]; break }
            if ($line -match '^\s*\S+\s+unauthorized\b') { $unauthorized = $true }
            if ($line -match '^\s*\S+\s+offline\b') { $offline = $true }
        }

        if ($authorized) {
            Write-Host "ADB DEBUG: authorized device = $authorized" -ForegroundColor Green
            $state = (& $Adb '-s' $authorized 'get-state').Trim()
            Write-Host "ADB DEBUG: get-state = [$state]"
            if ($state -ne 'device') { throw "ADB returned unexpected state: $state" }

            $model = (& $Adb '-s' $authorized 'shell' 'getprop' 'ro.product.model').Trim()
            $manufacturer = (& $Adb '-s' $authorized 'shell' 'getprop' 'ro.product.manufacturer').Trim()
            $android = (& $Adb '-s' $authorized 'shell' 'getprop' 'ro.build.version.release').Trim()
            Write-Host "ADB DEBUG: phone = $manufacturer $model"
            Write-Host "ADB DEBUG: Android = $android"

            Write-Host 'ADB DEBUG: shell round-trip test...'
            $ping = (& $Adb '-s' $authorized 'shell' 'echo' 'KEYSHORTCUT_ADB_OK').Trim()
            Write-Host "ADB DEBUG: shell returned [$ping]"
            if ($ping -ne 'KEYSHORTCUT_ADB_OK') { throw 'ADB shell round-trip test failed.' }

            return $authorized
        }

        if ($unauthorized) {
            Write-Host 'ADB DEBUG: device is UNAUTHORIZED. Unlock phone and accept the USB debugging RSA prompt.' -ForegroundColor Yellow
        } elseif ($offline) {
            Write-Host 'ADB DEBUG: device is OFFLINE. Reconnect USB and confirm USB debugging.' -ForegroundColor Yellow
        } else {
            Write-Host 'ADB DEBUG: no authorized device yet; waiting 1 second...' -ForegroundColor Yellow
        }
        Start-Sleep -Seconds 1
    }

    throw 'No authorized Android phone detected by ADB within 30 seconds.'
}

Write-Host '============================================================'
Write-Host 'KeyShortcut v2 - CLEAN BUILD + INSTALL'
Write-Host '============================================================'
Write-Host 'This uses the same Flutter Android generation/build path as the known-good My Player v88 workflow.'
Write-Host "Flutter: $Flutter"
Write-Host "Dart:    $Dart"
Write-Host "ADB:     $Adb"
Write-Host ''

if (-not (Test-Path -LiteralPath $Flutter -PathType Leaf)) { Fail "Flutter not found: $Flutter" }
if (-not (Test-Path -LiteralPath $Dart -PathType Leaf)) { Fail "Dart not found: $Dart" }
if (-not (Test-Path -LiteralPath $Adb -PathType Leaf)) { Fail "ADB not found: $Adb" }

$NativeRoot = Join-Path $SourceRoot 'app'
$RequiredFiles = @(
    (Join-Path $NativeRoot 'build.gradle'),
    (Join-Path $NativeRoot 'src\main\AndroidManifest.xml'),
    (Join-Path $NativeRoot 'src\main\java\com\example\keyshortcut\MainActivity.kt'),
    (Join-Path $NativeRoot 'src\main\java\com\example\keyshortcut\KeyComboService.kt'),
    (Join-Path $NativeRoot 'src\main\java\com\example\keyshortcut\Cfg.kt'),
    (Join-Path $NativeRoot 'src\main\res\xml\accessibility_service_config.xml'),
    (Join-Path $NativeRoot 'src\main\res\values\keyshortcut_strings.xml'),
    (Join-Path $NativeRoot 'src\main\res\drawable\ic_launcher.xml')
)
foreach ($file in $RequiredFiles) {
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { Fail "Required source file missing: $file" }
}
Write-Host "SOURCE CHECK: all $($RequiredFiles.Count) required source files exist." -ForegroundColor Green

# Verify ADB before the expensive build. This is now a real diagnostic test,
# not just a printed path. It will be repeated immediately before installation.
try { $DeviceId = Get-ConnectedDevice } catch { Fail $_.Exception.Message }

if (Test-Path -LiteralPath $BuildRoot) {
    Remove-Item -LiteralPath $BuildRoot -Recurse -Force
}
New-Item -ItemType Directory -Path $BuildRoot | Out-Null

Push-Location -LiteralPath $BuildRoot
try {
    Write-Host '[1/8] Creating a completely clean Flutter Android/Web project...'
    Invoke-Native $Flutter @('create','--project-name','keyshortcut_v2_build','--platforms=android,web','.')
    if (-not (Test-Path -LiteralPath 'android\gradlew.bat')) { throw 'Flutter did not create android\gradlew.bat.' }
    if (-not (Test-Path -LiteralPath 'android\settings.gradle')) { throw 'Flutter did not create android\settings.gradle.' }
    if (-not (Test-Path -LiteralPath 'pubspec.yaml')) { throw 'Flutter did not create pubspec.yaml.' }
    if (-not (Test-Path -LiteralPath 'lib\main.dart')) { throw 'Flutter did not create lib\main.dart.' }

    Write-Host '[2/8] Replacing generated Android app with the KeyShortcut native app...'
    $GeneratedApp = Join-Path $BuildRoot 'android\app'
    $GeneratedMain = Join-Path $GeneratedApp 'src\main'
    $NativeMain = Join-Path $NativeRoot 'src\main'
    if (-not (Test-Path -LiteralPath $GeneratedApp)) { throw 'Flutter did not create android\app.' }
    if (Test-Path -LiteralPath $GeneratedMain) { Remove-Item -LiteralPath $GeneratedMain -Recurse -Force }
    New-Item -ItemType Directory -Path $GeneratedMain -Force | Out-Null

    Get-ChildItem -LiteralPath $NativeMain -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $GeneratedMain $_.Name) -Recurse -Force
    }
    Copy-Item -LiteralPath (Join-Path $NativeRoot 'build.gradle') -Destination (Join-Path $GeneratedApp 'build.gradle') -Force

    $Critical = @(
        (Join-Path $GeneratedMain 'AndroidManifest.xml'),
        (Join-Path $GeneratedMain 'java\com\example\keyshortcut\MainActivity.kt'),
        (Join-Path $GeneratedMain 'java\com\example\keyshortcut\KeyComboService.kt'),
        (Join-Path $GeneratedMain 'java\com\example\keyshortcut\Cfg.kt'),
        (Join-Path $GeneratedMain 'res\xml\accessibility_service_config.xml'),
        (Join-Path $GeneratedMain 'res\values\keyshortcut_strings.xml'),
        (Join-Path $GeneratedMain 'res\drawable\ic_launcher.xml'),
        (Join-Path $GeneratedApp 'build.gradle')
    )
    foreach ($file in $Critical) {
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "CRITICAL COPY CHECK FAILED: $file" }
    }
    Write-Host 'COPY CHECK: every critical native file is physically present in the generated Android project.' -ForegroundColor Green

    # Verify the package declaration and manifest references before Gradle sees them.
    $activityText = Get-Content -LiteralPath $Critical[1] -Raw
    $serviceText = Get-Content -LiteralPath $Critical[2] -Raw
    $manifestText = Get-Content -LiteralPath $Critical[0] -Raw
    if ($activityText -notmatch 'package\s+com\.example\.keyshortcut') { throw 'MainActivity package declaration is wrong.' }
    if ($serviceText -notmatch 'package\s+com\.example\.keyshortcut') { throw 'KeyComboService package declaration is wrong.' }
    foreach ($needle in @('android:name=".MainActivity"','android:name=".KeyComboService"','@xml/accessibility_service_config')) {
        if ($manifestText -notmatch [regex]::Escape($needle)) { throw "Manifest reference missing: $needle" }
    }
    Write-Host 'SOURCE CONSISTENCY CHECK: package, activity, service, and accessibility references agree.' -ForegroundColor Green

    Write-Host '[3/8] Resolving Flutter dependencies...'
    Invoke-Native $Flutter @('pub','get')

    Write-Host '[4/8] Checking the generated Gradle wrapper and Java toolchain...'
    & '.\android\gradlew.bat' '--project-dir' '.\android' '--version'
    if ($LASTEXITCODE -ne 0) { throw 'Generated Gradle wrapper could not start.' }

    Write-Host '[5/8] Building the actual APK with Flutter (same style as My Player v88)...'
    Write-Host 'The phone has not been modified by the build itself.'
    Invoke-Native $Flutter @('build','apk','--debug','--no-tree-shake-icons')

    $Apk = Join-Path $BuildRoot 'build\app\outputs\flutter-apk\app-debug.apk'
    if (-not (Test-Path -LiteralPath $Apk -PathType Leaf)) { throw "Flutter reported success but APK was not found: $Apk" }
    $size = (Get-Item -LiteralPath $Apk).Length
    if ($size -lt 10000) { throw "APK is only $size bytes; refusing to install." }
    $FinalApk = Join-Path $SourceRoot 'KeyShortcut-v2.apk'
    Copy-Item -LiteralPath $Apk -Destination $FinalApk -Force
    Write-Host "APK BUILD CHECK: $size bytes at $FinalApk" -ForegroundColor Green

    Write-Host '[6/8] Running final ADB DEBUG and installing...'
    $DeviceId = Get-ConnectedDevice
    Write-Host "ADB DEBUG: installing APK to $DeviceId" -ForegroundColor Green
    & $Adb '-s' $DeviceId 'install' '-r' '-d' $FinalApk
    if ($LASTEXITCODE -ne 0) { throw "ADB install failed with exit code $LASTEXITCODE" }

    Write-Host 'ADB DEBUG: verifying installed package...'
    $pm = @(& $Adb '-s' $DeviceId 'shell' 'pm' 'path' 'com.example.keyshortcut')
    Write-Host ($pm -join [Environment]::NewLine)
    if (($pm -join "`n") -notmatch 'package:') { throw 'Install returned success, but Android cannot find com.example.keyshortcut.' }

    Write-Host '[7/8] Verifying and launching MainActivity...'
    $resolved = @(& $Adb '-s' $DeviceId 'shell' 'cmd' 'package' 'resolve-activity' '--brief' 'com.example.keyshortcut')
    Write-Host 'ADB DEBUG: resolve-activity:'
    Write-Host ($resolved -join [Environment]::NewLine)
    if (($resolved -join "`n") -notmatch 'com\.example\.keyshortcut') { throw 'Android did not resolve the KeyShortcut launcher activity.' }

    & $Adb '-s' $DeviceId 'shell' 'am' 'start' '-W' '-n' 'com.example.keyshortcut/.MainActivity'
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'ADB DEBUG: launch failed. Last 120 logcat lines:' -ForegroundColor Red
        & $Adb '-s' $DeviceId 'logcat' '-d' '-t' '120' '*:E'
        throw "ADB launch failed with exit code $LASTEXITCODE"
    }

    Start-Sleep -Milliseconds 1000
    Write-Host '[8/8] Final runtime verification...'
    $focused = @(& $Adb '-s' $DeviceId 'shell' 'dumpsys' 'activity' 'activities')
    $focusedText = $focused -join "`n"
    if ($focusedText -match 'com\.example\.keyshortcut') {
        Write-Host 'ADB DEBUG: KeyShortcut is present in the activity manager.' -ForegroundColor Green
    } else {
        Write-Host 'WARNING: Android accepted the launch command, but KeyShortcut was not found in dumpsys immediately.' -ForegroundColor Yellow
        Write-Host 'ADB DEBUG: recent KeyShortcut errors:' -ForegroundColor Yellow
        & $Adb '-s' $DeviceId 'logcat' '-d' '-t' '120' '*:E'
    }

    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Green
    Write-Host 'SUCCESS - KeyShortcut v2 BUILD, INSTALL, AND LAUNCH COMPLETED.' -ForegroundColor Green
    Write-Host '============================================================' -ForegroundColor Green
    Write-Host "Device: $DeviceId"
    Write-Host "APK:    $FinalApk"
}
catch { Fail $_.Exception.Message }
finally { Pop-Location }
