# KeyShortcut v2 — phone build

1. Connect the Android phone with USB debugging enabled.
2. Double-click `BUILD-AND-INSTALL.cmd`.
3. Accept the USB debugging/RSA prompt on the phone if Android shows it.

This uses the installed Flutter SDK only to generate the Android Gradle wrapper, then builds the original native Kotlin KeyShortcut app. No system Gradle installation is required.
