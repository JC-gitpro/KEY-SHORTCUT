$ErrorActionPreference = 'Stop'
$SourceRoot = Split-Path -Parent $PSCommandPath
$Flutter = 'C:\flutter\bin\flutter.bat'
$BuildRoot = Join-Path $env:TEMP ('keyshortcut_v2_apk_build_' + $PID)
$NativeRoot = Join-Path $SourceRoot 'app'
if (-not (Test-Path -LiteralPath $Flutter -PathType Leaf)) { throw "Flutter not found: $Flutter" }
if (Test-Path -LiteralPath $BuildRoot) { Remove-Item -LiteralPath $BuildRoot -Recurse -Force }
New-Item -ItemType Directory -Path $BuildRoot | Out-Null
Push-Location -LiteralPath $BuildRoot
try {
    & $Flutter 'create' '--project-name' 'keyshortcut_v2_build' '--platforms=android,web' '.'
    if ($LASTEXITCODE -ne 0) { throw 'Flutter project creation failed.' }
    $GeneratedMain = Join-Path $BuildRoot 'android\app\src\main'
    $NativeMain = Join-Path $NativeRoot 'src\main'
    Remove-Item -LiteralPath $GeneratedMain -Recurse -Force
    New-Item -ItemType Directory -Path $GeneratedMain -Force | Out-Null
    Get-ChildItem -LiteralPath $NativeMain -Force | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $GeneratedMain $_.Name) -Recurse -Force }
    Copy-Item -LiteralPath (Join-Path $NativeRoot 'build.gradle') -Destination (Join-Path $BuildRoot 'android\app\build.gradle') -Force
    & $Flutter 'pub' 'get'
    if ($LASTEXITCODE -ne 0) { throw 'flutter pub get failed.' }
    & $Flutter 'build' 'apk' '--debug' '--no-tree-shake-icons'
    if ($LASTEXITCODE -ne 0) { throw 'Flutter APK build failed.' }
    $apk = Join-Path $BuildRoot 'build\app\outputs\flutter-apk\app-debug.apk'
    if (-not (Test-Path -LiteralPath $apk -PathType Leaf)) { throw "APK not found: $apk" }
    Copy-Item -LiteralPath $apk -Destination (Join-Path $SourceRoot 'KeyShortcut-v2.apk') -Force
    Write-Host "APK READY: $(Join-Path $SourceRoot 'KeyShortcut-v2.apk')" -ForegroundColor Green
} finally { Pop-Location }
