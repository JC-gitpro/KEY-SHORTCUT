@echo off
setlocal
C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-AND-INSTALL.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo BUILD/INSTALL FAILED. See the message above.
pause
exit /b %RC%
