# KeyShortcut v4.0 — recorder storage fix

## What's fixed

- Retains the original Storage Access Framework (SAF) tree URI and requests only the read/write grants Android actually returned.
- Resolves the destination folder from that persisted tree using AndroidX `DocumentFile` each time, rather than reusing a child-document URI as if it were the original tree permission.
- Checks that the destination can really create and delete a test file.
- Records into a seekable temporary M4A file first, then copies the finalized audio into the selected SD-card folder through SAF. This avoids relying on a removable-storage provider's file descriptor being seekable for MP4 finalization.
- On save failure, shows a notification instead of silently adding a nonexistent recording to the library.

## Storage linking

Open Voice Recorder → Link storage folder → select a writable folder on the microSD card and grant access. KeyShortcut creates/uses `KeyShortcut/Recordings` under that selected folder. If you select a folder already named `KeyShortcut`, it creates/uses `Recordings` inside it; if you select `Recordings`, it uses that folder directly.

Android may prevent selecting the SD-card volume root on some versions/providers. In that case select a writable folder on the card; the app creates its folder structure beneath the selected folder.

## Build

Use the included `build-apk-v4.yml` workflow. The source ZIP's app Gradle file references Flutter, but the workflow intentionally creates a native Android Gradle project because the ZIP does not contain a Flutter project.

Package ID for this test build: `com.example.keyshortcut.test40`.
