package com.example.keyshortcut

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object RecordingStore {
    private const val PREFS = "voice_recordings"
    private const val KEY = "items"

    data class Item(val location: String, var name: String, val created: Long) {
        val isUri: Boolean get() = location.startsWith("content:")
        val uri: Uri? get() = if (isUri) Uri.parse(location) else null
        val path: String get() = location
    }

    fun all(ctx: Context): MutableList<Item> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val out = mutableListOf<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val location = o.optString("location", o.optString("path"))
            if (location.isBlank()) continue
            val exists = if (location.startsWith("content:")) {
                runCatching { ctx.contentResolver.openFileDescriptor(Uri.parse(location), "r")?.use { true } ?: false }.getOrDefault(false)
            } else File(location).exists()
            if (exists) out.add(Item(location, o.optString("name", "Recording"), o.optLong("created", System.currentTimeMillis())))
        }
        out.sortByDescending { it.created }
        return out
    }

    fun add(ctx: Context, location: String, name: String) {
        val list = all(ctx)
        list.removeAll { it.location == location }
        list.add(0, Item(location, name.ifBlank { "Recording" }, System.currentTimeMillis()))
        save(ctx, list)
    }

    fun rename(ctx: Context, item: Item, name: String): Item? {
        val newName = name.ifBlank { "Recording" }
        var newLocation = item.location
        if (item.isUri) {
            newLocation = StorageManager.rename(ctx, Uri.parse(item.location), newName)?.toString() ?: item.location
        } else {
            val src = File(item.location)
            val dst = File(src.parentFile, StorageManager.safeName(newName) + ".m4a")
            if (src.exists() && src.absolutePath != dst.absolutePath) runCatching { src.renameTo(dst) }
            newLocation = dst.absolutePath
        }
        val list = all(ctx)
        list.find { it.location == item.location }?.let {
            it.name = newName
            list.remove(it)
            list.add(0, Item(newLocation, newName, item.created))
        }
        save(ctx, list)
        return Item(newLocation, newName, item.created)
    }

    fun delete(ctx: Context, item: Item) {
        if (item.isUri) runCatching { StorageManager.delete(ctx, Uri.parse(item.location)) }
        else runCatching { File(item.location).delete() }
        val list = all(ctx)
        list.removeAll { it.location == item.location }
        save(ctx, list)
    }

    private fun save(ctx: Context, list: List<Item>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("location", it.location).put("name", it.name).put("created", it.created)) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
