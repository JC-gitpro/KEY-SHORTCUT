package com.example.keyshortcut

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.util.UUID

/**
 * SAF storage for removable/shared storage.
 * We retain the exact ACTION_OPEN_DOCUMENT_TREE URI and rebuild the destination
 * directory from that tree each time. We never treat a child document URI as a
 * tree permission, which was the broken link in earlier versions.
 *
 * User selects a writable folder on the SD card. The app creates/uses:
 *   selected folder/KeyShortcut/Recordings
 * unless the selected folder itself is already KeyShortcut or Recordings.
 */
object StorageManager {
    private const val PREFS = "recording_storage"
    private const val KEY_ROOT_TREE = "root_tree_uri"
    private const val KEY_RECORDINGS = "recordings_uri"
    private const val KEY_LAST_ERROR = "last_error"
    private const val KEYSHORTCUT_DIR = "KeyShortcut"
    private const val RECORDINGS_DIR = "Recordings"

    data class Validation(val ok: Boolean, val message: String)

    /** Returns the current Recordings directory URI for display/legacy callers. */
    fun treeUri(ctx: Context): Uri? = runCatching { recordingsDirectory(ctx)?.uri }.getOrNull()

    private fun rootTreeUri(ctx: Context): Uri? = prefs(ctx)
        .getString(KEY_ROOT_TREE, null)?.let { runCatching { Uri.parse(it) }.getOrNull() }

    /** Persist only permissions actually returned by the document picker. */
    fun linkSelectedFolder(ctx: Context, selectedTree: Uri, resultFlags: Int =
        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION): Validation {
        return try {
            val rwMask = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            val grantFlags = resultFlags and rwMask
            if (grantFlags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION == 0) {
                return Validation(false, "Android did not grant write access. Select the SD-card folder again and allow access.")
            }
            try {
                ctx.contentResolver.takePersistableUriPermission(selectedTree, grantFlags)
            } catch (e: SecurityException) {
                // It may already be persisted. Verify below rather than failing immediately.
                if (ctx.contentResolver.persistedUriPermissions.none { it.uri == selectedTree && it.isWritePermission }) throw e
            }

            val persisted = ctx.contentResolver.persistedUriPermissions
                .firstOrNull { it.uri == selectedTree }
            if (persisted == null || !persisted.isWritePermission) {
                return Validation(false, "Android did not preserve write access to that folder. Please select it again.")
            }

            // Temporarily save the selected tree so the directory resolver can use it.
            prefs(ctx).edit().putString(KEY_ROOT_TREE, selectedTree.toString()).apply()
            val recordings = recordingsDirectory(ctx)
                ?: throw IllegalStateException("Could not access the selected folder.")
            if (!recordings.isDirectory) throw IllegalStateException("The Recordings destination is not a folder.")
            prefs(ctx).edit()
                .putString(KEY_RECORDINGS, recordings.uri.toString())
                .remove(KEY_LAST_ERROR)
                .apply()
            validate(ctx)
        } catch (e: Exception) {
            val message = "Couldn't prepare KeyShortcut/Recordings on that location. ${e.message ?: "Choose a writable folder on the SD card."}"
            saveError(ctx, message)
            Validation(false, message)
        }
    }

    /** Backward-compatible setter for older code. */
    fun setTreeUri(ctx: Context, uri: Uri) {
        val result = linkSelectedFolder(ctx, uri)
        if (!result.ok) saveError(ctx, result.message)
    }

    fun clear(ctx: Context) {
        rootTreeUri(ctx)?.let { old ->
            runCatching {
                ctx.contentResolver.releasePersistableUriPermission(
                    old,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
        }
        prefs(ctx).edit().clear().apply()
    }

    /** Verify persisted write grant and perform an actual create/delete test in destination. */
    fun validate(ctx: Context): Validation {
        val root = rootTreeUri(ctx)
            ?: return Validation(false, "No recording folder is linked. Tap Link storage folder.")
        val permission = ctx.contentResolver.persistedUriPermissions
            .firstOrNull { it.uri == root }
        if (permission == null || !permission.isWritePermission) {
            val msg = "The SD-card write permission is missing. Tap Link storage folder and choose the destination again."
            saveError(ctx, msg)
            return Validation(false, msg)
        }
        return try {
            val directory = recordingsDirectory(ctx)
                ?: throw IllegalStateException("The KeyShortcut/Recordings folder could not be found.")
            val probe = directory.createFile("application/octet-stream", ".keyshortcut_${UUID.randomUUID()}")
                ?: throw IllegalStateException("Android could not create a test file in the selected folder.")
            if (!probe.delete()) throw IllegalStateException("Android created the test file but could not delete it.")
            prefs(ctx).edit().putString(KEY_RECORDINGS, directory.uri.toString()).remove(KEY_LAST_ERROR).apply()
            Validation(true, "Recording folder is ready.")
        } catch (e: Exception) {
            val msg = "KeyShortcut/Recordings cannot be written there. ${e.message ?: "Select a writable folder on the SD card."}"
            saveError(ctx, msg)
            Validation(false, msg)
        }
    }

    fun isLinked(ctx: Context): Boolean = validate(ctx).ok

    fun lastError(ctx: Context): String = prefs(ctx).getString(KEY_LAST_ERROR, "") ?: ""

    /** Create a destination M4A document inside the resolved Recordings directory. */
    fun createRecording(ctx: Context, baseName: String): Uri? {
        val validation = validate(ctx)
        if (!validation.ok) return null
        return try {
            val directory = recordingsDirectory(ctx)
                ?: throw IllegalStateException("Recording folder is unavailable.")
            val file = directory.createFile("audio/mp4", safeName(baseName) + ".m4a")
                ?: throw IllegalStateException("Android could not create the recording file.")
            file.uri
        } catch (e: Exception) {
            saveError(ctx, "Android could not create the recording file. ${e.message ?: "Check SD-card access."}")
            null
        }
    }

    fun delete(ctx: Context, uri: Uri): Boolean = runCatching {
        (DocumentFile.fromSingleUri(ctx, uri) ?: return false).delete()
    }.getOrDefault(false)

    fun rename(ctx: Context, uri: Uri, name: String): Uri? = runCatching {
        val file = DocumentFile.fromSingleUri(ctx, uri) ?: return null
        if (file.renameTo(safeName(name) + ".m4a")) file.uri else null
    }.getOrNull()

    fun safeName(name: String): String {
        val cleaned = name.trim().replace(Regex("[\\/:*?\"<>|]"), "_")
        return cleaned.ifBlank { "Recording" }.take(100)
    }

    fun displayLocation(ctx: Context): String = if (validate(ctx).ok) {
        "SD card / KeyShortcut / Recordings"
    } else "Not linked"

    /** Resolve the selected SAF tree to the actual destination directory. */
    private fun recordingsDirectory(ctx: Context): DocumentFile? {
        val tree = rootTreeUri(ctx) ?: return null
        var current = DocumentFile.fromTreeUri(ctx, tree) ?: return null
        val selectedName = current.name.orEmpty()
        if (selectedName.equals(RECORDINGS_DIR, ignoreCase = true)) return current
        if (!selectedName.equals(KEYSHORTCUT_DIR, ignoreCase = true)) {
            current = findOrCreateDirectory(current, KEYSHORTCUT_DIR)
        }
        return findOrCreateDirectory(current, RECORDINGS_DIR)
    }

    private fun findOrCreateDirectory(parent: DocumentFile, name: String): DocumentFile {
        val existing = parent.listFiles().firstOrNull {
            it.isDirectory && it.name.equals(name, ignoreCase = true)
        }
        return existing ?: parent.createDirectory(name)
            ?: throw IllegalStateException("Android could not create the $name folder.")
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun saveError(ctx: Context, message: String) {
        prefs(ctx).edit().putString(KEY_LAST_ERROR, message).apply()
    }
}
