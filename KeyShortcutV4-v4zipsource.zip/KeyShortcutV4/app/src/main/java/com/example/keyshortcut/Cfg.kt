package com.example.keyshortcut

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persistent configuration for KeyShortcut. */
object Cfg {
    const val PREFS = "keyshortcut2"
    const val CONFIG_VERSION = 3
    val GESTURES = arrayOf("Tap", "Hold", "Double tap", "Triple tap")
    const val SELECTION_MENU = -2
    const val UNASSIGNED = -1

    fun newAction(): JSONObject = JSONObject()
        .put("enabled", true)
        .put("pkg", "")
        .put("label", "")
        .put("steps", JSONArray())

    fun newStep(type: String): JSONObject = JSONObject().put("type", type)

    private fun newProfile(enabled: Boolean): JSONObject {
        val acts = JSONArray()
        acts.put(newAction())
        val assign = JSONArray()
        repeat(GESTURES.size) { assign.put(UNASSIGNED) }
        return JSONObject().put("enabled", enabled).put("assign", assign).put("actions", acts)
    }

    fun load(ctx: Context): JSONObject {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("config", null)
        val cfg = try {
            if (raw == null) JSONObject() else JSONObject(raw)
        } catch (_: Exception) {
            JSONObject()
        }

        if (!cfg.has("unlockedOnly")) cfg.put("unlockedOnly", true)
        if (!cfg.has("banner")) cfg.put("banner", true)
        if (!cfg.has("holdMs")) cfg.put("holdMs", 1200)
        if (!cfg.has("configVersion")) cfg.put("configVersion", 1)

        var profs = cfg.optJSONObject("profiles")
        if (profs == null) {
            profs = JSONObject()
            cfg.put("profiles", profs)
        }
        if (!profs.has("vol")) profs.put("vol", newProfile(true))
        if (!profs.has("power")) profs.put("power", newProfile(false))

        migrateProfile(profs.getJSONObject("vol"), cfg.optInt("configVersion", 1))
        migrateProfile(profs.getJSONObject("power"), cfg.optInt("configVersion", 1))
        cfg.put("configVersion", CONFIG_VERSION)
        return cfg
    }

    private fun migrateProfile(p: JSONObject, version: Int) {
        var acts = p.optJSONArray("actions")
        if (acts == null) {
            acts = JSONArray()
            p.put("actions", acts)
        }
        if (acts.length() == 0) acts.put(newAction())

        // Preserve the old three gestures: old Hold -> new Hold, old Double -> new Double, old Triple -> new Triple.
        val oldAssign = p.optJSONArray("assign")
        val newAssign = JSONArray()
        if (version < CONFIG_VERSION && oldAssign != null && oldAssign.length() >= 3) {
            newAssign.put(UNASSIGNED)
            newAssign.put(oldAssign.optInt(0, UNASSIGNED))
            newAssign.put(oldAssign.optInt(1, UNASSIGNED))
            newAssign.put(oldAssign.optInt(2, UNASSIGNED))
        } else {
            repeat(GESTURES.size) { newAssign.put(oldAssign?.optInt(it, UNASSIGNED) ?: UNASSIGNED) }
        }
        p.put("assign", newAssign)

        for (i in 0 until acts.length()) migrateAction(acts.getJSONObject(i))
        if (!p.has("enabled")) p.put("enabled", false)
    }

    private fun migrateAction(a: JSONObject) {
        if (!a.has("enabled")) a.put("enabled", true)
        if (!a.has("pkg")) a.put("pkg", "")
        if (!a.has("label")) a.put("label", "")

        if (a.optJSONArray("steps") == null) {
            val steps = JSONArray()
            val pkg = a.optString("pkg")
            val label = a.optString("label")
            if (pkg.isNotEmpty()) steps.put(newStep("open_app").put("pkg", pkg).put("label", label))

            val ts = a.optString("tailscale", "none")
            if (ts == "on" || ts == "off") steps.put(newStep(if (ts == "on") "tailscale_on" else "tailscale_off"))

            val controls = a.optJSONArray("controls") ?: JSONArray()
            for (i in 0 until controls.length()) {
                steps.put(JSONObject(controls.getJSONObject(i).toString()).put("type", "tap"))
            }
            if (a.optBoolean("closeApp", false)) steps.put(newStep("close_app"))
            a.put("steps", steps)
        }
        // Keep legacy fields so older configs are harmless, but steps are authoritative now.
        a.put("controls", JSONArray())
        a.put("tailscale", "none")
        a.put("closeApp", false)
    }

    fun save(ctx: Context, cfg: JSONObject) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("config", cfg.toString()).apply()
    }

    fun profile(cfg: JSONObject, key: String): JSONObject =
        cfg.getJSONObject("profiles").getJSONObject(key)
}
