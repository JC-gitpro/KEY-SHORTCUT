package com.example.keyshortcut

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileNotFoundException
import java.net.URLDecoder

/** Small read-only provider so recordings can be shared without exposing file:// URIs. */
class RecordingFileProvider : ContentProvider() {
    override fun onCreate(): Boolean = true
    override fun query(uri: Uri, projection: Array<String>?, selection: String?, selectionArgs: Array<String>?, sortOrder: String?): Cursor {
        val file = resolve(uri) ?: return MatrixCursor(arrayOf("_display_name", "_size"))
        val c = MatrixCursor(arrayOf("_display_name", "_size"))
        c.addRow(arrayOf(file.name, file.length()))
        return c
    }
    override fun getType(uri: Uri): String = "audio/mp4"
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<String>?): Int = 0
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (!mode.contains("r") || mode.contains("w")) throw FileNotFoundException("Read-only")
        val file = resolve(uri) ?: throw FileNotFoundException("Recording not found")
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    private fun resolve(uri: Uri): File? {
        val raw = uri.path?.removePrefix("/") ?: return null
        val decoded = try { URLDecoder.decode(raw, "UTF-8") } catch (_: Exception) { raw }
        val root = File(requireContext().filesDir, "recordings").canonicalFile
        val f = File(root, decoded).canonicalFile
        if (!f.path.startsWith(root.path + File.separator) || !f.exists()) return null
        return f
    }
}
