# KeyShortcut v4.0 — SD card recorder storage fix

This version fixes two separate storage/recording failure points:

1. It stores the original Storage Access Framework tree URI and persists only the read/write flags returned by Android. The app resolves `KeyShortcut/Recordings` from that selected tree using AndroidX `DocumentFile`, instead of treating a child document URI as if it were a tree permission.
2. It records to a seekable temporary M4A file in app cache, then copies the finalized audio to the selected SD-card folder through the SAF output stream. This avoids MediaRecorder muxer failures with non-seekable provider file descriptors.

To link storage: open Voice Recorder → Link storage folder → select a writable folder on the SD card and approve access. The app creates/uses `KeyShortcut/Recordings` under the selected folder, unless you select `KeyShortcut` or `Recordings` directly.

The build workflow creates a native Android Gradle project and replaces the Flutter plugin-based Gradle file included in the source archive.
