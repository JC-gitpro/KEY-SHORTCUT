# KeyShortcut v2.5 — SD-card recording storage fix

This build fixes the recording-folder linking flow.

## What changed

When you tap **Link storage folder** in Voice Recorder:

1. Android's folder picker opens.
2. Select the **microSD card** (or another writable parent folder).
3. KeyShortcut requests persistent read/write access.
4. KeyShortcut automatically creates or reuses:

   `SD card / KeyShortcut / Recordings`

5. The app performs a real create/delete test in that folder.
6. Recordings are created directly in that folder using the Storage Access Framework.

The persisted permission is kept for the original selected tree, while the actual Recordings folder URI is stored separately. This avoids the Android/Samsung SAF problem where a child folder URI is not itself a persisted tree permission.

## Important

If an older v2.5 build already says storage is linked but recordings do not work, tap **Change storage folder** and select the microSD card again once. The new build will rebuild/verify the KeyShortcut/Recordings folder automatically.
