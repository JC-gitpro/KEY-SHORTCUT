# KeyShortcut v3.0

This is the actual v3.0 Android source tree, not a renamed wrapper around an older source ZIP.

## v3.0 storage/recorder fixes
- Adds the missing `StorageManager.isLinked()` API used by the recorder UI.
- Keeps the SAF-persisted SD-card permission and the actual `KeyShortcut/Recordings` folder URI separately.
- Validates the persisted write permission with a real create/delete probe before reporting storage ready.
- Uses the selected SD-card tree to create or reuse `KeyShortcut/Recordings`.
- Keeps the recorder foreground-service microphone declarations.

The GitHub Actions workflow builds this source into a standalone debug APK with package ID `com.example.keyshortcut.test30` so it can be installed alongside older test builds.
