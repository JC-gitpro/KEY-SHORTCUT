# KeyShortcut v2.2 Test

This test build uses only **Volume Up + Volume Down** for hardware gesture detection.

The action editor uses an event-sequence layout: Open app, recorded taps, Tailscale actions, and Close app can be arranged top-to-bottom. App-related events display the selected app icon on the left. Tap, Hold, Double tap, and Triple tap are supported.

The top-level app selector was removed from the action editor; apps are selected through the **Open app** event at the bottom of the editor.

The launcher icon was redesigned with a dark indigo/blue style instead of the previous orange/black icon.
