package com.example.keyshortcut

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File

/** Persistent user-selected recording folder using Android's Storage Access Framework. */
object StorageManager {
    private const val PREFS = "recording_storage"
    private const val KEY_TREE = "tree_uri"

    fun treeUri(ctx: Context): Uri? = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_TREE, null)?.let { runCatching { Uri.parse(it) }.getOrNull() }

    fun isLinked(ctx: Context): Boolean = treeUri(ctx) != null

    fun setTreeUri(ctx: Context, uri: Uri) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TREE, uri.toString()).apply()
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_TREE).apply()
    }

    fun createRecording(ctx: Context, baseName: String): Uri? {
        val tree = treeUri(ctx) ?: return null
        return runCatching {
            DocumentsContract.createDocument(
                ctx.contentResolver,
                tree,
                "audio/mp4",
                safeName(baseName) + ".m4a"
            )
        }.getOrNull()
    }

    fun delete(ctx: Context, uri: Uri): Boolean = runCatching {
        DocumentsContract.deleteDocument(ctx.contentResolver, uri)
    }.getOrDefault(false)

    fun rename(ctx: Context, uri: Uri, name: String): Uri? = runCatching {
        DocumentsContract.renameDocument(ctx.contentResolver, uri, safeName(name) + ".m4a")
    }.getOrNull()

    fun safeName(name: String): String {
        val cleaned = name.trim().replace(Regex("[\\/:*?\"<>|]"), "_")
        return cleaned.ifBlank { "Recording" }.take(100)
    }

    fun displayLocation(ctx: Context): String {
        val uri = treeUri(ctx) ?: return "Not linked"
        val doc = DocumentsContract.getTreeDocumentId(uri)
        return doc.substringAfterLast(':').ifBlank { "SD card" }
    }
}
