# KeyShortcut v2.4

Built from the working v2.2 architecture with the v2.3 recorder/Sufshark features carried forward.

## v2.4 changes
- Fixed-size centered selection menu (340dp x 430dp) with scrolling inside the menu.
- Added "Back to KeyShortcut" button to the selection menu.
- Faster recorded navigation taps and shorter app-transition waits.
- Voice Recorder redesigned as a dedicated recorder experience.
- Persistent SD-card recording folder selected through Android's folder picker.
- "Link recording folder" / "Change recording folder" control.
- Recordings are written directly to the selected folder and metadata is kept separately from the APK.
- Gesture recording uses an armed foreground recorder service initialized while KeyShortcut is visible, so the later hardware gesture does not attempt to create a microphone foreground service from the background.
- Pause/resume, stop, waveform/level display, recent recordings, library, rename, trim, share, delete.
- Recorder back arrow always returns to the main KeyShortcut screen.

Important: Android 14+ requires microphone foreground services to be created while the app is visible. The recorder therefore arms its foreground service while Voice Recorder is opened with microphone permission granted. The hardware gesture then controls the already-running recorder service rather than starting a new microphone foreground service from the background.
