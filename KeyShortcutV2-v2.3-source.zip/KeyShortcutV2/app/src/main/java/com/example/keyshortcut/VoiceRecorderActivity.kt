package com.example.keyshortcut

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaPlayer
import android.net.Uri
import android.content.ClipData
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** iPhone-inspired native voice recorder and recording library. */
class VoiceRecorderActivity : Activity() {
    companion object {
        const val ACTION_REFRESH = "com.example.keyshortcut.voice.REFRESH"
        fun notifyRefresh(ctx: Context) { ctx.sendBroadcast(Intent(ACTION_REFRESH).setPackage(ctx.packageName)) }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var playingPath: String? = null
    private var timer: TextView? = null

    private val refreshReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { showPage() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registerReceiver(refreshReceiver, IntentFilter(ACTION_REFRESH), Context.RECEIVER_NOT_EXPORTED)
        showPage()
    }

    override fun onDestroy() {
        try { unregisterReceiver(refreshReceiver) } catch (_: Exception) {}
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, bold: Boolean = false, color: Int = Color.BLACK): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        setAllCaps(false)
        setOnClickListener { click() }
    }

    private fun showPage() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
        }
        root.addView(tv("Voice Recorder", 30f, true))
        root.addView(tv("A built-in recorder for KeyShortcut gestures.", 14f, false, Color.DKGRAY))
        root.addView(spacer(12))

        val now = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(0xFF15151A.toInt(), 24)
        }
        now.addView(tv(if (VoiceRecorderService.recording) "● Recording now" else "Ready to record", 18f, true, if (VoiceRecorderService.recording) 0xFFFF4D5A.toInt() else Color.WHITE))
        timer = tv(if (VoiceRecorderService.recording) elapsed() else "00:00", 42f, true, Color.WHITE).apply { gravity = Gravity.CENTER_HORIZONTAL }
        now.addView(timer)
        now.addView(tv(if (VoiceRecorderService.recording) "Tap Stop below or use your assigned gesture again." else "Use the gesture assigned to Voice Recorder, or start here.", 13f, false, 0xFFB9BAC4.toInt()))
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        controls.addView(button(if (VoiceRecorderService.recording) "Stop" else "Start") {
            VoiceRecorderService.send(this, if (VoiceRecorderService.recording) VoiceRecorderService.ACTION_STOP else VoiceRecorderService.ACTION_START)
            handler.postDelayed({ showPage() }, 500L)
        })
        controls.addView(button("Open library") { showLibrary() })
        now.addView(controls)
        root.addView(now)

        root.addView(spacer(18))
        root.addView(tv("Recent recordings", 20f, true))
        val list = RecordingStore.all(this)
        if (list.isEmpty()) root.addView(tv("No recordings yet.", 14f, false, Color.DKGRAY))
        else list.take(5).forEach { root.addView(recordingRow(it)) }
        root.addView(spacer(12))
        root.addView(button("View all recordings") { showLibrary() })

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        if (VoiceRecorderService.recording) startTimerLoop()
    }

    private fun startTimerLoop() {
        handler.post(object : Runnable {
            override fun run() {
                if (!isFinishing && VoiceRecorderService.recording) {
                    timer?.text = elapsed()
                    handler.postDelayed(this, 500L)
                }
            }
        })
    }

    private fun elapsed(): String {
        val sec = ((System.currentTimeMillis() - VoiceRecorderService.startedAt) / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
    }

    private fun recordingRow(item: RecordingStore.Item): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(0xFFF0F1F5.toInt(), 18)
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = tv(item.name, 16f, true)
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        head.addView(title)
        head.addView(tv(formatDate(item.created), 11f, false, Color.GRAY))
        r.addView(head)
        r.addView(tv(duration(item.path), 12f, false, Color.GRAY))
        val buttons = LinearLayout(this)
        buttons.addView(button("Play") { play(item.path) })
        buttons.addView(button("Rename") { rename(item) })
        buttons.addView(button("Trim") { trim(item) })
        buttons.addView(button("Share") { share(item) })
        buttons.addView(button("Delete") { delete(item) })
        r.addView(buttons)
        r.setOnClickListener { showRecording(item) }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(10)
        r.layoutParams = lp
        return r
    }

    private fun showLibrary() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
        }
        root.addView(button("← Recorder") { showPage() })
        root.addView(tv("Recordings", 30f, true))
        val list = RecordingStore.all(this)
        if (list.isEmpty()) root.addView(tv("No recordings yet.", 15f, false, Color.DKGRAY))
        else list.forEach { root.addView(recordingRow(it)) }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun showRecording(item: RecordingStore.Item) {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(30)) }
        root.addView(button("← Recordings") { showLibrary() })
        root.addView(tv(item.name, 28f, true))
        root.addView(tv(formatDate(item.created) + "  •  " + duration(item.path), 13f, false, Color.GRAY))
        root.addView(spacer(18))
        val big = tv("▶", 54f, true).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF4F6BED.toInt())
            setPadding(0, dp(20), 0, dp(20))
            setOnClickListener { play(item.path) }
        }
        root.addView(big)
        root.addView(button("Rename") { rename(item) })
        root.addView(button("Trim recording") { trim(item) })
        root.addView(button("Share") { share(item) })
        root.addView(button("Delete") { delete(item) })
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }

    private fun play(path: String) {
        try {
            if (playingPath == path && player?.isPlaying == true) {
                player?.pause(); return
            }
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(path)
                setOnCompletionListener { playingPath = null }
                prepare()
                start()
            }
            playingPath = path
        } catch (e: Exception) { toast("Couldn't play this recording") }
    }

    private fun rename(item: RecordingStore.Item) {
        val input = EditText(this).apply { setText(item.name); setSingleLine() }
        AlertDialog.Builder(this).setTitle("Rename recording").setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                RecordingStore.rename(this, item.path, input.text.toString())
                showLibrary()
            }.show()
    }

    private fun delete(item: RecordingStore.Item) {
        AlertDialog.Builder(this).setTitle("Delete recording?").setMessage("This permanently removes the audio file.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> RecordingStore.delete(this, item.path); showLibrary() }.show()
    }

    private fun share(item: RecordingStore.Item) {
        try {
            val file = File(item.path)
            val uri = Uri.parse("content://com.example.keyshortcut.recordings/" + Uri.encode(file.name))
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "audio/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("Recording", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Share recording"))
        } catch (e: Exception) { toast("Couldn't share this recording") }
    }

    private fun duration(path: String): String {
        return try {
            val mp = MediaPlayer(); mp.setDataSource(path); mp.prepare(); val ms = mp.duration; mp.release()
            val sec = ms / 1000
            String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
        } catch (_: Exception) { "Audio" }
    }

    private fun trim(item: RecordingStore.Item) {
        val durationSec = try {
            val mp = MediaPlayer(); mp.setDataSource(item.path); mp.prepare(); val d = (mp.duration / 1000).coerceAtLeast(1); mp.release(); d
        } catch (_: Exception) { 0 }
        if (durationSec <= 0) { toast("Couldn't read the recording length"); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), 0) }
        val start = EditText(this).apply { hint = "Start seconds"; inputType = 2; setText("0") }
        val end = EditText(this).apply { hint = "End seconds"; inputType = 2; setText(durationSec.toString()) }
        box.addView(start); box.addView(end)
        AlertDialog.Builder(this).setTitle("Trim recording").setMessage("Keep audio between these times.").setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Trim") { _, _ ->
                val s = start.text.toString().toLongOrNull() ?: 0L
                val e = end.text.toString().toLongOrNull() ?: durationSec.toLong()
                if (s < 0 || e <= s) { toast("End time must be after start time"); return@setPositiveButton }
                Thread { doTrim(item, s * 1_000_000L, e * 1_000_000L) }.start()
            }.show()
    }

    private fun doTrim(item: RecordingStore.Item, startUs: Long, endUs: Long) {
        try {
            val src = File(item.path)
            val out = File(src.parentFile, src.nameWithoutExtension + "_trimmed.m4a")
            val ex = MediaExtractor(); ex.setDataSource(src.absolutePath)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; break }
            }
            if (track < 0) throw Exception("No audio track")
            ex.selectTrack(track)
            val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outTrack = mux.addTrack(ex.getTrackFormat(track)); mux.start()
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val buffer = java.nio.ByteBuffer.allocate(1024 * 1024)
            val info = android.media.MediaCodec.BufferInfo()
            while (true) {
                info.offset = 0
                info.size = ex.readSampleData(buffer, 0)
                if (info.size < 0) break
                val t = ex.sampleTime
                if (t > endUs) break
                if (t >= startUs) {
                    info.presentationTimeUs = t - startUs
                    info.flags = ex.sampleFlags
                    mux.writeSampleData(outTrack, buffer, info)
                }
                ex.advance()
            }
            mux.stop(); mux.release(); ex.release()
            RecordingStore.add(this, out.absolutePath, item.name + " (trimmed)")
            runOnUiThread { toast("Trimmed recording saved"); showLibrary() }
        } catch (e: Exception) { runOnUiThread { toast("Trim failed") } }
    }

    private fun formatDate(t: Long): String = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US).format(Date(t))
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun spacer(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
