package com.example.keyshortcut

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Native microphone recorder used by KeyShortcut gestures. */
class VoiceRecorderService : Service() {
    companion object {
        const val ACTION_TOGGLE = "com.example.keyshortcut.voice.TOGGLE"
        const val ACTION_START = "com.example.keyshortcut.voice.START"
        const val ACTION_STOP = "com.example.keyshortcut.voice.STOP"
        const val ACTION_OPEN = "com.example.keyshortcut.voice.OPEN"
        const val ACTION_STATE = "com.example.keyshortcut.voice.STATE"
        const val EXTRA_STATE = "state"
        const val STATE_IDLE = "idle"
        const val STATE_RECORDING = "recording"

        @Volatile var recording = false
        @Volatile var currentPath: String? = null
        @Volatile var startedAt: Long = 0L

        private const val CHANNEL = "keyshortcut_voice"
        private const val NOTIFICATION_ID = 4101
        private const val FINISHED_NOTIFICATION_ID = 4102

        fun send(ctx: Context, action: String) {
            val i = Intent(ctx, VoiceRecorderService::class.java).setAction(action)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private var recorder: MediaRecorder? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (recording) {
                KeyComboService.instance?.updateRecorderPill(elapsedMs())
                handler.postDelayed(this, 500L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> if (recording) stopRecording() else startRecording()
            ACTION_START -> if (!recording) startRecording()
            ACTION_STOP -> if (recording) stopRecording()
            ACTION_OPEN -> openRecorder()
        }
        return START_NOT_STICKY
    }

    private fun startRecording() {
        if (recording) return
        try {
            val dir = File(filesDir, "recordings")
            if (!dir.exists()) dir.mkdirs()
            val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            val file = File(dir, "Recording_$stamp.m4a")

            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            currentPath = file.absolutePath
            startedAt = System.currentTimeMillis()
            recording = true
            startForeground(NOTIFICATION_ID, buildNotification())
            KeyComboService.instance?.showRecorderPill()
            handler.removeCallbacks(tick)
            handler.post(tick)
        } catch (e: Exception) {
            e.printStackTrace()
            recording = false
            recorder = null
            currentPath = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun stopRecording() {
        if (!recording) {
            stopSelf()
            return
        }
        val path = currentPath
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        recording = false
        currentPath = null
        handler.removeCallbacks(tick)
        KeyComboService.instance?.hideRecorderPill()
        if (!path.isNullOrEmpty()) {
            RecordingStore.add(this, path, File(path).nameWithoutExtension)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        VoiceRecorderActivity.notifyRefresh(this)
        try {
            val n = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            n.notify(FINISHED_NOTIFICATION_ID, finishedNotification(path))
        } catch (_: Exception) {}
    }

    private fun elapsedMs(): Long = if (startedAt == 0L) 0L else System.currentTimeMillis() - startedAt

    private fun openRecorder() {
        try {
            val i = Intent(this, VoiceRecorderActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            startActivity(i)
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Voice Recorder", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun pending(action: String, id: Int): PendingIntent {
        val i = Intent(this, VoiceRecorderService::class.java).setAction(action)
        return PendingIntent.getService(this, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun baseBuilder(): android.app.Notification.Builder {
        return if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, CHANNEL)
        else android.app.Notification.Builder(this)
    }

    private fun buildNotification(): Notification = baseBuilder()
        .setContentTitle("Voice Recorder")
        .setContentText("Recording ${formatElapsed(elapsedMs())}")
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setOngoing(true)
        .setContentIntent(PendingIntent.getActivity(this, 20, Intent(this, VoiceRecorderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        .addAction(Notification.Action.Builder(null, "Stop", pending(ACTION_STOP, 21)).build())
        .build()

    private fun finishedNotification(path: String?): Notification = baseBuilder()
        .setContentTitle("Recording saved")
        .setContentText(if (path.isNullOrEmpty()) "Open Voice Recorder" else File(path).nameWithoutExtension)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setAutoCancel(true)
        .setContentIntent(PendingIntent.getActivity(this, 22, Intent(this, VoiceRecorderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        .build()

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        if (recording) {
            try { recorder?.stop() } catch (_: Exception) {}
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            recording = false
        }
        KeyComboService.instance?.hideRecorderPill()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun formatElapsed(ms: Long): String {
        val total = ms / 1000
        return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
    }

}
