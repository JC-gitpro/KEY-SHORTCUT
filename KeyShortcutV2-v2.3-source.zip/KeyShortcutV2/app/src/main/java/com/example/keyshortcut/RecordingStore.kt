package com.example.keyshortcut

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object RecordingStore {
    private const val PREFS = "voice_recordings"
    private const val KEY = "items"

    data class Item(val path: String, var name: String, val created: Long)

    fun all(ctx: Context): MutableList<Item> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val out = mutableListOf<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val path = o.optString("path")
            if (path.isNotEmpty() && File(path).exists()) out.add(Item(path, o.optString("name", File(path).nameWithoutExtension), o.optLong("created", File(path).lastModified())))
        }
        out.sortByDescending { it.created }
        return out
    }

    fun add(ctx: Context, path: String, name: String) {
        val list = all(ctx)
        list.removeAll { it.path == path }
        list.add(0, Item(path, name, System.currentTimeMillis()))
        save(ctx, list)
    }

    fun rename(ctx: Context, path: String, name: String) {
        val list = all(ctx)
        list.find { it.path == path }?.name = name.ifBlank { "Recording" }
        save(ctx, list)
    }

    fun delete(ctx: Context, path: String) {
        try { File(path).delete() } catch (_: Exception) {}
        val list = all(ctx)
        list.removeAll { it.path == path }
        save(ctx, list)
    }

    private fun save(ctx: Context, list: List<Item>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("path", it.path).put("name", it.name).put("created", it.created)) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
