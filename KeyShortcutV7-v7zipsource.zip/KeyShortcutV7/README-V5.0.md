# KeyShortcut v5.0 — recording studio and four-press trigger

## Recorder changes
- Recording detail has play/pause, a seek bar, and elapsed/total time.
- Newly recorded files retain sampled microphone levels; the detail waveform reflects those samples.
- Edit menu includes rename, trim/cut, playback speed, and playback volume.
- Condense for text re-encodes audio as mono 32 kbps AAC, then opens Android's share chooser. Actual carrier/MMS limits vary; long recordings may still need trimming.
- Recordings are automatically transcribed on-device in English using the compact Vosk model. The first transcription downloads the model (internet required); later transcriptions reuse it. Existing recordings can be transcribed from the detail page.

## Shortcut changes
- Volume Up + Volume Down supports quadruple tap.
- New installs default quadruple tap to Toggle Voice Recorder.
- Upgrades add the quadruple-tap assignment to Voice Recorder without replacing existing configured actions.
- The unlocked-only restriction defaults off; Android/Samsung may still limit key delivery with the display fully off.
- Newly added Open app events automatically name the action after the selected app.

## Build
Upload `KeyShortcutV5-v5zipsource.zip` to the repository root and use the matching workflow. Package ID: `com.example.keyshortcut.test50`.

## Note
The included source has no standalone Gradle wrapper; the GitHub Actions workflow generates the native Android Gradle project and includes AndroidX DocumentFile plus Vosk.
