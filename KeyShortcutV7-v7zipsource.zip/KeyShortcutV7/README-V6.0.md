# KeyShortcut v7.0

Recorder experience update based on the working v5 source. Adds a dedicated full-page recording editor, a separate trim/cut workspace with in/out sliders and waveform context, and transcript-derived descriptive titles that retain recording date/time.

Build with the included GitHub Actions workflow using `KeyShortcutV6-v6zipsource.zip`. Test on-device before relying on background/lock-screen recording behavior.
