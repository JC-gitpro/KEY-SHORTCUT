package com.example.keyshortcut

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/** Native KeyShortcut configuration UI. */
class MainActivity : Activity() {
    private var cfg = JSONObject()
    private var profile = "vol"
    private var editingIndex = -1

    override fun onResume() {
        super.onResume()
        cfg = Cfg.load(this)
        if (editingIndex >= 0) showEditor(editingIndex) else showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun save() { Cfg.save(this, cfg) }
    private fun prof(): JSONObject = Cfg.profile(cfg, profile)

    private fun newPage(title: String): LinearLayout {
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(40))
        val t = label(title, 28f, true)
        t.setPadding(0, 0, 0, dp(12))
        content.addView(t)
        val sv = ScrollView(this)
        sv.addView(content)
        setContentView(sv)
        return content
    }

    private fun label(s: String, size: Float = 16f, bold: Boolean = false, color: Int = Color.BLACK): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.includeFontPadding = true
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun btn(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setAllCaps(false)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun smallIconButton(s: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = s
        b.textSize = 15f
        b.gravity = Gravity.CENTER
        b.setTextColor(Color.DKGRAY)
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.setPadding(0, 0, 0, 0)
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.background = GradientDrawable().apply {
            setColor(Color.parseColor("#E3E4E9"))
            setCornerRadius(dp(16).toFloat())
        }
        b.layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)).apply {
            leftMargin = dp(3)
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#EEF0F6"))
        bg.setCornerRadius(dp(16).toFloat())
        c.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        c.layoutParams = lp
        return c
    }

    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun weighted(v: View): View { v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); return v }
    private fun spacer(h: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h)) }

    private fun loadIcon(pkg: String?): Drawable? = try {
        if (pkg.isNullOrEmpty()) null else packageManager.getApplicationIcon(pkg)
    } catch (_: Exception) { null }

    private fun iconView(pkg: String?, sizeDp: Int): View {
        val d = loadIcon(pkg)
        val lp = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply { rightMargin = dp(10) }
        if (d != null) return ImageView(this).apply { setImageDrawable(d); layoutParams = lp }
        return TextView(this).apply {
            text = "⚡"
            textSize = sizeDp * .42f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#5267D8"))
            }
            layoutParams = lp
        }
    }

    private fun isInstalled(pkg: String): Boolean = try { packageManager.getApplicationInfo(pkg, 0); true } catch (_: Exception) { false }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = android.content.ComponentName(this, KeyComboService::class.java)
        return enabled.contains(cn.flattenToString()) || enabled.contains(cn.flattenToShortString())
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun showHome() {
        editingIndex = -1
        val c = newPage("KeyShortcut")
        c.addView(accessCard())
        c.addView(recorderCard())
        c.addView(surfsharkCard())
        c.addView(profileCard())
        c.addView(assignCard())

        val head = label("Actions", 20f, true)
        head.setPadding(0, dp(8), 0, dp(8))
        c.addView(head)

        val acts = prof().getJSONArray("actions")
        for (i in 0 until acts.length()) c.addView(actionCard(i))
        c.addView(btn("＋ Add action") { addAction() })
        c.addView(settingsCard())
    }

    private fun accessCard(): LinearLayout {
        val on = isServiceEnabled()
        val k = card()
        k.background = GradientDrawable().apply {
            setColor(Color.parseColor(if (on) "#DDF3E1" else "#FBDADA"))
            setCornerRadius(dp(16).toFloat())
        }
        k.addView(label(if (on) "Accessibility service is on" else "Accessibility service is OFF", 17f, true))
        k.addView(label(if (on) "Your shortcuts work from any app." else "Turn on KeyShortcut in Accessibility settings before testing gestures.", 13f))
        if (!on) k.addView(btn("Open Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        return k
    }

    private fun recorderCard(): LinearLayout {
        val k = card()
        k.addView(label("Voice Recorder", 17f, true))
        k.addView(label("Record from a gesture, use the polished recording pill, and keep recordings on your SD card.", 13f))
        k.addView(label(if (StorageManager.isLinked(this)) "● SD card storage connected" else "● SD card storage not linked", 13f, false, if (StorageManager.isLinked(this)) 0xFF2E8B57.toInt() else 0xFFB44A4A.toInt()))
        k.addView(btn("Open Voice Recorder") { openRecorder() })
        k.addView(btn(if (StorageManager.isLinked(this)) "Change recording folder" else "Link recording folder") { openRecorder() })
        return k
    }

    private fun surfsharkCard(): LinearLayout {
        val k = card()
        k.addView(label("Surfshark", 17f, true))
        val installed = isInstalled("com.surfshark.vpnclient.android")
        k.addView(label(if (installed) "Save a Surfshark country/city once, then replay that exact location from a gesture." else "Install Surfshark first. KeyShortcut can then record a chosen location and replay it.", 13f))
        if (installed) {
            k.addView(btn("Open Surfshark") { launchSurfshark() })
            k.addView(btn("Set up a saved location") { addSurfsharkSetupAction() })
        }
        return k
    }

    private fun openRecorder() {
        requestRecorderPermissions()
        startActivity(Intent(this, VoiceRecorderActivity::class.java))
    }

    private fun requestRecorderPermissions() {
        val needs = ArrayList<String>()
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needs.add(android.Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needs.add(android.Manifest.permission.POST_NOTIFICATIONS)
        if (needs.isNotEmpty()) requestPermissions(needs.toTypedArray(), 740)
    }

    private fun launchSurfshark() {
        val li = packageManager.getLaunchIntentForPackage("com.surfshark.vpnclient.android")
        if (li == null) toast("Surfshark is not installed.") else startActivity(li)
    }

    private fun addSurfsharkSetupAction() {
        val acts = prof().getJSONArray("actions")
        val a = Cfg.newAction().put("label", "Connect Surfshark saved location")
        a.put("pkg", "com.surfshark.vpnclient.android")
        a.put("label", "Connect Surfshark saved location")
        a.getJSONArray("steps").put(Cfg.newStep("open_app").put("pkg", "com.surfshark.vpnclient.android").put("label", "Surfshark"))
        acts.put(a)
        save()
        val index = acts.length() - 1
        val svc = KeyComboService.instance
        if (svc == null) {
            toast("Turn on the KeyShortcut accessibility service first.")
            showEditor(index)
            return
        }
        val li = packageManager.getLaunchIntentForPackage("com.surfshark.vpnclient.android")
        if (li == null) { toast("Surfshark is not installed."); showEditor(index); return }
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        startActivity(li)
        svc.startRecording(profile, index, "com.surfshark.vpnclient.android")
        toast("Choose your Surfshark country/city and tap through the location. KeyShortcut will record the navigation.")
        editingIndex = index
    }

    private fun profileCard(): LinearLayout {
        val p = prof()
        val k = card()
        val head = row()
        head.gravity = Gravity.CENTER_VERTICAL
        val title = label("Volume Up + Volume Down", 17f, true)
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        head.addView(title)
        val sw = Switch(this)
        sw.isChecked = p.optBoolean("enabled", false)
        sw.setOnCheckedChangeListener { _, v -> p.put("enabled", v); save() }
        head.addView(sw)
        k.addView(head)
        k.addView(label("Tap, hold, double tap, or triple tap both buttons together.", 13f))
        return k
    }

    private fun actionNames(): Array<String> {
        val acts = prof().getJSONArray("actions")
        val out = ArrayList<String>()
        out.add("Not assigned")
        out.add("Selection menu")
        for (i in 0 until acts.length()) out.add("Action ${i + 1}: " + actionTitle(acts.getJSONObject(i), i))
        return out.toTypedArray()
    }

    private fun assignCard(): LinearLayout {
        val p = prof()
        val asg = p.getJSONArray("assign")
        val k = card()
        k.addView(label("Gesture assignment", 17f, true))
        k.addView(label("Assign Tap, Hold, Double tap, and Triple tap independently to any action or to the selection menu.", 13f))
        k.addView(spacer(6))
        val options = actionNames()
        for (g in Cfg.GESTURES.indices) {
            val r = row()
            r.gravity = Gravity.CENTER_VERTICAL
            val name = label(Cfg.GESTURES[g], 15f, true)
            name.layoutParams = LinearLayout.LayoutParams(dp(105), ViewGroup.LayoutParams.WRAP_CONTENT)
            r.addView(name)
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
            val current = asg.optInt(g, Cfg.UNASSIGNED)
            sp.setSelection(when {
                current == Cfg.SELECTION_MENU -> 1
                current >= 0 -> current + 2
                else -> 0
            })
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    val chosen = when {
                        pos == 1 -> Cfg.SELECTION_MENU
                        pos >= 2 -> pos - 2
                        else -> Cfg.UNASSIGNED
                    }
                    if (chosen != asg.optInt(g, Cfg.UNASSIGNED)) {
                        asg.put(g, chosen)
                        save()
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
            sp.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            r.addView(sp)
            k.addView(r)
        }
        return k
    }

    private fun actionTitle(a: JSONObject, i: Int): String = a.optString("label").ifBlank { "Action ${i + 1}" }

    private fun assignedGestures(index: Int): String {
        val asg = prof().getJSONArray("assign")
        val names = ArrayList<String>()
        for (g in Cfg.GESTURES.indices) if (asg.optInt(g, Cfg.UNASSIGNED) == index) names.add(Cfg.GESTURES[g])
        return if (names.isEmpty()) "Not assigned" else names.joinToString(", ")
    }

    private fun eventLabel(s: JSONObject): String = when (s.optString("type")) {
        "open_app" -> "Open " + s.optString("label").ifBlank { s.optString("pkg") }
        "tap" -> "Tap: " + s.optString("label").ifBlank { "control" }
        "tailscale_on" -> "Turn Tailscale on"
        "tailscale_off" -> "Turn Tailscale off"
        "close_app" -> "Close " + s.optString("label").ifBlank { s.optString("pkg", "app") }
        "voice_toggle" -> "Toggle voice recording"
        "voice_start" -> "Start voice recording"
        "voice_stop" -> "Stop voice recording"
        "voice_open" -> "Open Voice Recorder"
        else -> s.optString("type", "Event")
    }

    private fun eventPkg(s: JSONObject): String = when (s.optString("type")) {
        "open_app", "tap", "close_app" -> s.optString("pkg")
        else -> ""
    }

    private fun actionCard(i: Int): LinearLayout {
        val a = prof().getJSONArray("actions").getJSONObject(i)
        val k = card()
        val head = row()
        head.gravity = Gravity.CENTER_VERTICAL
        val title = label(actionTitle(a, i), 18f, true)
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        head.addView(title)
        val sw = Switch(this)
        sw.isChecked = a.optBoolean("enabled", true)
        sw.setOnCheckedChangeListener { _, v -> a.put("enabled", v); save() }
        head.addView(sw)
        k.addView(head)
        k.addView(label("Gestures: ${assignedGestures(i)}", 13f, false, Color.DKGRAY))
        val steps = a.optJSONArray("steps") ?: JSONArray()
        val summary = ArrayList<String>()
        for (q in 0 until steps.length()) summary.add("${q + 1}. ${eventLabel(steps.getJSONObject(q))}")
        k.addView(label(if (summary.isEmpty()) "No events configured" else summary.joinToString("\n"), 13f, false, Color.DKGRAY))
        val r = row()
        r.addView(weighted(btn("Edit") { showEditor(i) }))
        r.addView(weighted(btn("Test") { testAction(a, i) }))
        r.addView(weighted(btn("Delete") { deleteAction(i) }))
        k.addView(r)
        return k
    }

    private fun addAction() {
        val acts = prof().getJSONArray("actions")
        val a = Cfg.newAction().put("label", "Action ${acts.length() + 1}")
        acts.put(a)
        save()
        showEditor(acts.length() - 1)
    }

    private fun deleteAction(index: Int) {
        AlertDialog.Builder(this)
            .setTitle("Delete action?")
            .setMessage("This removes the action and unassigns any gestures using it.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                val p = prof()
                val acts = p.getJSONArray("actions")
                if (index >= 0 && index < acts.length()) acts.remove(index)
                val asg = p.getJSONArray("assign")
                for (g in 0 until asg.length()) {
                    val v = asg.optInt(g, Cfg.UNASSIGNED)
                    asg.put(g, when {
                        v == index -> Cfg.UNASSIGNED
                        v > index -> v - 1
                        else -> v
                    })
                }
                save()
                showHome()
            }.show()
    }

    private fun showEditor(index: Int) {
        val acts = prof().getJSONArray("actions")
        if (index < 0 || index >= acts.length()) {
            showHome()
            return
        }
        editingIndex = index
        val a = acts.getJSONObject(index)
        val c = newPage("Edit Action ${index + 1}")
        c.addView(btn("← Back to actions") { editingIndex = -1; showHome() })

        val name = EditText(this)
        name.setText(a.optString("label"))
        name.hint = "Action name"
        name.setSingleLine()
        c.addView(name)
        name.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                a.put("label", s?.toString().orEmpty())
                save()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) {}
        })

        val en = Switch(this)
        en.text = "Enabled"
        en.isChecked = a.optBoolean("enabled", true)
        en.setOnCheckedChangeListener { _, v -> a.put("enabled", v); save() }
        c.addView(en)

        val eventsCard = card()
        eventsCard.addView(label("Events — top to bottom", 18f, true))
        eventsCard.addView(label("The action runs these events in exactly this order. App events show the app icon on the left.", 13f))
        eventsCard.addView(spacer(4))

        val steps = a.optJSONArray("steps") ?: JSONArray().also { a.put("steps", it) }
        for (q in 0 until steps.length()) eventsCard.addView(eventRow(a, q))

        eventsCard.addView(spacer(6))
        val addRow1 = row()
        addRow1.addView(weighted(btn("＋ Add event") { showAddEventDialog(index) }))
        addRow1.addView(weighted(btn("Record navigation") { startRecord(index) }))
        eventsCard.addView(addRow1)

        val addRow2 = row()
        addRow2.addView(weighted(btn("Open app") { addOpenAppEvent(index) }))
        addRow2.addView(weighted(btn("Close app") { addCloseAppEvent(index) }))
        eventsCard.addView(addRow2)

        val voiceRow = row()
        voiceRow.addView(weighted(btn("Toggle recording") { addVoiceEvent(index, "voice_toggle") }))
        voiceRow.addView(weighted(btn("Open Recorder") { addVoiceEvent(index, "voice_open") }))
        eventsCard.addView(voiceRow)
        val surfRow = row()
        surfRow.addView(weighted(btn("Set up Surfshark location") { setupSurfsharkForAction(index) }))
        eventsCard.addView(surfRow)

        c.addView(eventsCard)
        c.addView(btn("Test this action") { testAction(a, index) })
        c.addView(btn("Delete this action") { deleteAction(index) })

        val settings = card()
        settings.addView(label("Global settings", 17f, true))
        settings.addView(label("These settings apply to the whole app and are available from the main page.", 13f))
        c.addView(settings)
    }

    private fun eventRow(a: JSONObject, index: Int): LinearLayout {
        val steps = a.getJSONArray("steps")
        val s = steps.getJSONObject(index)
        val r = row()
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(5), 0, dp(5))

        val num = label("${index + 1}", 14f, true)
        num.gravity = Gravity.CENTER
        num.layoutParams = LinearLayout.LayoutParams(dp(24), dp(34))
        r.addView(num)

        val pkg = eventPkg(s)
        if (pkg.isNotEmpty()) {
            val icon = iconView(pkg, 34)
            icon.layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(8) }
            r.addView(icon)
        } else {
            val dot = TextView(this)
            dot.text = "•"
            dot.textSize = 20f
            dot.gravity = Gravity.CENTER
            dot.setTextColor(Color.GRAY)
            dot.layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(8) }
            r.addView(dot)
        }

        val text = label(eventLabel(s), 14f)
        text.maxLines = 4
        text.ellipsize = null
        text.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        r.addView(text)

        r.addView(smallIconButton("↑") {
            if (index > 0) {
                val previous = steps.getJSONObject(index - 1)
                steps.put(index, previous)
                steps.put(index - 1, s)
                save()
                showEditor(editingIndex)
            }
        })
        r.addView(smallIconButton("↓") {
            if (index < steps.length() - 1) {
                val next = steps.getJSONObject(index + 1)
                steps.put(index, next)
                steps.put(index + 1, s)
                save()
                showEditor(editingIndex)
            }
        })
        r.addView(smallIconButton("×") {
            steps.remove(index)
            save()
            showEditor(editingIndex)
        })
        return r
    }

    private fun showAddEventDialog(index: Int) {
        val choices = arrayOf("Tap/recorded control", "Turn Tailscale on", "Turn Tailscale off", "Toggle voice recording", "Start voice recording", "Stop voice recording", "Open Voice Recorder")
        AlertDialog.Builder(this)
            .setTitle("Add event")
            .setItems(choices) { _, which ->
                val a = prof().getJSONArray("actions").getJSONObject(index)
                val steps = a.getJSONArray("steps")
                when (which) {
                    0 -> startRecord(index)
                    1 -> steps.put(Cfg.newStep("tailscale_on"))
                    2 -> steps.put(Cfg.newStep("tailscale_off"))
                    3 -> steps.put(Cfg.newStep("voice_toggle"))
                    4 -> steps.put(Cfg.newStep("voice_start"))
                    5 -> steps.put(Cfg.newStep("voice_stop"))
                    6 -> steps.put(Cfg.newStep("voice_open"))
                }
                save()
                if (which != 0) showEditor(index)
            }.show()
    }

    private fun addOpenAppEvent(index: Int) {
        val a = prof().getJSONArray("actions").getJSONObject(index)
        pickApp { appLabel, pkg ->
            val step = Cfg.newStep("open_app")
                .put("pkg", pkg)
                .put("label", appLabel)
            a.getJSONArray("steps").put(step)
            // Keep this only as runtime metadata; it is not shown as a separate app selector.
            a.put("pkg", pkg)
            if (a.optString("label").isBlank() || a.optString("label").startsWith("Action ") || a.getJSONArray("steps").length() == 1) {
                a.put("label", appLabel)
            }
            save()
            showEditor(index)
        }
    }

    private fun addCloseAppEvent(index: Int) {
        val a = prof().getJSONArray("actions").getJSONObject(index)
        val steps = a.getJSONArray("steps")
        var pkg = ""
        var label = "app"
        for (i in steps.length() - 1 downTo 0) {
            val s = steps.getJSONObject(i)
            if (s.optString("type") == "open_app" && s.optString("pkg").isNotEmpty()) {
                pkg = s.optString("pkg")
                label = s.optString("label").ifBlank { pkg }
                break
            }
        }
        if (pkg.isEmpty()) {
            toast("Add an Open app event first so KeyShortcut knows which app to close.")
            return
        }
        steps.put(Cfg.newStep("close_app").put("pkg", pkg).put("label", label))
        save()
        showEditor(index)
    }

    private fun addVoiceEvent(index: Int, type: String) {
        val a = prof().getJSONArray("actions").getJSONObject(index)
        a.getJSONArray("steps").put(Cfg.newStep(type))
        save()
        if (type != "voice_open") requestRecorderPermissions()
        showEditor(index)
    }

    private fun setupSurfsharkForAction(index: Int) {
        if (!isInstalled("com.surfshark.vpnclient.android")) { toast("Surfshark is not installed."); return }
        val a = prof().getJSONArray("actions").getJSONObject(index)
        val steps = a.getJSONArray("steps")
        var hasOpen = false
        for (i in 0 until steps.length()) if (steps.getJSONObject(i).optString("type") == "open_app" && steps.getJSONObject(i).optString("pkg") == "com.surfshark.vpnclient.android") hasOpen = true
        if (!hasOpen) {
            steps.put(Cfg.newStep("open_app").put("pkg", "com.surfshark.vpnclient.android").put("label", "Surfshark"))
            a.put("pkg", "com.surfshark.vpnclient.android")
        }
        save()
        val svc = KeyComboService.instance
        if (svc == null) { toast("Turn on the KeyShortcut accessibility service first."); return }
        val li = packageManager.getLaunchIntentForPackage("com.surfshark.vpnclient.android") ?: return
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        startActivity(li)
        svc.startRecording(profile, index, "com.surfshark.vpnclient.android")
        toast("Choose the location in Surfshark. Your taps will be recorded and replayed later.")
    }

    private fun settingsCard(): LinearLayout {
        val k = card()
        k.addView(label("Settings", 17f, true))
        val unl = Switch(this)
        unl.text = "Only when the phone is unlocked"
        unl.isChecked = cfg.optBoolean("unlockedOnly", false)
        unl.setOnCheckedChangeListener { _, v -> cfg.put("unlockedOnly", v); save() }
        k.addView(unl)
        val ban = Switch(this)
        ban.text = "Show the banner at the top"
        ban.isChecked = cfg.optBoolean("banner", true)
        ban.setOnCheckedChangeListener { _, v -> cfg.put("banner", v); save() }
        k.addView(ban)
        val holdMs = cfg.optInt("holdMs", 1200)
        val holdLabel = label("Hold time: ${holdMs / 1000.0} s", 14f)
        k.addView(holdLabel)
        val bar = SeekBar(this)
        bar.max = 25
        bar.progress = ((holdMs - 500) / 100).coerceIn(0, 25)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                holdLabel.text = "Hold time: ${(500 + progress * 100) / 1000.0} s"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                cfg.put("holdMs", 500 + (s?.progress ?: 7) * 100)
                save()
            }
        })
        k.addView(bar)
        return k
    }

    private fun testAction(a: JSONObject, i: Int) {
        val svc = KeyComboService.instance ?: run {
            toast("Turn on the KeyShortcut accessibility service first.")
            return
        }
        svc.runAction(a, i, "Test")
    }

    private fun startRecord(index: Int) {
        val svc = KeyComboService.instance ?: run {
            toast("Turn on the KeyShortcut accessibility service first.")
            return
        }
        val a = prof().getJSONArray("actions").getJSONObject(index)
        val steps = a.getJSONArray("steps")
        var pkg = ""
        var label = ""
        for (i in steps.length() - 1 downTo 0) {
            val s = steps.getJSONObject(i)
            if (s.optString("type") == "open_app" && s.optString("pkg").isNotEmpty()) {
                pkg = s.optString("pkg")
                label = s.optString("label").ifBlank { pkg }
                break
            }
        }
        if (pkg.isEmpty()) {
            toast("Add an Open app event first, then record the navigation.")
            return
        }
        val li = packageManager.getLaunchIntentForPackage(pkg) ?: run {
            toast("That app can't be opened.")
            return
        }
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        startActivity(li)
        svc.startRecording(profile, index, pkg)
        toast("Recording navigation in $label")
    }

    private fun pickApp(onPicked: (String, String) -> Unit) {
        val apps = listApps()
        var shown = apps
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val search = EditText(this)
        search.hint = "Search apps"
        search.setSingleLine()
        box.addView(search)
        val list = ListView(this)
        list.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(420))
        box.addView(list)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Choose an app")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .create()
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int) = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val item = shown[position]
                val r = row()
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(12), dp(8), dp(12), dp(8))
                r.addView(iconView(item.second, 40))
                val col = LinearLayout(this@MainActivity)
                col.orientation = LinearLayout.VERTICAL
                col.addView(label(item.first, 16f, true))
                col.addView(label(item.second, 11f, false, Color.GRAY))
                r.addView(col)
                return r
            }
        }
        list.adapter = adapter
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty().lowercase()
                shown = apps.filter { it.first.lowercase().contains(q) || it.second.lowercase().contains(q) }
                adapter.notifyDataSetChanged()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) {}
        })
        list.setOnItemClickListener { _, _, pos, _ ->
            val item = shown[pos]
            dialog.dismiss()
            onPicked(item.first, item.second)
        }
        dialog.show()
    }

    private fun listApps(): List<Pair<String, String>> {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        return packageManager.queryIntentActivities(launcher, 0)
            .map { Pair(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.second }
            .filter { it.second != packageName }
            .sortedBy { it.first.lowercase() }
    }
}
