package com.example.keyshortcut

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min

/** Re-encodes a voice note as mono low-bitrate AAC for smaller message attachments. */
object AudioCondensor {
    fun create(context: Context, location: String, output: File): File {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        try {
            if (location.startsWith("content:")) extractor.setDataSource(context, Uri.parse(location), null) else extractor.setDataSource(location)
            var track = -1
            for (i in 0 until extractor.trackCount) if (extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; break }
            if (track < 0) error("No audio track found")
            extractor.selectTrack(track)
            val sourceFormat = extractor.getTrackFormat(track)
            val mime = sourceFormat.getString(MediaFormat.KEY_MIME) ?: error("Unknown audio format")
            val sampleRate = sourceFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val sourceChannels = sourceFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(sourceFormat, null, null, 0)
            val encFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, android.media.MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 32000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            output.parentFile?.mkdirs()
            if (output.exists()) output.delete()
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            decoder.start(); encoder.start()

            val decInfo = MediaCodec.BufferInfo()
            val encInfo = MediaCodec.BufferInfo()
            var decoderInputDone = false
            var decoderOutputDone = false
            var encoderInputDone = false
            var encoderOutputDone = false
            var muxerStarted = false
            var outTrack = -1
            var fallbackPts = 0L

            while (!encoderOutputDone) {
                if (!decoderInputDone) {
                    val index = decoder.dequeueInputBuffer(10000)
                    if (index >= 0) {
                        val input = decoder.getInputBuffer(index)!!
                        input.clear()
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            decoderInputDone = true
                        } else {
                            decoder.queueInputBuffer(index, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                if (!decoderOutputDone) {
                    val index = decoder.dequeueOutputBuffer(decInfo, 10000)
                    if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        // Decoder output is PCM. Encoder is configured for the original sample rate, mono.
                    } else if (index >= 0) {
                        if (decInfo.size > 0 && !encoderInputDone) {
                            val decoded = decoder.getOutputBuffer(index)!!.apply { position(decInfo.offset); limit(decInfo.offset + decInfo.size) }
                            val pcm = ByteArray(decInfo.size); decoded.get(pcm)
                            val mono = if (sourceChannels > 1) downmix(pcm, sourceChannels) else pcm
                            val encIn = encoder.dequeueInputBuffer(10000)
                            if (encIn >= 0) {
                                val target = encoder.getInputBuffer(encIn)!!
                                target.clear()
                                val n = min(mono.size, target.remaining())
                                target.put(mono, 0, n)
                                val pts = if (decInfo.presentationTimeUs > 0) decInfo.presentationTimeUs else fallbackPts
                                encoder.queueInputBuffer(encIn, 0, n, pts, 0)
                                fallbackPts = pts + (n / 2 * 1000000L / sampleRate)
                            }
                        }
                        if ((decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) decoderOutputDone = true
                        decoder.releaseOutputBuffer(index, false)
                    }
                }

                if (decoderOutputDone && !encoderInputDone) {
                    val encIn = encoder.dequeueInputBuffer(10000)
                    if (encIn >= 0) {
                        encoder.queueInputBuffer(encIn, 0, 0, fallbackPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        encoderInputDone = true
                    }
                }

                val encIndex = encoder.dequeueOutputBuffer(encInfo, 10000)
                when {
                    encIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        outTrack = muxer.addTrack(encoder.outputFormat)
                        muxer.start(); muxerStarted = true
                    }
                    encIndex >= 0 -> {
                        val encoded = encoder.getOutputBuffer(encIndex)!!
                        if (encInfo.size > 0 && muxerStarted && (encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            encoded.position(encInfo.offset); encoded.limit(encInfo.offset + encInfo.size)
                            muxer.writeSampleData(outTrack, encoded, encInfo)
                        }
                        encoderOutputDone = (encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        encoder.releaseOutputBuffer(encIndex, false)
                    }
                }
            }
            if (!output.exists() || output.length() < 1000) error("Compressed audio output is empty")
            return output
        } catch (e: Exception) {
            output.delete()
            throw e
        } finally {
            runCatching { decoder?.stop() }; runCatching { decoder?.release() }
            runCatching { encoder?.stop() }; runCatching { encoder?.release() }
            runCatching { if (muxer != null) muxer.stop() }; runCatching { muxer?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun downmix(bytes: ByteArray, channels: Int): ByteArray {
        val src = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val frames = bytes.size / (channels * 2)
        val out = ByteBuffer.allocate(frames * 2).order(ByteOrder.LITTLE_ENDIAN)
        repeat(frames) {
            var sum = 0
            repeat(channels) { sum += src.short.toInt() }
            out.putShort((sum / channels).toShort())
        }
        return out.array()
    }
}
