package com.example.keyshortcut

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

/** On-device English transcription. The compact Vosk model is downloaded once and kept locally. */
object TranscriptEngine {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private val active = ConcurrentHashMap.newKeySet<String>()

    fun transcribeAsync(context: Context, location: String) {
        if (!active.add(location)) return
        val app = context.applicationContext
        thread(name = "KeyShortcut-transcript") {
            try {
                val text = transcribe(app, location)
                RecordingStore.updateTranscript(app, location, text.ifBlank { "No speech detected." })
            } catch (e: Exception) {
                RecordingStore.updateTranscript(app, location, "TRANSCRIPTION_UNAVAILABLE:${e.message ?: "Could not transcribe this recording."}")
            } finally {
                active.remove(location)
                VoiceRecorderActivity.notifyRefresh(app)
            }
        }
    }

    private fun modelDirectory(ctx: Context): File {
        val root = File(ctx.filesDir, "vosk-model-small-en-us-0.15")
        if (File(root, "am").isDirectory) return root
        val zip = File(ctx.cacheDir, "vosk-model-en.zip")
        URL(MODEL_URL).openConnection().apply { connectTimeout = 20000; readTimeout = 60000 }.getInputStream().use { input ->
            FileOutputStream(zip).use { output -> input.copyTo(output) }
        }
        val parent = ctx.filesDir
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val out = File(parent, entry.name).canonicalFile
                require(out.path.startsWith(parent.canonicalPath + File.separator)) { "Invalid model archive path" }
                if (entry.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        zip.delete()
        if (!File(root, "am").isDirectory) throw IllegalStateException("Speech model download was incomplete")
        return root
    }

    private fun transcribe(ctx: Context, location: String): String {
        val model = Model(modelDirectory(ctx).absolutePath)
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var recognizer: Recognizer? = null
        try {
            if (location.startsWith("content:")) extractor.setDataSource(ctx, Uri.parse(location), null)
            else extractor.setDataSource(location)
            var track = -1
            for (i in 0 until extractor.trackCount) {
                if (extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; break }
            }
            if (track < 0) throw IllegalStateException("No audio track found")
            extractor.selectTrack(track)
            val inputFormat = extractor.getTrackFormat(track)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: throw IllegalStateException("Unknown audio format")
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var outRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            while (!outputDone) {
                if (!inputDone) {
                    val inIndex = decoder.dequeueInputBuffer(10000)
                    if (inIndex >= 0) {
                        val input = decoder.getInputBuffer(inIndex)!!
                        input.clear()
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                when (val outIndex = decoder.dequeueOutputBuffer(info, 10000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val fmt = decoder.outputFormat
                        outRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        recognizer?.close()
                        recognizer = Recognizer(model, outRate.toFloat())
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (outIndex >= 0) {
                        if (info.size > 0) {
                            if (recognizer == null) recognizer = Recognizer(model, outRate.toFloat())
                            val buffer = decoder.getOutputBuffer(outIndex)!!.apply { position(info.offset); limit(info.offset + info.size) }
                            val bytes = ByteArray(info.size); buffer.get(bytes)
                            val mono = if (channels > 1) downmix(bytes, channels) else bytes
                            recognizer!!.acceptWaveForm(mono, mono.size)
                        }
                        outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        decoder.releaseOutputBuffer(outIndex, false)
                    }
                }
            }
            val final = recognizer?.finalResult ?: "{}"
            return JSONObject(final).optString("text", "").trim()
        } finally {
            runCatching { recognizer?.close() }
            runCatching { decoder?.stop() }; runCatching { decoder?.release() }
            runCatching { extractor.release() }
            runCatching { model.close() }
        }
    }

    private fun downmix(input: ByteArray, channels: Int): ByteArray {
        if (channels <= 1) return input
        val src = ByteBuffer.wrap(input).order(ByteOrder.LITTLE_ENDIAN)
        val frames = input.size / (2 * channels)
        val out = ByteBuffer.allocate(frames * 2).order(ByteOrder.LITTLE_ENDIAN)
        repeat(frames) {
            var sum = 0
            repeat(channels) { sum += src.short.toInt() }
            out.putShort((sum / channels).toShort())
        }
        return out.array()
    }
}
