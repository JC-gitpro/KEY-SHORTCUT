package com.example.keyshortcut

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

object RecordingStore {
    private const val PREFS = "voice_recordings"
    private const val KEY = "items"

    data class Item(val location: String, var name: String, val created: Long, val waveform: List<Int> = emptyList(), val transcript: String = "") {
        val isUri: Boolean get() = location.startsWith("content:")
        val uri: Uri? get() = if (isUri) Uri.parse(location) else null
        val path: String get() = location
    }

    fun all(ctx: Context): MutableList<Item> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val out = mutableListOf<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val location = o.optString("location", o.optString("path"))
            if (location.isBlank()) continue
            val exists = if (location.startsWith("content:")) {
                runCatching { ctx.contentResolver.openFileDescriptor(Uri.parse(location), "r")?.use { true } ?: false }.getOrDefault(false)
            } else File(location).exists()
            if (exists) {
                val ampsJson = o.optJSONArray("waveform") ?: JSONArray()
                val amps = (0 until ampsJson.length()).map { ampsJson.optInt(it, 0) }
                out.add(Item(location, o.optString("name", "Recording"), o.optLong("created", System.currentTimeMillis()), amps, o.optString("transcript", "")))
            }
        }
        out.sortByDescending { it.created }
        return out
    }

    fun add(ctx: Context, location: String, name: String, waveform: List<Int> = emptyList()) {
        val list = all(ctx)
        list.removeAll { it.location == location }
        list.add(0, Item(location, name.ifBlank { "Recording" }, System.currentTimeMillis(), waveform))
        save(ctx, list)
    }

    fun rename(ctx: Context, item: Item, name: String): Item? {
        val newName = name.ifBlank { "Recording" }
        var newLocation = item.location
        if (item.isUri) {
            newLocation = StorageManager.rename(ctx, Uri.parse(item.location), newName)?.toString() ?: item.location
        } else {
            val src = File(item.location)
            val dst = File(src.parentFile, StorageManager.safeName(newName) + ".m4a")
            if (src.exists() && src.absolutePath != dst.absolutePath) runCatching { src.renameTo(dst) }
            newLocation = dst.absolutePath
        }
        val list = all(ctx)
        list.find { it.location == item.location }?.let {
            it.name = newName
            list.remove(it)
            list.add(0, Item(newLocation, newName, item.created, item.waveform, item.transcript))
        }
        save(ctx, list)
        return Item(newLocation, newName, item.created, item.waveform, item.transcript)
    }

    fun updateTranscript(ctx: Context, location: String, transcript: String) {
        val list = all(ctx)
        val arr = JSONArray()
        list.forEach { item ->
            val finalTranscript = if (item.location == location) transcript else item.transcript
            val isGeneratedTitle = item.name.startsWith("Recording") || Regex(" · [A-Z][a-z]{2} \d{1,2}, \d{4} ·").containsMatchIn(item.name)
            val generatedName = if (item.location == location && isGeneratedTitle && finalTranscript.isNotBlank() && !finalTranscript.startsWith("TRANSCRIPTION_UNAVAILABLE:")) {
                val date = java.text.SimpleDateFormat("M/d/yy · h:mm a", java.util.Locale.US).format(java.util.Date(item.created))
                "${shortConcept(finalTranscript)} · $date"
            } else item.name
            arr.put(JSONObject().put("location", item.location).put("name", generatedName).put("created", item.created)
                .put("waveform", JSONArray(item.waveform)).put("transcript", finalTranscript))
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }


    private fun shortConcept(transcript: String): String {
        val normalized = transcript.lowercase(Locale.US).replace(Regex("[^a-z0-9' ]"), " ").replace(Regex("\\s+"), " ").trim()
        val stop = setOf("hello", "hi", "hey", "and", "welcome", "to", "this", "the", "a", "an", "is", "are", "was", "were", "i", "we", "you", "it", "of", "for", "in", "on", "that", "so", "um", "uh", "like", "today", "now", "new")
        val words = normalized.split(" ").filter { it.length > 1 && it !in stop }
        if (words.isEmpty()) return "Voice note"
        val podcast = words.indexOf("podcast")
        val conceptWords = if (podcast >= 0) words.filterIndexed { index, _ -> index != podcast }.takeLast(2) else words.takeLast(3)
        val topic = if (conceptWords.contains("apps") && conceptWords.contains("creating")) "App creating" else conceptWords.joinToString(" ").replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.US) else it.toString() }
        return if (podcast >= 0 && topic.isNotBlank()) "Podcast - $topic" else words.takeLast(3).joinToString(" ").replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.US) else it.toString() }
    }

    fun delete(ctx: Context, item: Item) {
        if (item.isUri) runCatching { StorageManager.delete(ctx, Uri.parse(item.location)) }
        else runCatching { File(item.location).delete() }
        val list = all(ctx)
        list.removeAll { it.location == item.location }
        save(ctx, list)
    }

    private fun save(ctx: Context, list: List<Item>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("location", it.location).put("name", it.name).put("created", it.created).put("waveform", JSONArray(it.waveform)).put("transcript", it.transcript)) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
