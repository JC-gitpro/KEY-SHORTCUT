package com.example.keyshortcut

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

/** Polished standalone voice recorder experience inside KeyShortcut. */
class VoiceRecorderActivity : Activity() {
    companion object {
        const val ACTION_REFRESH = "com.example.keyshortcut.voice.REFRESH"
        const val PICK_FOLDER = 8801
        fun notifyRefresh(ctx: Context) { ctx.sendBroadcast(Intent(ACTION_REFRESH).setPackage(ctx.packageName)) }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var playing: RecordingStore.Item? = null
    private var timer: TextView? = null
    private var waveform: LinearLayout? = null
    private var titleView: TextView? = null
    private var pendingStartAfterPermission = false
    private var detailProgress: SeekBar? = null
    private var detailTime: TextView? = null
    private var detailPlayButton: Button? = null
    private var detailItem: RecordingStore.Item? = null
    private var userSeeking = false
    private val playbackTicker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && detailItem != null) {
                val duration = runCatching { p.duration }.getOrDefault(0)
                val position = runCatching { p.currentPosition }.getOrDefault(0)
                if (!userSeeking) detailProgress?.progress = position
                detailTime?.text = "${clock(position)} / ${clock(duration)}"
                detailPlayButton?.text = if (runCatching { p.isPlaying }.getOrDefault(false)) "Ⅱ  Pause" else "▶  Play"
                if (runCatching { p.isPlaying }.getOrDefault(false)) handler.postDelayed(this, 250)
            }
        }
    }

    private val refreshReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val selected = detailItem
            if (selected == null) showHome()
            else RecordingStore.all(this@VoiceRecorderActivity).firstOrNull { it.location == selected.location }?.let { showRecording(it) } ?: showHome()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registerReceiver(refreshReceiver, IntentFilter(ACTION_REFRESH), Context.RECEIVER_NOT_EXPORTED)
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            VoiceRecorderService.arm(this)
        }
        showHome()
    }

    override fun onDestroy() {
        try { unregisterReceiver(refreshReceiver) } catch (_: Exception) {}
        handler.removeCallbacks(playbackTicker)
        player?.release(); player = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(text: String, size: Float, bold: Boolean = false, color: Int = Color.BLACK) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); includeFontPadding = true
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun button(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text; setAllCaps(false); setOnClickListener { click() }
    }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun spacer(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }

    private fun backToMain() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }

    private fun header(title: String, back: () -> Unit): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(tv("‹", 38f, false, Color.BLACK).apply { setOnClickListener { back() }; setPadding(0, 0, dp(8), 0) })
        addView(tv(title, 25f, true))
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(32)) }
        root.addView(header("Voice Recorder") { backToMain() })
        root.addView(tv("Record, edit, and keep your voice notes on your SD card.", 13f, false, Color.DKGRAY))
        root.addView(spacer(16))

        root.addView(recordingStudio())
        root.addView(spacer(20))
        root.addView(storageCard())
        root.addView(spacer(20))
        root.addView(recentSection())
        root.addView(spacer(12))
        root.addView(button("View all recordings") { showLibrary() })

        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        if (VoiceRecorderService.recording) startLoops()
    }

    private fun recordingStudio(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(0xFF111217.toInt(), 30)
        }

        val recording = VoiceRecorderService.recording
        val paused = VoiceRecorderService.paused
        val stateColor = when {
            recording && !paused -> 0xFFFF5B6B.toInt()
            recording -> 0xFFFFC857.toInt()
            else -> 0xFFB7BBC7.toInt()
        }

        val state = tv(if (recording) if (paused) "PAUSED" else "RECORDING" else "READY", 12f, true, stateColor).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            letterSpacing = .12f
        }
        card.addView(state)

        timer = tv(if (recording) elapsed() else "00:00", 58f, true, Color.WHITE).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            letterSpacing = .02f
            setPadding(0, dp(4), 0, 0)
        }
        card.addView(timer)

        titleView = tv(if (recording) "Current recording" else "Voice Memo", 14f, false, 0xFFB9BBC4.toInt()).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        }
        card.addView(titleView)
        card.addView(spacer(16))

        waveform = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        repeat(36) { i -> waveform!!.addView(waveBar(if (recording) 10 + ((i * 7) % 28) else 7 + ((i % 4) * 4))) }
        card.addView(waveform)
        card.addView(spacer(14))

        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }

        if (recording) {
            controls.addView(circleAction(if (paused) "▶" else "Ⅱ", if (paused) "Resume" else "Pause") {
                VoiceRecorderService.send(this@VoiceRecorderActivity, if (paused) VoiceRecorderService.ACTION_RESUME else VoiceRecorderService.ACTION_PAUSE)
                handler.postDelayed({ showHome() }, 220)
            })
            controls.addView(spacerH(18))
            controls.addView(circleAction("■", "Stop", 0xFFE94B5B.toInt()) {
                VoiceRecorderService.send(this@VoiceRecorderActivity, VoiceRecorderService.ACTION_STOP)
                handler.postDelayed({ showHome() }, 450)
            })
        } else {
            controls.addView(circleAction("●", "Record", 0xFFFF4F61.toInt()) { startRecordingFromPage() })
        }
        card.addView(controls)
        card.addView(spacer(10))
        card.addView(tv(
            if (recording) "Recording stays active while you use other apps." else "Tap Record to start a new voice recording.",
            12f, false, 0xFF8F929D.toInt()
        ).apply { gravity = Gravity.CENTER_HORIZONTAL })
        return card
    }

    private fun waveBar(h: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(3), dp(h)).apply { leftMargin = dp(2); rightMargin = dp(2) }
        setBackgroundColor(0xFF6875FF.toInt())
    }

    private fun circleAction(symbol: String, label: String, color: Int = 0xFF4657D8.toInt(), click: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT)
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
        val circle = TextView(this).apply {
            text = symbol
            textSize = if (symbol == "●") 28f else 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(color)
            }
            layoutParams = LinearLayout.LayoutParams(dp(62), dp(62))
        }
        box.addView(circle)
        box.addView(tv(label, 12f, true, 0xFFB9BBC4.toInt()).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
        return box
    }

    private fun spacerH(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }

    private fun startRecordingFromPage() {
        val validation = StorageManager.validate(this)
        if (!validation.ok) {
            toast(validation.message)
            linkFolder()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterPermission = true
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 740)
            return
        }
        VoiceRecorderService.startFromVisibleActivity(this)
        handler.postDelayed({ showHome() }, 300)
    }

    private fun storageCard(): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(17), dp(17), dp(17))
            background = rounded(0xFFF1F3F8.toInt(), 22)
        }
        c.addView(tv("Recording Storage", 18f, true))
        c.addView(spacer(4))
        val validation = StorageManager.validate(this)
        val linked = validation.ok
        c.addView(tv(if (linked) "● SD card connected" else "● Storage needs attention", 13f, true, if (linked) 0xFF258A57.toInt() else 0xFFB84D59.toInt()))
        c.addView(tv(if (linked) "SD card / KeyShortcut / Recordings" else validation.message, 13f, false, 0xFF5D626D.toInt()).apply { setPadding(0, dp(3), 0, dp(8)) })
        c.addView(button(if (linked) "Change storage folder" else "Link storage folder") { linkFolder() })
        return c
    }

    private fun linkFolder() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        }, PICK_FOLDER)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_FOLDER || resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        val validation = StorageManager.linkSelectedFolder(this, uri, data.flags)
        if (validation.ok) {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                VoiceRecorderService.arm(this)
            }
            toast("Recording storage connected: SD card / KeyShortcut / Recordings")
        } else {
            toast(validation.message)
        }
        showHome()
    }

    private fun recentSection(): View {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("Recent Recordings", 21f, true).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        head.addView(tv("All  ›", 14f, true, 0xFF4F6BED.toInt()).apply { setOnClickListener { showLibrary() } })
        wrap.addView(head)
        wrap.addView(spacer(8))
        val list = RecordingStore.all(this)
        if (list.isEmpty()) {
            val empty = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(26), dp(20), dp(26)); background = rounded(0xFFF3F4F7.toInt(), 18) }
            empty.addView(tv("No recordings yet", 17f, true)); empty.addView(tv("Your saved voice notes will appear here.", 13f, false, Color.GRAY))
            wrap.addView(empty)
        } else {
            list.take(5).forEach { wrap.addView(recordingRow(it)) }
        }
        return wrap
    }

    private fun recordingRow(item: RecordingStore.Item): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(13), dp(12), dp(10), dp(12)); background = rounded(0xFFF0F1F5.toInt(), 17) }
        val icon = tv("◉", 23f, true, 0xFF4F6BED.toInt()).apply { gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)) }
        r.addView(icon)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(10); rightMargin = dp(8) } }
        col.addView(tv(item.name, 15f, true))
        col.addView(tv(formatDate(item.created) + "  •  " + duration(item), 11f, false, Color.GRAY))
        r.addView(col)
        r.addView(tv("▶", 18f, true, 0xFF4F6BED.toInt()).apply { setOnClickListener { play(item) } })
        r.addView(tv("⋮", 25f, false, Color.DKGRAY).apply { setPadding(dp(12), 0, 0, 0); setOnClickListener { menu(item) } })
        r.setOnClickListener { showRecording(item) }
        r.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
        return r
    }

    private fun menu(item: RecordingStore.Item) {
        AlertDialog.Builder(this).setItems(arrayOf("Play", "Rename", "Trim", "Share", "Delete")) { _, which ->
            when (which) { 0 -> play(item); 1 -> rename(item); 2 -> trim(item); 3 -> share(item); 4 -> delete(item) }
        }.show()
    }

    private fun showLibrary() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(32)) }
        root.addView(header("Recordings") { backToMain() })
        root.addView(tv("Your saved voice notes", 13f, false, Color.DKGRAY))
        root.addView(spacer(14))
        RecordingStore.all(this).forEach { root.addView(recordingRow(it)) }
        if (RecordingStore.all(this).isEmpty()) root.addView(tv("No recordings yet.", 15f, false, Color.GRAY))
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }

    private fun showRecording(item: RecordingStore.Item) {
        if (item.transcript.isNotBlank() && !item.transcript.startsWith("TRANSCRIPTION_UNAVAILABLE:")) {
            RecordingStore.updateTranscript(this, item.location, item.transcript)
            val refreshed = RecordingStore.all(this).firstOrNull { it.location == item.location }
            if (refreshed != null && refreshed.name != item.name) return showRecording(refreshed)
        }
        detailItem = item
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(32)) }
        root.addView(header("Recording") { showLibrary() })
        root.addView(spacer(8))
        root.addView(tv(item.name, 27f, true))
        root.addView(tv(formatDate(item.created) + "  •  " + duration(item), 13f, false, Color.GRAY))
        root.addView(spacer(18))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(20))
            background = rounded(0xFF101116.toInt(), 26)
        }
        panel.addView(waveformView(item))
        panel.addView(spacer(12))
        detailPlayButton = button("▶  Play") { play(item) }
        panel.addView(detailPlayButton)
        detailProgress = SeekBar(this).apply {
            max = maxOf(1, durationMillis(item))
            progress = 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true }
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) detailTime?.text = "${clock(progress)} / ${clock(max)}"
                }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    runCatching { player?.seekTo(seekBar?.progress ?: 0) }
                    userSeeking = false
                }
            })
        }
        panel.addView(detailProgress)
        detailTime = tv("00:00 / ${clock(durationMillis(item))}", 12f, false, 0xFFB9BBC4.toInt())
        detailTime?.gravity = Gravity.CENTER
        panel.addView(detailTime)
        root.addView(panel)
        root.addView(spacer(16))

        val transcriptCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(0xFFF0F1F5.toInt(), 18)
        }
        transcriptCard.addView(tv("Transcript", 17f, true))
        val transcriptText = when {
            item.transcript.startsWith("TRANSCRIPTION_UNAVAILABLE:") -> "Transcript unavailable: " + item.transcript.substringAfter(":")
            item.transcript.isNotBlank() -> item.transcript
            else -> "Creating transcript… The first transcription may download a compact English speech model."
        }
        transcriptCard.addView(tv(transcriptText, 14f, false, Color.DKGRAY))
        if (item.transcript.isBlank() || item.transcript.startsWith("TRANSCRIPTION_UNAVAILABLE:")) {
            transcriptCard.addView(button("Generate transcript") { TranscriptEngine.transcribeAsync(applicationContext, item.location); toast("Transcription started") })
        }
        root.addView(transcriptCard)
        root.addView(spacer(12))
        root.addView(button("Edit recording") { showEditor(item) })
        root.addView(button("Condense for text") { condenseAndShare(item) })
        root.addView(button("Share original") { share(item) })
        root.addView(button("Delete") { delete(item) })
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        handler.removeCallbacks(playbackTicker)
        if (playing?.location == item.location && player != null) handler.post(playbackTicker)
    }

    private fun waveformView(item: RecordingStore.Item): View {
        val values = item.waveform
        val bars = 64
        val sampled = (0 until bars).map { i ->
            if (values.isEmpty()) 0.18f else {
                val index = (i.toFloat() / (bars - 1) * (values.size - 1)).toInt().coerceIn(0, values.lastIndex)
                (values[index].toFloat() / 32767f).coerceIn(0.04f, 1f)
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(94))
            sampled.forEach { amplitude ->
                val bar = View(this@VoiceRecorderActivity)
                bar.background = rounded(0xFF7D89FF.toInt(), 3)
                val h = dp((8 + amplitude * 76).toInt())
                addView(bar, LinearLayout.LayoutParams(0, h, 1f).apply { leftMargin = dp(1); rightMargin = dp(1) })
            }
        }
    }

    private fun durationMillis(item: RecordingStore.Item): Int = try {
        val mp = MediaPlayer()
        if (item.isUri) mp.setDataSource(this, Uri.parse(item.location)) else mp.setDataSource(item.location)
        mp.prepare(); val value = mp.duration; mp.release(); value.coerceAtLeast(1)
    } catch (_: Exception) { 1 }

    private fun clock(ms: Int): String = String.format(Locale.US, "%02d:%02d", (ms / 1000) / 60, (ms / 1000) % 60)

    private fun showEditor(item: RecordingStore.Item) {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(32)) }
        root.addView(header("Edit recording") { showRecording(item) })
        root.addView(tv(item.name, 23f, true))
        root.addView(tv("Make precise changes to this recording", 13f, false, Color.GRAY))
        root.addView(spacer(18))
        val preview = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(0xFF101116.toInt(), 22) }
        preview.addView(waveformView(item))
        preview.addView(button("▶  Play preview") { play(item) })
        // This editor page must own its own SeekBar. Reusing detailProgress from
        // the recording detail screen throws IllegalStateException (view already has a parent).
        val editorProgress = SeekBar(this).apply {
            max = durationMillis(item).coerceAtLeast(1)
            progress = player?.currentPosition?.coerceIn(0, max) ?: 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true }
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) detailTime?.text = "${clock(progress)} / ${clock(max)}"
                }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    runCatching { player?.seekTo(seekBar?.progress ?: 0) }
                    userSeeking = false
                }
            })
        }
        preview.addView(editorProgress)
        root.addView(preview)
        root.addView(spacer(16))
        val actions = listOf(
            Triple("✎", "Rename recording", { rename(item) }),
            Triple("✂", "Trim and cut audio", { showTrimEditor(item) }),
            Triple("1×", "Playback speed", { chooseSpeed() }),
            Triple("◖", "Playback volume", { choosePlaybackVolume() }),
            Triple("≡", "Generate transcript", { TranscriptEngine.transcribeAsync(applicationContext, item.location); toast("Transcription started") })
        )
        actions.forEach { (symbol, label, action) ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(15), dp(14), dp(15)); background = rounded(0xFFF0F1F5.toInt(), 15) }
            row.addView(tv(symbol, 22f, true, 0xFF5965D8.toInt()).apply { layoutParams = LinearLayout.LayoutParams(dp(42), -2) })
            row.addView(tv(label, 16f, true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
            row.addView(tv("›", 27f, false, Color.GRAY))
            row.setOnClickListener { action() }
            root.addView(row); root.addView(spacer(9))
        }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }

    private fun showTrimEditor(item: RecordingStore.Item) {
        val duration = durationMillis(item).coerceAtLeast(1000)
        var startMs = 0
        var endMs = duration
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(28)) }
        root.addView(header("Trim & cut") { showEditor(item) })
        root.addView(tv("Choose the section to keep", 23f, true))
        root.addView(tv("Drag the handles to set the in and out points. The selected range will be saved as a new recording.", 14f, false, Color.GRAY))
        root.addView(spacer(18))
        val wave = waveformView(item)
        root.addView(LinearLayout(this).apply { setPadding(dp(12), dp(16), dp(12), dp(16)); background = rounded(0xFF101116.toInt(), 20); addView(wave) })
        val startLabel = tv("Start  00:00", 14f, true)
        val startSeek = SeekBar(this).apply { max = duration; progress = 0 }
        val endLabel = tv("End  ${clock(duration)}", 14f, true)
        val endSeek = SeekBar(this).apply { max = duration; progress = duration }
        startSeek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) { if(fromUser) { startMs=value.coerceAtMost(endMs-500); startLabel.text="Start  ${clock(startMs)}"; startSeek.progress=startMs } }
        })
        endSeek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) { if(fromUser) { endMs=value.coerceAtLeast(startMs+500); endLabel.text="End  ${clock(endMs)}"; endSeek.progress=endMs } }
        })
        root.addView(spacer(12)); root.addView(startLabel); root.addView(startSeek); root.addView(endLabel); root.addView(endSeek)
        root.addView(spacer(18))
        root.addView(button("Save selected section as new recording") { if(endMs-startMs<500) toast("Select at least half a second") else { Thread { doTrim(item, startMs*1000L, endMs*1000L) }.start() } })
        root.addView(button("Cancel") { showEditor(item) })
        val scroll=ScrollView(this); scroll.addView(root); setContentView(scroll)
    }

    private fun chooseSpeed() {
        val labels = arrayOf("0.75× slower", "Normal 1×", "1.25×", "1.5×", "2× faster")
        val speeds = floatArrayOf(.75f, 1f, 1.25f, 1.5f, 2f)
        AlertDialog.Builder(this).setTitle("Playback speed").setItems(labels) { _, which ->
            runCatching { if (android.os.Build.VERSION.SDK_INT >= 23) player?.playbackParams = PlaybackParams().setSpeed(speeds[which]) }
            toast("Speed applies to playback preview")
        }.show()
    }

    private fun choosePlaybackVolume() {
        val seek = SeekBar(this).apply { max = 100; progress = 100 }
        val dialog = AlertDialog.Builder(this).setTitle("Playback volume").setMessage("Adjust preview volume").setView(seek).setPositiveButton("Done", null).create()
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress / 100f
                runCatching { player?.setVolume(value, value) }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        dialog.show()
    }

    private fun condenseAndShare(item: RecordingStore.Item) {
        toast("Creating a smaller AAC copy…")
        Thread {
            try {
                val folder = File(filesDir, "recordings").apply { mkdirs() }
                val file = File(folder, "${System.currentTimeMillis()}_message.m4a")
                AudioCondensor.create(this, item.location, file)
                runOnUiThread {
                    try {
                        val uri = Uri.parse("content://" + packageName + ".recordings/" + Uri.encode(file.name))
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "audio/mp4"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            clipData = ClipData.newRawUri("Condensed recording", uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(intent, "Send smaller recording"))
                    } catch (_: Exception) { toast("Condensed copy created, but sharing failed") }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Couldn't condense recording: ${e.message ?: "unsupported audio"}") }
            }
        }.start()
    }

    private fun play(item: RecordingStore.Item) {
        try {
            if (playing?.location == item.location && player != null) {
                if (player!!.isPlaying) player!!.pause() else player!!.start()
                handler.removeCallbacks(playbackTicker)
                handler.post(playbackTicker)
                return
            }
            handler.removeCallbacks(playbackTicker)
            player?.release()
            player = MediaPlayer().apply {
                if (item.isUri) setDataSource(this@VoiceRecorderActivity, Uri.parse(item.location)) else setDataSource(item.location)
                setOnCompletionListener {
                    detailProgress?.progress = detailProgress?.max ?: 0
                    detailPlayButton?.text = "▶  Play again"
                    handler.removeCallbacks(playbackTicker)
                }
                prepare(); start()
            }
            playing = item
            detailItem = item
            detailProgress?.max = player?.duration ?: durationMillis(item)
            detailProgress?.progress = 0
            detailPlayButton?.text = "Ⅱ  Pause"
            handler.post(playbackTicker)
        } catch (_: Exception) { toast("Couldn't play this recording") }
    }

    private fun rename(item: RecordingStore.Item) {
        val input = EditText(this).apply { setText(item.name); setSingleLine() }
        AlertDialog.Builder(this).setTitle("Rename recording").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            RecordingStore.rename(this, item, input.text.toString()); showHome()
        }.show()
    }

    private fun delete(item: RecordingStore.Item) {
        AlertDialog.Builder(this).setTitle("Delete recording?").setMessage("This permanently removes the audio file from your recording folder.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> RecordingStore.delete(this, item); showHome() }.show()
    }

    private fun share(item: RecordingStore.Item) {
        try {
            val uri = if (item.isUri) Uri.parse(item.location) else Uri.parse("content://" + packageName + ".recordings/" + Uri.encode(File(item.path).name))
            val i = Intent(Intent.ACTION_SEND).apply { type = "audio/mp4"; putExtra(Intent.EXTRA_STREAM, uri); clipData = ClipData.newRawUri("Recording", uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(Intent.createChooser(i, "Share recording"))
        } catch (_: Exception) { toast("Couldn't share this recording") }
    }

    private fun duration(item: RecordingStore.Item): String = try {
        val mp = MediaPlayer()
        if (item.isUri) mp.setDataSource(this, Uri.parse(item.location)) else mp.setDataSource(item.location)
        mp.prepare(); val sec = mp.duration / 1000; mp.release(); String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
    } catch (_: Exception) { "--:--" }

    private fun trim(item: RecordingStore.Item) { showTrimEditor(item) }

    private fun doTrim(item: RecordingStore.Item, startUs: Long, endUs: Long) {
        val temp = File(cacheDir, "trim_${System.currentTimeMillis()}.m4a")
        try {
            val ex = MediaExtractor()
            if (item.isUri) ex.setDataSource(this, Uri.parse(item.location), null) else ex.setDataSource(item.location)
            var track = -1
            for (i in 0 until ex.trackCount) if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; break }
            if (track < 0) throw Exception("No audio track")
            ex.selectTrack(track)
            val mux = MediaMuxer(temp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outTrack = mux.addTrack(ex.getTrackFormat(track)); mux.start(); ex.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val buffer = java.nio.ByteBuffer.allocate(1024 * 1024); val info = android.media.MediaCodec.BufferInfo()
            while (true) { info.offset = 0; info.size = ex.readSampleData(buffer, 0); if (info.size < 0) break; val t = ex.sampleTime; if (t > endUs) break; if (t >= startUs) { info.presentationTimeUs = t - startUs; info.flags = ex.sampleFlags; mux.writeSampleData(outTrack, buffer, info) }; ex.advance() }
            mux.stop(); mux.release(); ex.release()
            val name = item.name + " (trimmed)"
            val outUri = StorageManager.createRecording(this, name)
            if (outUri == null) throw Exception("Recording storage is not linked")
            contentResolver.openOutputStream(outUri, "w")!!.use { out -> temp.inputStream().use { it.copyTo(out) } }
            RecordingStore.add(this, outUri.toString(), name)
            temp.delete()
            runOnUiThread { toast("Trimmed recording saved"); showHome() }
        } catch (_: Exception) { temp.delete(); runOnUiThread { toast("Trim failed") } }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 740 && grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            VoiceRecorderService.arm(this)
            if (pendingStartAfterPermission) {
                pendingStartAfterPermission = false
                handler.postDelayed({ VoiceRecorderService.startFromVisibleActivity(this); showHome() }, 300)
            } else {
                toast("Microphone ready. Your gesture can now start recording.")
                showHome()
            }
        } else if (requestCode == 740) {
            pendingStartAfterPermission = false
            toast("Microphone permission is required to record audio.")
        }
    }

    private fun startLoops() {
        handler.post(object : Runnable {
            override fun run() {
                if (isFinishing || !VoiceRecorderService.recording) return
                timer?.text = elapsed()
                val amp = VoiceRecorderService.maxAmplitude
                waveform?.let { for (i in 0 until it.childCount) { val v = it.getChildAt(i); val base = 8 + ((amp / 5000).coerceIn(0, 15) + (i % 5) * 4); v.layoutParams = (v.layoutParams as LinearLayout.LayoutParams).apply { height = dp(base) }; v.requestLayout() } }
                handler.postDelayed(this, 250)
            }
        })
    }

    private fun elapsed(): String { val sec = ((System.currentTimeMillis() - VoiceRecorderService.startedAt) / 1000).coerceAtLeast(0); return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60) }
    private fun formatDate(t: Long): String = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US).format(Date(t))
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
